import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const Aibase());

class Aibase extends StatefulWidget {
  const Aibase({super.key});

  @override
  State<Aibase> createState() => _AibaseState();
}

class _AibaseState extends State<Aibase> {
  String _lang = 'en';

  void _changeLang(String? lang) {
    if (lang != null) setState(() => _lang = lang);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Tools Discovery',
      theme: ThemeData(primarySwatch: Colors.grey),
      home: AiToolsHomePage(
        lang: _lang,
        onLangChanged: _changeLang,
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}

// UI Language packs
const Map<String, Map<String, String>> langPack = {
  'en': {
    'title': 'Discover Top AI Tools',
    'category': 'Category',
    'examplePrompts': 'Example Prompts (English):',
    'openTool': 'Open Tool',
    'selectLang': 'Language',
    'couldNotLaunch': 'Could not launch ',
    'English': 'English',
    'Hindi': 'हिंदी',
    'Marathi': 'मराठी',
    'Spanish': 'Español',
    'German': 'Deutsch',
  },
  'hi': {
    'title': 'शीर्ष AI टूल्स खोजें',
    'category': 'श्रेणी',
    'examplePrompts': 'उदाहरण प्रॉम्प्ट (हिंदी):',
    'openTool': 'टूल खोलें',
    'selectLang': 'भाषा',
    'couldNotLaunch': 'लिंक खोला नहीं जा सका ',
    'English': 'English',
    'Hindi': 'हिंदी',
    'Marathi': 'मराठी',
    'Spanish': 'स्पेनिश',
    'German': 'जर्मन',
  },
  'mr': {
    'title': 'सर्वोत्कृष्ट AI साधने शोधा',
    'category': 'वर्ग',
    'examplePrompts': 'उदाहरण संकेत (मराठी):',
    'openTool': 'साधन उघडा',
    'selectLang': 'भाषा',
    'couldNotLaunch': 'लिंक उघडता आला नाही ',
    'English': 'English',
    'Hindi': 'हिंदी',
    'Marathi': 'मराठी',
    'Spanish': 'Spanish',
    'German': 'German',
  },
  'es': {
    'title': 'Descubre las mejores herramientas de IA',
    'category': 'Categoría',
    'examplePrompts': 'Ejemplos de prompts (Español):',
    'openTool': 'Abrir herramienta',
    'selectLang': 'Idioma',
    'couldNotLaunch': 'No se pudo abrir ',
    'English': 'Inglés',
    'Hindi': 'Hindi',
    'Marathi': 'Marathi',
    'Spanish': 'Español',
    'German': 'Alemán',
  },
  'de': {
    'title': 'Entdecke Top KI-Tools',
    'category': 'Kategorie',
    'examplePrompts': 'Beispiel-Prompts (Deutsch):',
    'openTool': 'Tool öffnen',
    'selectLang': 'Sprache',
    'couldNotLaunch': 'Konnte nicht öffnen ',
    'English': 'Englisch',
    'Hindi': 'Hindi',
    'Marathi': 'Marathi',
    'Spanish': 'Spanisch',
    'German': 'Deutsch',
  },
};

// Translations for tool names and descriptions
const Map<String, Map<String, Map<String, String>>> toolTranslations = {
  "ChatGPT": {
    "en": {
      "name": "ChatGPT",
      "desc": "ChatGPT helps with writing, coding, brainstorming, and more.",
    },
    "hi": {
      "name": "चैटजीपीटी",
      "desc": "चैटजीपीटी लेखन, कोडिंग, विचार-विमर्श आदि में मदद करता है।",
    },
    "mr": {
      "name": "चॅटजीपीटी",
      "desc":
          "चॅटजीपीटी लेखन, कोडिंग, विचारमंथन आणि इतर गोष्टींमध्ये मदत करते.",
    },
    "es": {
      "name": "ChatGPT",
      "desc":
          "ChatGPT ayuda con escritura, codificación, lluvia de ideas y más.",
    },
    "de": {
      "name": "ChatGPT",
      "desc":
          "ChatGPT hilft beim Schreiben, Programmieren, Brainstorming und mehr.",
    },
  },
  "roamaround": {
    "en": {
      "name": "Room Around",
      "desc":
          "Room Around is a smart AI assistant for travel lovers that helps you plan lodging and organize room sharing or optimize accommodations for families and groups. Easily compare layouts, get recommendations for comfort and budget, and make the most of any trip space.",
    },
    "hi": {
      "name": "रूम अराउंड",
      "desc":
          "रूम अराउंड यात्रियों के लिए एक स्मार्ट एआई सहायक है—यह लॉजिंग, रूम शेयरिंग और पारिवारिक या सामूहिक यात्राओं के लिए स्थान का अनुकूलन करने में आपकी मदद करता है। लेआउट और बजट की तुलना करें, सर्वोत्तम अनुशंसाएँ प्राप्त करें, और हर ट्रिप को सुविधाजनक बनाएं।",
    },
    "mr": {
      "name": "रूम अराउंड",
      "desc":
          "रूम अराउंड प्रवास-प्रेमीसाठी स्मार्ट AI मदतनीस—लॉजिंग, रूम शेअरिंग व कुटुंब/मित्रांसाठी जागेचे नियोजन करण्यास मदत करा. निवासाचा सर्वोत्तम पर्याय, कंफर्ट व बजेटमध्ये तुलना, आणि प्रवासातील जागेचा अखेरपर्यंत उपयोग.",
    },
    "es": {
      "name": "Room Around",
      "desc":
          "Room Around es tu asistente inteligente de IA que organiza alojamientos, recomienda distribuciones óptimas de habitaciones y facilita compartir espacios en viajes familiares o con amigos. Compara opciones y asegura confort al mejor precio.",
    },
    "de": {
      "name": "Room Around",
      "desc":
          "Room Around ist Ihr smarter KI-Assistent für Reisende: Plant Unterkünfte, organisiert optimale Raumaufteilung für Familien oder Gruppen und gibt Empfehlungen zu Komfort und Budget – für mehr Wohlbefinden auf jeder Reise.",
    },
  },
  "VaeayChatbot": {
    "en": {
      "name": "Vaeay Chatbot",
      "desc":
          "Vaeay Chatbot is an AI-powered travel assistant that delivers instant, conversational advice for any destination. Ask about hidden gems, local dining, activities, and get real-time answers to travel questions—all in natural language.",
    },
    "hi": {
      "name": "वाएएआई चैटबोट",
      "desc":
          "वाएएआई चैटबोट एआई-पावर्ड यात्रा सहायक है—आप किसी भी डेस्टिनेशन पर छुपी हुई जगहें, लोकल फूड और एक्टिविटी, मौसम व ट्रांसपोर्ट के बारे में पूछ सकते हैं। हर सवाल का उत्तर त्वरित और अपनी भाषा में पाएं।",
    },
    "mr": {
      "name": "वाएएआय चॅटबोट",
      "desc":
          "वाएएआय चॅटबोट AI-आधारित ट्रॅव्हल सहाय्यक—स्थानीय गोष्टी, स्वादिष्ट जेवण, वेगळ्या अनुभवांविषयी विचारू शकता, वेळीच उत्तर मिळवा आणि प्रवास सुलभ करा.",
    },
    "es": {
      "name": "Vaeay Chatbot",
      "desc":
          "Vaeay Chatbot es tu asistente viajero con IA—haz preguntas sobre actividades, gastronomía o lugares secretos en cualquier destino y recibe respuestas al instante, usando lenguaje natural.",
    },
    "de": {
      "name": "Vaeay Chatbot",
      "desc":
          "Vaeay Chatbot ist der KI-basierte Reiseassistent für Soforttipps zu Sehenswürdigkeiten, Aktivitäten, Restaurants und Insiderwissen – bequem im Dialog.",
    },
  },
  "TripPlannerAI": {
    "en": {
      "name": "Trip Planner AI",
      "desc":
          "Trip Planner AI creates personalized, day-by-day itineraries for entire trips based on your interests, budget, and travel style. Includes must-see sights, offbeat spots, local food, and booking links—making organizing any journey effortless.",
    },
    "hi": {
      "name": "ट्रिप प्लानर एआई",
      "desc":
          "ट्रिप प्लानर एआई यात्रा योजना बनाने के लिए एआई का उपयोग करता है—आपकी रुचियों, बजट और ट्रेवल स्टाइल के आधार पर हर दिन आकर्षण, घूमने की जगह, भोजन और बुकिंग लिंक के साथ पूरा कार्यक्रम तैयार करता है। पूरी यात्रा ऑटोमैटिक और आसान।",
    },
    "mr": {
      "name": "ट्रिप प्लॅनर एआय",
      "desc":
          "ट्रिप प्लॅनर एआय वैयक्तिकृत प्रवास दिनक्रम तयार करतो—आवडीनिवड, बजेट व ट्रिप शैलीनुसार सर्वोत्तम आकर्षण, स्थानिक अन्न व बुकिंग लिंक देते. संपूर्ण प्रवासाचे नियोजन सहजपणे पूर्ण करा.",
    },
    "es": {
      "name": "Trip Planner IA",
      "desc":
          "Trip Planner IA genera itinerarios diarios personalizados según tus intereses, presupuesto y preferencias. Incluye sitios imperdibles, rincones poco conocidos, gastronomía local y enlaces de reserva para organizar todo el viaje sin esfuerzo.",
    },
    "de": {
      "name": "Trip Planner AI",
      "desc":
          "Trip Planner AI erstellt maßgeschneiderte Tagespläne für Ihre Reise – nach Interessen, Budget und Reisetyp. Mit Empfehlungen für Sehenswürdigkeiten, Geheimtipps, lokale Küche und Buchungslinks – Ihre komplette Reiseorganisation per KI.",
    },
  },
  "LogoCopy": {
    "en": {
      "name": "LogoCopy",
      "desc": "Create stunning logos with AI assistance."
    },
    "hi": {"name": "लोगो कॉपी", "desc": "एआई सहायता से शानदार लोगो बनाएं।"},
    "mr": {"name": "लोगो कॉपी", "desc": "AI सहाय्याने उत्कृष्ट लोगो तयार करा."},
    "es": {
      "name": "LogoCopy",
      "desc": "Crea logos impresionantes con asistencia IA."
    },
    "de": {
      "name": "LogoCopy",
      "desc": "Erstellen Sie beeindruckende Logos mit KI-Unterstützung."
    },
  },
  "LoGo": {
    "en": {"name": "LoGo", "desc": "AI-based advanced logo generator."},
    "hi": {"name": "लोगो", "desc": "एआई आधारित उन्नत लोगो जनरेटर।"},
    "mr": {"name": "लोगो", "desc": "AI आधारित प्रगत लोगो जनरेटर."},
    "es": {"name": "LoGo", "desc": "Generador de logotipos avanzado con IA."},
    "de": {"name": "LoGo", "desc": "Fortschrittlicher KI-Logogenerator."},
  },
  "LogoPony": {
    "en": {
      "name": "LogoPony",
      "desc": "Instant professional logo designs with AI."
    },
    "hi": {"name": "लोगोपोनी", "desc": "एआई से त्वरित पेशेवर लोगो डिजाइन।"},
    "mr": {
      "name": "लोगोपोनी",
      "desc": "AI द्वारे त्वरित व्यावसायिक लोगो डिझाइन."
    },
    "es": {
      "name": "LogoPony",
      "desc": "Diseños de logotipo profesional con IA al instante."
    },
    "de": {"name": "LogoPony", "desc": "Sofort professionelle Logos mit KI."},
  },
  "LogoMaker": {
    "en": {
      "name": "LogoMaker",
      "desc": "Easy logo design with smart suggestions."
    },
    "hi": {
      "name": "लोगोमेकर",
      "desc": "स्मार्ट सुझावों के साथ आसान लोगो डिज़ाइन।"
    },
    "mr": {"name": "लोगोमेकर", "desc": "स्मार्ट सूचनांसह सहज लोगो डिझाइन."},
    "es": {
      "name": "LogoMaker",
      "desc": "Diseño de logotipos fácil con sugerencias inteligentes."
    },
    "de": {
      "name": "LogoMaker",
      "desc": "Einfache Logo-Designs mit intelligenten Vorschlägen."
    },
  },
  "Microdesigner": {
    "en": {
      "name": "Microdesigner",
      "desc":
          "Microdesigner allows you to rapidly create custom graphics, icons, and illustrations with AI suggestions and automation.",
    },
    "hi": {
      "name": "Microdesigner",
      "desc":
          "Microdesigner AI से आप आइकन, ग्राफिक्स व चित्र जल्दी बना सकते हैं।",
    },
    "mr": {
      "name": "Microdesigner",
      "desc": "Microdesigner AI सह जलद ग्राफिक्स, आयकॉन्स व चित्रे बनवा.",
    },
    "es": {
      "name": "Microdesigner",
      "desc":
          "Microdesigner crea gráficos y artes rápidos con IA y automatización.",
    },
    "de": {
      "name": "Microdesigner",
      "desc":
          "Microdesigner erstellt Grafiken und Illustrationen zügig per KI.",
    },
  },
  "Nisme": {
    "en": {
      "name": "Nisme",
      "desc":
          "Nisme delivers AI-powered, personalized graphic style and content suggestions to match your visual identity.",
    },
    "hi": {
      "name": "Nisme",
      "desc": "Nisme AI से ब्रांड के मुताबिक ग्राफिक सुझाव प्राप्त करें।",
    },
    "mr": {
      "name": "Nisme",
      "desc": "Nisme हे AI आधारित वैयक्तिक डिझाईन सल्ला देते.",
    },
    "es": {
      "name": "Nisme",
      "desc": "Nisme aporta sugerencias gráficas IA acorde a tu marca.",
    },
    "de": {
      "name": "Nisme",
      "desc": "Nisme macht KI-Designvorschläge individuell nach Markenstil.",
    },
  },
  "DesignAI": {
    "en": {
      "name": "DesignAI",
      "desc":
          "DesignAI is a complete AI creative suite for designing logos, videos, and marketing graphics automatically.",
    },
    "hi": {
      "name": "DesignAI",
      "desc":
          "DesignAI सम्पूर्ण ग्राफिक डिज़ाइन व वीडियो सूट—AI द्वारा ऑटोमेटेड बनाएं।",
    },
    "mr": {
      "name": "DesignAI",
      "desc":
          "DesignAI हे सर्वसमावेशक AI डिझाईन साधन आहे—लोगो, ग्राफिक्स, व्हिडिओ सबंधित.",
    },
    "es": {
      "name": "DesignAI",
      "desc":
          "DesignAI es suite IA para logos, videos y gráficos promocionales automáticos.",
    },
    "de": {
      "name": "DesignAI",
      "desc":
          "DesignAI erstellt automatisch Logos, Videos & Marketing-Grafiken per KI.",
    },
  },
  "OpenArtAI": {
    "en": {
      "name": "OpenArtAI",
      "desc":
          "OpenArtAI generates creative digital art, illustrations, and concept graphics from prompts using AI.",
    },
    "hi": {
      "name": "OpenArtAI",
      "desc":
          "OpenArtAI: कला व चित्रण के लिए AI जनरेटर, टेक्स्ट से विजुअल्स बनाएं।",
    },
    "mr": {
      "name": "OpenArtAI",
      "desc": "OpenArtAI हे AI वरून प्रेरित कला व चित्रणासाठी जनरेटर आहे.",
    },
    "es": {
      "name": "OpenArtAI",
      "desc":
          "OpenArtAI genera arte digital e ilustraciones desde texto y estilos IA.",
    },
    "de": {
      "name": "OpenArtAI",
      "desc":
          "OpenArtAI erstellt digitale Kunst & Illustrationen aus Textvorgaben durch KI.",
    },
  },
  "Gamma": {
    "en": {
      "name": "Gamma",
      "desc":
          "Gamma lets you quickly generate beautiful, modern presentations with structured templates and creative AI slide creation features. Collaborate easily and share dynamic decks online.",
    },
    "hi": {
      "name": "गामा",
      "desc":
          "गामा के साथ आप सुंदर, आधुनिक प्रेजेंटेशन एआई की मदद से जल्दी बना सकते हैं। इसमें तैयार टेम्प्लेट्स, रचनात्मक स्लाइड्स और सहयोग हेतु आसान विकल्प हैं।",
    },
    "mr": {
      "name": "गॅमा",
      "desc":
          "गॅमा वापरून आपल्याला एआयसह आकर्षक, डिझायन केलेली प्रेझेंटेशन लवकर तयार करता येतात. सहज सहकार्य, टेम्प्लेट्स आणि सर्जनशील स्लाईड्स.",
    },
    "kn": {
      "name": "ಗ್ಯಾಮಾ",
      "desc":
          "ಗ್ಯಾಮಾ ಬಳಸಿಕೊಂಡು ಆಕರ್ಷಕ ಪ್ರೆಸೆಂಟೇಶನ್‌ಗಳನ್ನು ಎಐ ಮೂಲಕ ಬೇಗ ನಿರ್ವಹಿಸಿ. ತೆಲೆಯಲ್ಲಿ ಟೆಂಪ್ಲೆಟ್‌ಗಳು, ಗೊತ್ತುಪಡಿಸುವುದಕ್ಕೆ ಸುಲಭವಾದ ಆಯ್ಕೆಗಳು.",
    },
    "de": {
      "name": "Gamma",
      "desc":
          "Gamma ermöglicht KI-gestützte, beeindruckende Präsentationen in wenigen Minuten. Moderne Vorlagen, intuitive Bearbeitung und einfache Zusammenarbeit.",
    },
  },
  "TomeAI": {
    "en": {
      "name": "Tome AI",
      "desc":
          "Tome AI leverages generative AI to help you tell compelling stories: automatically create slides, images, and structured narratives for pitches, reports, or portfolios in a visually engaging way.",
    },
    "hi": {
      "name": "टोम एआई",
      "desc":
          "टोम एआई जनरेटिव एआई की मदद से स्टोरी प्रजेंटेशन, पिच, रिपोर्ट और पोर्टफोलियो कुछ ही मिनटों में सुंदर स्लाइड्स के साथ तैयार करता है।",
    },
    "mr": {
      "name": "टोम AI",
      "desc":
          "टोम AI तुमच्यासाठी सुंदर आणि आकर्षक कथा, पिच किंवा रिपोर्ट्स काही मिनिटांत एआयसह तयार करते.",
    },
    "kn": {
      "name": "ಟೋಮ್ ಎಐ",
      "desc":
          "ಟೋಮ್ ಎಐ ನಿಮ್ಮ ಕಥನವನ್ನು ಎಐ ಬಳಸಿಕೊಂಡು ಸ್ನಾಯುಮಯ ಪ್ರೆಸೆಂಟೇಶನ್ನಾಗಿ ರೂಪಿಸುತ್ತದೆ. ವೈಶಿಷ್ಟ್ಯಪೂರ್ಣ ಸ್ಲೈಡ್‌ಗಳು ಮತ್ತು ಕಥಾವಸ್ತು ರೂಪಣೆ.",
    },
    "de": {
      "name": "Tome AI",
      "desc":
          "Tome AI generiert mit KI ganze Präsentationsgeschichten: Von der Idee bis zu vollständig gestalteten Slides – perfekt für Pitches und Berichte.",
    },
  },
  "DecktopusAT": {
    "en": {
      "name": "Decktopus AT",
      "desc":
          "Decktopus AT is an AI assistant for building professional slide decks effortlessly. Just provide your topic and details; Decktopus will generate text, suggest layouts, and automate the design process.",
    },
    "hi": {
      "name": "डेकटोपस एटी",
      "desc":
          "डेकटोपस एटी एक एआई-सहायक है, जो प्रेजेंटेशन के लिए सामग्री, डिजाइन व ऑटोमेशन ओटोमेटिक बना देता है।",
    },
    "mr": {
      "name": "डेकटोपस एटी",
      "desc":
          "डेकटोपस एटी सह निःसंशय व्यावसायिक स्लाइड डेक, एआयसह ऑटोमॅटिक तयार करा. फक्त टोपिक द्या — सर्व डिझाईन मिळवा.",
    },
    "es": {
      "name": "ಡೆಕ್ಟೋಪಸ್ ಎಟಿ",
      "desc":
          "ಡೆಕ್ಟೋಪಸ್ ಎಟಿ ಸ್ಲೈಡ್ ಡೆಕ್‌ಗಳನ್ನು ಸುಲಭವಾಗಿ ಎಐ ಮೂಲಕ ರಚಿಸುತ್ತದೆ. ವಿಷಯ ಮತ್ತು ವಿವರ ನೀಡಿ, ವಿನ್ಯಾಸಗಳನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಪಡೆಯಿರಿ.",
    },
    "de": {
      "name": "Decktopus AT",
      "desc":
          "Decktopus AT erstellt mit KI professionelle Slide Decks: Geben Sie das Thema ein, und alles andere – Inhalt, Layout, Design – geht automatisch.",
    },
  },
  "Perplexity.": {
    "en": {
      "name": "Perplexity",
      "desc":
          "Perplexity delivers instant, accurate research, structured answers, and sourced Q&A—great for finding facts, stats, and summaries with citations for your slides.",
    },
    "hi": {
      "name": "पर्प्लेक्सिटी",
      "desc":
          "पर्प्लेक्सिटी देता है अनुच्छेद, ताज़ा फैक्ट्स और रिफरेंस के साथ रिसर्च, जिससे प्रेजेंटेशन Q&A और डेटा तैयार करना आसान है।",
    },
    "mr": {
      "name": "पर्प्लेक्सिटी",
      "desc":
          "पर्प्लेक्सिटी शोध, शंका निरसन, आणि संदर्भांसह माहिती पटकन शोधते—प्रेझेंटेशनसाठी विश्वसनीय डेटा मिळवा.",
    },
    "kn": {
      "name": "ಪರ್ಪ್ಲೆಕ್ಸಿಟಿ",
      "desc":
          "ಪರ್ಪ್ಲೆಕ್ಸಿಟಿ ಎಐ ಮೂಲಕ ನಿಖರವಾದ ಉತ್ತರ ಮತ್ತು ಉಲ್ಲೇಖ ಸಹಿತ ಸಂಶೋಧನೆ ನೀಡುತ್ತದೆ. ಪ್ರೆಸೆಂಟೇಶನ್‌ನಲ್ಲಿ ಸ್ಪಷ್ಟ ಉತ್ತರಗಳು.",
    },
    "de": {
      "name": "Perplexity",
      "desc":
          "Perplexity liefert sofortige, nachvollziehbare Antworten und Fakten aus geprüften Quellen – ideal zur Recherche für Präsentationen.",
    },
  },
  "Gemini": {
    "en": {
      "name": "Gemini",
      "desc":
          "Gemini is Google's conversational AI that generates text, summaries, slide suggestions, and creative ideas for presentations, brainstorms, and more.",
    },
    "hi": {
      "name": "जेमिनी",
      "desc":
          "जेमिनी गूगल का एआई चैट सहायक है, जो प्रेजेंटेशन, विचार-विमर्श और रचनात्मक कंटेंट के लिए सुझाव, स्लाइड्स और संक्षेप देता है।",
    },
    "mr": {
      "name": "जेमिनी",
      "desc":
          "गूगलचा जेमिनी AI ब्रेनस्टॉर्म, प्रेझेंटेशन आयडिया व टेक्स्ट सजेस्ट करतो.",
    },
    "kn": {
      "name": "ಜೆಮಿನಿ",
      "desc":
          "Google Gemini ನಿಮ್ಮ ಪ್ರೆಸೆಂಟೇಶನ್‌ಗೆ ಐಡಿಯಾ, ಅನ್ನುಸಾಧನೆ ಮತ್ತು ಸ್ಲೈಡ್ ಸಲಹೆಗಳನ್ನು ಎಐ ಮೂಲಕ ನೀಡುತ್ತದೆ.",
    },
    "de": {
      "name": "Gemini",
      "desc":
          "Gemini ist Googles KI-Assistent für Präsentationen, Ideenfindung, Text und Zusammenfassungen.",
    },
  },
  "Canva": {
    "en": {
      "name": "Canva",
      "desc":
          "Canva lets you create and customize presentations using intuitive, drag-and-drop AI tools for writing, layout, graphics, and instant design suggestions.",
    },
    "hi": {
      "name": "कैनवा",
      "desc":
          "कैनवा के AI टूल्स से लिखें, डिज़ाइन करें व सुंदर प्रेजेंटेशन स्वयं बनाएं — ड्रैग एंड ड्रॉप व ग्राफिक्स सहित।",
    },
    "mr": {
      "name": "कॅनव्हा",
      "desc":
          "कॅनव्हा वापरून सहजपणे AI साधनांच्या मदतीने सुंदर सादरीकरण तयार करा, लेआउट, ग्राफिक्स व सजेशनसह.",
    },
    "kn": {
      "name": "ಕ್ಯಾನ್ವಾ",
      "desc":
          "ಕ್ಯಾನ್ವಾ ಹೊಸ AI ಫೀಚರ್ಸ್‌ನೊಂದಿಗೆ ಬರವಣಿಗೆ, ವಿನ್ಯಾಸ, ಗ್ರಾಫಿಕ್ಸ್—all-in-one ಡ್ರ್ಯಾಗ್-ಡ್ರಾಪ್ ಪ್ರೆಸೆಂಟೇಶನ್ ರಚನೆ.",
    },
    "de": {
      "name": "Canva",
      "desc":
          ".Canva ist eine All-in-One-Designsuite: Präsentationen mit KI-gestütztem Schreiben, Layout und kreativen Vorlagen – einfach per Drag&Drop.",
    },
    "es": {
      "name": "Canva",
      "desc":
          "Crea presentaciones con funciones de IA para escritura, diseño y gráficos—todo en una plataforma drag-and-drop.",
    },
  },
  "ComposerTrade": {
    "en": {
      "name": "Composer.trade",
      "desc":
          "Discover, build, and automate sophisticated algorithmic trading strategies using AI, with an intuitive no-code interface. Perfect for investors wanting to harness AI-driven decision-making without programming.",
    },
    "hi": {
      "name": "Composer.trade",
      "desc":
          "AI की मदद से परिष्कृत अल्गोरिदमिक ट्रेडिंग रणनीतियां खोजें, बनाएं और ऑटोमेट करें, बिना कोडिंग के। निवेशकों के लिए आदर्श जो AI आधारित निर्णय लेना चाहते हैं।",
    },
    "mr": {
      "name": "Composer.trade",
      "desc":
          "AI च्या मदतीने गुंतागुंतीच्या अल्गोरिदमिक ट्रेडिंग स्ट्रॅटेजी शोधा, तयार करा आणि कोडिंगशिवाय ऑटोमेशन करा. गुंतवणूकदारांसाठी आदर्श जे AI निर्णयक्षमतेचा वापर करू इच्छितात.",
    },
    "es": {
      "name": "Composer.trade",
      "desc":
          "Descubra, construya y automatice estrategias sofisticadas de trading algorítmico con IA, mediante una interfaz intuitiva sin código. Ideal para inversores que buscan aprovechar la toma de decisiones impulsada por IA sin programar.",
    },
    "de": {
      "name": "Composer.trade",
      "desc":
          "Entdecken, entwickeln und automatisieren Sie anspruchsvolle algorithmische Handelsstrategien mit KI über eine intuitive No-Code-Oberfläche. Perfekt für Investoren, die KI-gesteuerte Entscheidungen ohne Programmierkenntnisse nutzen möchten.",
    },
  },
  "TradeIdeas": {
    "en": {
      "name": "Trade Ideas",
      "desc":
          "Real-time AI-powered market analytics delivering actionable stock ideas and automated trade suggestions for investors. Includes live scanning, risk management tools, and predictive insights to maximize trading performance.",
    },
    "hi": {
      "name": "Trade Ideas",
      "desc":
          "रीयल-टाइम AI संचालित मार्केट एनालिटिक्स जो निवेशकों के लिए स्टॉक आइडिया और ऑटोमेटेड ट्रेड सुझाव प्रदान करता है। इसमें लाइव स्कैनिंग, जोखिम प्रबंधन उपकरण और पूर्वानुमान शामिल हैं।",
    },
    "mr": {
      "name": "Trade Ideas",
      "desc":
          "रिअल-टाइम AI चालित मार्केट विश्लेषण, ज्यामध्ये गुंतवणूकदारांसाठी कृत्ययोग्य स्टॉक आयडिया आणि स्वयंचलित ट्रेड सूचना असतात. यात थेट स्कॅनिंग, धोका व्यवस्थापन साधने आणि भाकीत समजुणी समाविष्ट आहेत.",
    },
    "es": {
      "name": "Trade Ideas",
      "desc":
          "Análisis de mercado en tiempo real potenciado por IA que ofrece ideas accionables de acciones y sugerencias automáticas de trading para inversores. Incluye escaneo en vivo, herramientas de gestión de riesgos y predicciones para maximizar el rendimiento.",
    },
    "de": {
      "name": "Trade Ideas",
      "desc":
          "Echtzeit-KI-Marktanalyse mit umsetzbaren Aktienideen und automatischen Handelsempfehlungen für Investoren. Enthält Live-Scanning, Risikomanagement-Tools und Prognosefunktionen zur Maximierung der Handelsleistung.",
    },
  },
  "Sigmoidal": {
    "en": {
      "name": "Sigmoidal",
      "desc":
          "Build, backtest, and deploy AI-based trading models with comprehensive performance analytics. Supports strategy optimization, risk assessment, and integration with multiple trading platforms for robust algorithmic trading.",
    },
    "hi": {
      "name": "सिग्मोइडल",
      "desc":
          "AI आधारित ट्रेडिंग मॉडल बनाएं, उनका बैकटेस्ट करें और विस्तृत प्रदर्शन विश्लेषण के साथ इन्हें लागू करें। रणनीति अनुकूलन, जोखिम मूल्यांकन और कई ट्रेडिंग प्लेटफ़ॉर्म के साथ एकीकरण का समर्थन करता है।",
    },
    "mr": {
      "name": "सिग्मोइडल",
      "desc":
          "AI-आधारित ट्रेडिंग मॉडेल तयार करा, बॅकटेस्ट करा आणि व्यापक परफॉर्मन्स विश्लेषणासह तैनात करा. स्ट्रॅटेजी ऑप्टिमायझेशन, धोका मूल्यमापन आणि अनेक ट्रेडिंग प्लॅटफॉर्मशी एकत्रीकरण यांना समर्थन देते.",
    },
    "es": {
      "name": "Sigmoidal",
      "desc":
          "Construya, pruebe y despliegue modelos de trading basados en IA con análisis de rendimiento completos. Soporta optimización de estrategias, evaluación de riesgos e integración con múltiples plataformas de trading.",
    },
    "de": {
      "name": "Sigmoidal",
      "desc":
          "Erstellen, testen und implementieren Sie KI-basierte Handelsmodelle mit umfassender Leistungsanalyse. Unterstützt Strategieoptimierung, Risikobewertung und Integration mit verschiedenen Handelsplattformen für robusten algorithmischen Handel.",
    },
  },
  "Eginbot": {
    "en": {
      "name": "Eginbot",
      "desc":
          "Complete AI-driven automation of stock trading workflows including scheduling, execution, and monitoring. Provides actionable AI insights and alerts, enabling traders to optimize performance and reduce manual workload.",
    },
    "hi": {
      "name": "ईगिनबॉट",
      "desc":
          "स्टॉक ट्रेडिंग वर्कफ़्लो के पूर्ण AI-आधारित स्वचालन में शेड्यूलिंग, निष्पादन और निगरानी शामिल है। व्यावहारिक AI अंतर्दृष्टि और अलर्ट प्रदान करता है जिससे ट्रेडर्स प्रदर्शन सुधार सकते हैं।",
    },
    "mr": {
      "name": "ईगिनबॉट",
      "desc":
          "शेअर ट्रेडिंग वर्कफ्लोचे पूर्ण AI-आधारित स्वयंचलन जे शेड्यूलिंग, कार्यान्वयन आणि देखरेख यांचा समावेश करते. व्यावहारिक AI अंतर्दृष्टी व सूचना देऊन ट्रेडर्सना कामकाज सुधारण्यास मदत करते.",
    },
    "es": {
      "name": "Eginbot",
      "desc":
          "Automatización completa impulsada por IA de los flujos de trabajo de trading de acciones, incluida la programación, ejecución y monitoreo. Ofrece alertas y conocimientos prácticos para optimizar el rendimiento y reducir la carga manual.",
    },
    "de": {
      "name": "Eginbot",
      "desc":
          "Vollständige KI-gesteuerte Automatisierung von Aktienhandelsabläufen, einschließlich Planung, Ausführung und Überwachung. Bietet umsetzbare KI-Einblicke und Warnungen zur Leistungsoptimierung und Reduzierung manueller Arbeit.",
    },
  },
  "Visenze": {
    "en": {
      "name": "Visenze",
      "desc":
          "AI-powered visual search and product discovery platform for e-commerce, enabling shoppers to find products through images, attributes, and style recognition. Helps increase conversion rates by simplifying product search and improving user experience.",
    },
    "hi": {
      "name": "विजनज़े",
      "desc":
          "ई-कॉमर्स के लिए एआई संचालित विजुअल सर्च और उत्पाद खोज मंच, जो ग्राहकों को तस्वीरों, गुणों और स्टाइल पहचान के माध्यम से उत्पाद खोजने में सक्षम बनाता है। उत्पाद खोज को आसान बनाकर रूपांतरण दर बढ़ाता है।",
    },
    "mr": {
      "name": "विजनझे",
      "desc":
          "ई-कॉमर्ससाठी AI आधारित व्हिज्युअल सर्च व उत्पादन शोध प्लॅटफॉर्म, जे वापरकर्त्यांना फोटो, वैशिष्ट्ये व स्टाईल ओळखीने उत्पादन शोधण्यास मदत करते. वापरकर्ता अनुभव सुधारून विक्री वाढवते.",
    },
    "es": {
      "name": "Visenze",
      "desc":
          "Plataforma de búsqueda visual y descubrimiento de productos potenciada por IA para e-commerce, que permite a los compradores encontrar productos mediante imágenes, atributos y reconocimiento de estilo. Mejora la tasa de conversión simplificando las búsquedas.",
    },
    "de": {
      "name": "Visenze",
      "desc":
          "KI-gestützte visuelle Suche und Produktentdeckungsplattform für E-Commerce, die es Käufern ermöglicht, Produkte über Bilder, Attribute und Stilerkennung zu finden. Verbessert die Konversionsrate durch Vereinfachung der Produktsuche.",
    },
  },
  "BlueShift": {
    "en": {
      "name": "Blue Shift",
      "desc":
          "AI-driven customer engagement and multichannel marketing automation platform that helps brands target the right audience, personalize communications, and optimize retention. Includes predictive analytics and seamless integration with marketing channels.",
    },
    "hi": {
      "name": "ब्लू शिफ्ट",
      "desc":
          "एआई संचालित ग्राहक जुड़ाव और मल्टीचैनल मार्केटिंग ऑटोमेशन प्लेटफ़ॉर्म, जो ब्रांड्स को सही लक्षित करने, संचार को वैयक्तिकृत करने और ग्राहक बनाए रखने में मदद करता है। भविष्यवाणी विश्लेषण और चैनल इंटीग्रेशन शामिल हैं।",
    },
    "mr": {
      "name": "ब्लू शिफ्ट",
      "desc":
          "AI-चालित ग्राहक संलग्नता व बहु-चॅनेल मार्केटिंग ऑटोमेशन प्लॅटफॉर्म, जो ब्रॅण्डना योग्य प्रेक्षक लक्ष्य करण्यास, संवाद वैयक्तीकरणासाठी आणि राखण सुधारण्यासाठी मदत करते. भविष्यवाणी विश्लेषण आणि चॅनेल समाकलन यासह.",
    },
    "es": {
      "name": "Blue Shift",
      "desc":
          "Plataforma de automatización de marketing multicanal impulsada por IA que ayuda a las marcas a dirigirse al público adecuado, personalizar comunicaciones y optimizar la retención. Incluye analíticas predictivas e integración fluida con canales.",
    },
    "de": {
      "name": "Blue Shift",
      "desc":
          "KI-gesteuerte Plattform für Kundenbindung und Multichannel-Marketingautomatisierung, mit der Marken die Zielgruppen erreichen, Kommunikation personalisieren und Kundenbindung optimieren können. Beinhaltet Predictive Analytics und Channel-Integration.",
    },
  },
  "LivePerson": {
    "en": {
      "name": "LivePerson",
      "desc":
          "Conversational AI and messaging platform delivering real-time customer support, chatbot automation, and personalized engagement. Enables brands to scale interactions, automate routine queries, and provide human-like assistance across multiple channels.",
    },
    "hi": {
      "name": "लाइवपर्सन",
      "desc":
          "संवादी एआई और मैसेजिंग प्लेटफ़ॉर्म, जो त्वरित ग्राहक सहायता, चैटबॉट ऑटोमेशन और वैयक्तिकृत जुड़ाव प्रदान करता है। ब्रांड्स को व्यापक स्तर पर बातचीत करने, नियमित प्रश्नों को स्वचालित करने और विभिन्न चैनलों पर मानव-समान सहायता देने में सक्षम बनाता है।",
    },
    "mr": {
      "name": "लाइव्हपर्सन",
      "desc":
          "संवादी AI आणि मेसेजिंग प्लॅटफॉर्म, जो रिअल-टाइम ग्राहक सेवा, बॉट्स स्वयंचलन आणि वैयक्तिकृत संवाद देतो. ब्रँडना मोठ्या प्रमाणावर संवाद साधणे, नियमित प्रश्नांचे स्वयंचलन आणि विभिन्न चॅनेलवर मानवीसारखी मदत पुरवणे शक्य करते.",
    },
    "es": {
      "name": "LivePerson",
      "desc":
          "Plataforma de IA conversacional y mensajería para soporte al cliente en tiempo real, automatización de chatbots y participación personalizada. Permite a las marcas escalar interacciones, automatizar consultas rutinarias y brindar asistencia humana en múltiples canales.",
    },
    "de": {
      "name": "LivePerson",
      "desc":
          "Konversations-KI- und Messaging-Plattform für Echtzeit-Kundensupport, Chatbot-Automatisierung und personalisierte Kundenbindung. Ermöglicht Marken die Skalierung von Interaktionen, Automatisierung von Routineanfragen und menschenähnliche Unterstützung über mehrere Kanäle.",
    },
  },
  "ClerkIO": {
    "en": {
      "name": "Clerk.io",
      "desc":
          "AI-powered engine for personalized product recommendations, search optimization, and dynamic e-commerce experiences. Helps merchants increase sales through customized customer journeys, cross-sell suggestions, and real-time analytics.",
    },
    "hi": {
      "name": "क्लर्क.आईओ",
      "desc":
          "वैयक्तिकृत उत्पाद सिफारिशें, खोज अनुकूलन और गतिशील ई-कॉमर्स अनुभव के लिए AI संचालित इंजन। कस्टम ग्राहक यात्राओं, क्रॉस-सेल सुझावों और रीयल-टाइम एनालिटिक्स के माध्यम से बिक्री बढ़ाने में मदद करता है।",
    },
    "mr": {
      "name": "क्लर्क.आयो",
      "desc":
          "वैयक्तिकृत उत्पादन शिफारसी, शोध ऑप्टिमायझेशन आणि गतिशील ई-कॉमर्स अनुभवासाठी AI-सहाय्यक इंजिन. विक्रेत्यांना सानुकूल ग्राहक प्रवास, क्रॉस-सेल सूचना आणि रिअल-टाइम अॅनालिटिक्सद्वारे विक्री वाढवण्यासाठी मदत करते.",
    },
    "es": {
      "name": "Clerk.io",
      "desc":
          "Motor impulsado por IA para recomendaciones personalizadas de productos, optimización de búsqueda y experiencias dinámicas de comercio electrónico. Ayuda a aumentar ventas mediante journeys personalizados, sugerencias cruzadas y análisis en tiempo real.",
    },
    "de": {
      "name": "Clerk.io",
      "desc":
          "KI-gestützte Engine für personalisierte Produktempfehlungen, Suchoptimierung und dynamische E-Commerce-Erlebnisse. Hilft Händlern, den Umsatz durch individuelle Kundenreisen, Cross-Selling-Vorschläge und Echtzeitanalysen zu steigern.",
    },
  },
  "Style": {
    "en": {
      "name": "Style AI",
      "desc":
          "Advanced AI-powered style and fashion recommendation platform offering personalized outfit suggestions, trend analysis, and customized shopping experiences tailored to individual preferences and body types.",
    },
    "hi": {
      "name": "स्टाइल एआई",
      "desc":
          "एवीanced AI संचालित स्टाइल और फैशन सिफारिश प्लेटफ़ॉर्म, जो व्यक्तिगत रूचि और शरीर के प्रकार के अनुसार आउटफिट सुझाव, ट्रेंड विश्लेषण और कस्टम शॉपिंग अनुभव प्रदान करता है।",
    },
    "mr": {
      "name": "स्टाईल एआय",
      "desc":
          "उन्नत AI आधारित स्टाईल व फॅशन शिफारस प्लॅटफॉर्म, जो वैयक्तिक पसंती व शरीर प्रकारानुसार सानुकूल आउटफिट सूचना, ट्रेंड विश्लेषण व खरेदी अनुभव देतो.",
    },
    "es": {
      "name": "Style IA",
      "desc":
          "Plataforma avanzada de recomendaciones de estilo y moda impulsada por IA que ofrece sugerencias de atuendos personalizados, análisis de tendencias y experiencias de compra adaptadas a preferencias y tipos de cuerpo individuales.",
    },
    "de": {
      "name": "Style AI",
      "desc":
          "Fortschrittliche KI-basierte Plattform für Stil- und Modeempfehlungen mit personalisierten Outfitvorschlägen, Trendanalysen und maßgeschneiderten Einkaufserlebnissen, angepasst an individuelle Vorlieben und Körpertypen.",
    },
  },
  "TheNewBluilk": {
    "en": {
      "name": "The NewBluilk",
      "desc":
          "The NewBluilk is your personal AI-powered journaling guide to help you uncover, nurture, and organize your life’s passions. It provides mood tracking, personalized daily reflection prompts, motivational insights, habit-building tools, and thematic journaling challenges—ideal for self-growth and boosting creativity.",
    },
    "hi": {
      "name": "द न्यूब्ल्यूल्क",
      "desc":
          "द न्यूब्ल्यूल्क आपका निजी एआई-संचालित जर्नलिंग पार्टनर है, जो आपके शौक और जुनून को पहचानने, nurture करने और व्यवस्थित रखने में मदद करता है। इसमें है मूड ट्रैकिंग, व्यक्तिगत डेली प्रॉम्प्ट्स, प्रेरक सुझाव, आदत बनाने के टूल्स, और थीम आधारित जर्नलिंग चैलेंजेस—आत्म-विकास और रचनात्मकता के लिए आदर्श।",
    },
    "mr": {
      "name": "द न्यूब्ल्यूल्क",
      "desc":
          "द न्यूब्ल्यूल्क हे तुमचे वैयक्तिक AI जर्नलिंग गाइड, जे तुमच्या छंद-आवडी ओळखण्यात, त्यांचा विकास करण्यात व आयुष्याचे क्षण टिपण्यात मदत करते. मूड ट्रॅकिंग, वैयक्तिक रोजची प्रेरणा, सर्जनशीलता वाढवणारे सल्ले, सवयी घडवणारी साधने व थीमॅटिक जर्नलिंग challenges यात मिळतात.",
    },
    "es": {
      "name": "The NewBluilk",
      "desc":
          "The NewBluilk es tu guía de diario personal con IA para descubrir, fomentar y organizar tus pasiones y talentos. Incluye seguimiento emocional, reflexiones diarias personalizadas, retos temáticos, herramientas para crear hábitos y consejos motivacionales—perfecto para el crecimiento interior y la inspiración.",
    },
    "de": {
      "name": "The NewBluilk",
      "desc":
          "The NewBluilk ist dein KI-gestützter Tagebuchbegleiter zur Entfaltung und Dokumentation deiner Leidenschaften. Mit Stimmungstracking, täglichen Journalimpulsen, Motivations-Tipps, Habit-Tracking und thematischen Challenges für mehr Selbstreflexion und Kreativität.",
    },
  },
  "AlbdO": {
    "en": {
      "name": "AlbdO",
      "desc":
          "AlbdO is an advanced AI platform designed to spark your creativity: receive tailored writing prompts for fiction, poetry, or essays, generate new story concepts with just a click, explore visual art themes, and get creative suggestions to overcome writer’s block and inspire artistic projects.",
    },
    "hi": {
      "name": "अलब्डो",
      "desc":
          "अलब्डो एक एआई प्लेटफ़ॉर्म है जो आपकी रचनात्मकता को जगाता है: इसमें आपके लिए गद्य, कविता या कहानी के लिए कस्टम प्रॉम्प्ट्स, एक क्लिक में नई कहानी-विचार, चित्रकला थीम और लेखन ब्लॉक दूर करने के लिए रचनात्मक सुझाव शामिल हैं।",
    },
    "mr": {
      "name": "अलब्डो",
      "desc":
          "अलब्डो हा प्रगत AI प्लॅटफॉर्म आहे—गद्य, कथा किंवा कविता लेखनासाठी वैयक्तिक संकल्पना, नवीन कथानक क्लिकवर मिळवा, चित्रकला थीम आणि सर्जनशील अडथळे दूर करतील असे सुचवणारे प्रेरक संकेत साहित्य मिळवा.",
    },
    "es": {
      "name": "AlbdO",
      "desc":
          "AlbdO es una plataforma avanzada de IA para despertar tu creatividad: recibe sugerencias personalizadas para cuentos, poesía o ensayos, genera nuevas ideas de historias al instante, explora temas para arte visual y disfruta de recursos para superar bloqueos creativos.",
    },
    "de": {
      "name": "AlbdO",
      "desc":
          "AlbdO ist eine fortschrittliche KI-Plattform für kreative Inspiration: maßgeschneiderte Schreibanregungen für Prosa, Lyrik oder Geschichten, neue Story-Ideen auf Knopfdruck, künstlerische Themen für Grafik sowie Inspiration gegen Schreibblockaden.",
    },
  },
  "SuperAI": {
    "en": {
      "name": "SuperAI",
      "desc": "SuperAI boosts your productivity with smart automation.",
    },
    "hi": {
      "name": "सुपरएआई",
      "desc": "सुपरएआई स्मार्ट ऑटोमेशन के साथ आपकी उत्पादकता बढ़ाता है।",
    },
    "mr": {
      "name": "सुपरएआई",
      "desc": "सुपरएआई स्मार्ट ऑटोमेशनसह तुमची उत्पादकता वाढवतो.",
    },
    "es": {
      "name": "SuperAI",
      "desc":
          "SuperAI aumenta tu productividad con automatización inteligente.",
    },
    "de": {
      "name": "SuperAI",
      "desc":
          "SuperAI steigert Ihre Produktivität durch smarte Automatisierung.",
    },
  },
  "Midjourney": {
    "en": {
      "name": "Midjourney",
      "desc": "Midjourney creates stunning images from text prompts.",
    },
    "hi": {
      "name": "मिडजर्नी",
      "desc": "मिडजर्नी टेक्स्ट प्रॉम्प्ट से शानदार चित्र बनाता है।",
    },
    "mr": {
      "name": "मिडजर्नी",
      "desc": "मिडजर्नी मजकूर संकेतांपासून अप्रतिम चित्रे तयार करते.",
    },
    "es": {
      "name": "Midjourney",
      "desc": "Midjourney crea imágenes impresionantes a partir de textos.",
    },
    "de": {
      "name": "Midjourney",
      "desc": "Midjourney erstellt beeindruckende Bilder aus Textvorgaben.",
    },
  },
  "Resume.io": {
    "en": {
      "name": "Resume.io",
      "desc":
          "Generate professional resumes with AI suggestions and templates.",
    },
    "hi": {
      "name": "रिज़्यूमे.io",
      "desc": "एआई सुझाव और टेम्पलेट्स के साथ पेशेवर रिज़्यूमे बनाएं।",
    },
    "mr": {
      "name": "रिझ्युमे.io",
      "desc": "AI सूचनांसह आणि टेम्पलेट्ससह व्यावसायिक रिझ्युमे तयार करा.",
    },
    "es": {
      "name": "Resume.io",
      "desc": "Genere currículums profesionales con IA y plantillas.",
    },
    "de": {
      "name": "Resume.io",
      "desc":
          "Erstellen Sie professionelle Lebensläufe mit KI-Vorschlägen und Vorlagen.",
    },
  },
  "GitHub Copilot": {
    "en": {
      "name": "GitHub Copilot",
      "desc":
          "Copilot helps write code, suggests completions, and automates repetitive tasks.",
    },
    "hi": {
      "name": "गिटहब कोपायलट",
      "desc":
          "कोपायलट कोड लिखने, सुझाव देने और दोहराए जाने वाले कार्यों को स्वचालित करने में मदद करता है।",
    },
    "mr": {
      "name": "गिटहब कोपायलट",
      "desc":
          "कोपायलट कोड लिहिण्यात, सुचवण्यात आणि पुनरावृत्ती कार्ये स्वयंचलित करण्यात मदत करते.",
    },
    "es": {
      "name": "GitHub Copilot",
      "desc":
          "Copilot ayuda a escribir código, sugiere completaciones y automatiza tareas repetitivas.",
    },
    "de": {
      "name": "GitHub Copilot",
      "desc":
          "Copilot hilft beim Schreiben von Code, schlägt Vervollständigungen vor und automatisiert wiederkehrende Aufgaben.",
    },
  },
  "SheetAI": {
    "en": {
      "name": "SheetAI",
      "desc":
          "SheetAI lets you generate, auto-edit, and manage spreadsheet workflows and sprite sheets with AI; fast for analytics, assets, and exporting designs.",
    },
    "hi": {
      "name": "SheetAI",
      "desc":
          "SheetAI एआई के साथ शीट या स्प्राइट्स जल्दी बनाएं, एडिट करें और डिजाइन या डेटा को आसानी से मैनेज करें।",
    },
    "mr": {
      "name": "SheetAI",
      "desc":
          "SheetAI हे AI आधारित स्प्रेडशीट व स्प्राइट शीट तयार, संपादित व व्यवस्थापित करणारे साधन आहे.",
    },
    "es": {
      "name": "SheetAI",
      "desc":
          "SheetAI automatiza hojas de cálculo y hojas de sprites con IA: crea, edita y gestiona datos y assets.",
    },
    "de": {
      "name": "SheetAI",
      "desc":
          "SheetAI erstellt & bearbeitet Tabellen und Sprite-Sheets automatisch mit KI – für Daten & Design.",
    },
  },
  "CoefficientsAI": {
    "en": {
      "name": "Coefficients AI",
      "desc":
          "Coefficients AI brings AI automations and smart formulas to spreadsheets—auto-fill, connect, and manage live data across platforms.",
    },
    "hi": {
      "name": "Coefficients AI",
      "desc":
          "Coefficients AI स्प्रेडशीट में स्वचालित डेटा, वर्कफ्लो, और प्लेटफ़ॉर्म कनेक्टिविटी लाता है।",
    },
    "mr": {
      "name": "Coefficients AI",
      "desc":
          "Coefficients AI स्प्रेडशीटमध्ये स्वयंचलित डेटा, वर्कफ्लो व कनेक्टिव्हिटी देते.",
    },
    "es": {
      "name": "Coefficients AI",
      "desc":
          "Coefficients AI automatiza flujos y conecta datos en hojas de cálculo con IA.",
    },
    "de": {
      "name": "Coefficients AI",
      "desc":
          "Coefficients AI automatisiert Tabellen und Daten-Workflows plattformübergreifend.",
    },
  },
  "PromptLoop": {
    "en": {
      "name": "PromptLoop",
      "desc":
          "PromptLoop enables you to run AI-powered text and data functions inside Google Sheets and Excel, including summarization, classification, and generation.",
    },
    "hi": {
      "name": "PromptLoop",
      "desc":
          "PromptLoop AI टेक्स्ट और डेटा कार्य Google शीट्स/Excel में चलाता है—जैसे सारांश, वर्गीकरण, निर्माण।",
    },
    "mr": {
      "name": "PromptLoop",
      "desc":
          "PromptLoop हे AI बेस्ड टेक्स्ट व डेटा फंक्शन्स Google Sheets व Excel मधे चालू शकते.",
    },
    "es": {
      "name": "PromptLoop",
      "desc":
          "PromptLoop ejecuta funciones IA (resúmenes, clasificación…) en Sheets y Excel.",
    },
    "de": {
      "name": "PromptLoop",
      "desc":
          "PromptLoop ermöglicht KI-basierte Text- und Datenfunktionen in Sheets & Excel.",
    },
  },
  "Canva Magic Write": {
    "en": {
      "name": "Canva Magic Write",
      "desc":
          "Helps you brainstorm, edit, and create marketing copy, emails, and more.",
    },
    "hi": {
      "name": "कैनवा मैजिक राइट",
      "desc":
          "मदद करता है विचारों को सोचने, संपादित करने और विपणन सामग्री, ईमेल आदि बनाने में।",
    },
    "mr": {
      "name": "कॅनव्हा मॅजिक राइट",
      "desc": "विचारमंथन, संपादन आणि विपणन प्रत, ईमेल्स तयार करण्यात मदत करते.",
    },
    "es": {
      "name": "Canva Magic Write",
      "desc":
          "Ayuda a crear ideas, editar y escribir textos de marketing, correos y más.",
    },
    "de": {
      "name": "Canva Magic Write",
      "desc":
          "Hilft beim Brainstorming, Bearbeiten und Erstellen von Marketingtexten, E-Mails und mehr.",
    },
  },
  "ManusAI": {
    "en": {
      "name": "Manus.ai",
      "desc":
          "Manus.ai empowers users to build professional mobile apps visually, without writing code. Drag-and-drop blocks, instant AI suggestions, and ready-made templates speed up your app's creation whether you’re a professional or a beginner.",
    },
    "hi": {
      "name": "Manus.ai",
      "desc":
          "Manus.ai उपयोगकर्ताओं को बिना कोड के मोबाइल ऐप तेजी से और आसानी से बनाने की सुविधा देता है। इसमें ड्रैग-ड्रॉप, AI टेम्पलेट और त्वरित सजेशन हैं—नौसिखिए और विशेषज्ञ दोनों के लिए उपयुक्त।",
    },
    "mr": {
      "name": "Manus.ai",
      "desc":
          "Manus.ai वापरकर्त्यांना ड्रॅग-ड्रॉप, तयार AI टेम्पलेट्स आणि त्वरित सुचवण्या वापरून कोड न लिहिता मोबाईल अ‍ॅप बनविण्याची सुविधा देते.",
    },
    "es": {
      "name": "Manus.ai",
      "desc":
          "Manus.ai permite crear apps móviles profesionales visualmente, sin programar. Usa bloques drag-and-drop, plantillas IA y consejos automáticos.",
    },
    "de": {
      "name": "Manus.ai",
      "desc":
          "Mit Manus.ai bauen Sie professionelle Mobile-Apps visuell, dank Drag&Drop-Editor, KI-Vorlagen und schnellen Tipps – ganz ohne Programmierung.",
    },
  },
  "Workable": {
    "en": {
      "name": "Workable",
      "desc":
          "Workable is an AI-powered recruiting and applicant tracking system for posting jobs, sourcing, evaluating candidates, and automating hiring processes.",
    },
    "hi": {
      "name": "Workable",
      "desc":
          "Workable AI-आधारित भर्ती, जॉब पोस्टिंग, कैंडिडेट ट्रैकिंग और ऑटोमेटिक हायरिंग टूल हैं।",
    },
    "mr": {
      "name": "Workable",
      "desc": "Workable हे AI-आधारित भरती व अर्जदार व्यवस्थापन साधन आहे.",
    },
    "es": {
      "name": "Workable",
      "desc":
          "Workable es un sistema IA para reclutamiento y selección: ofertas, filtrado y automatización.",
    },
    "de": {
      "name": "Workable",
      "desc":
          "Workable ist ein KI-Recruiting- und Bewerbermanagement-Tool für Automatisierung und Auswahlprozesse.",
    },
  },
  "Toptal": {
    "en": {
      "name": "Toptal",
      "desc":
          "Toptal connects businesses with top global freelancers and experts using AI to match candidates to projects.",
    },
    "hi": {
      "name": "Toptal",
      "desc":
          "Toptal एआई से श्रेष्ठ वैश्विक फ्रीलांसर व एक्सपर्ट्स को आपके प्रोजेक्ट्स के लिए मैच करता है।",
    },
    "mr": {
      "name": "Toptal",
      "desc": "Toptal AI च्या मदतीने जागतिक फ्रीलॅन्सर व तज्ञांशी जुळवतो.",
    },
    "es": {
      "name": "Toptal",
      "desc":
          "Toptal encuentra el mejor talento freelance global mediante IA y selección experta.",
    },
    "de": {
      "name": "Toptal",
      "desc":
          "Toptal vermittelt Experten und Freelancer weltweit – unterstützt durch KI-Matching.",
    },
  },
  "EdApp": {
    "en": {
      "name": "EdApp",
      "desc":
          "EdApp is a mobile-first training and microlearning solution with AI—create, deliver, and track engaging courses for employee growth.",
    },
    "hi": {
      "name": "EdApp",
      "desc":
          "EdApp एआई आधारित मोबाइल प्रशिक्षण प्लेटफ़ॉर्म—छोटे लेसन, पढाई व ग्रोथ के लिए।",
    },
    "mr": {
      "name": "EdApp",
      "desc": "EdApp हे मोबाइल व AI-आधारित शिक्षण व प्रशिक्षणाचे अ‍ॅप आहे.",
    },
    "es": {
      "name": "EdApp",
      "desc":
          "EdApp: cursos móviles y microaprendizaje IA para empleados y formación.",
    },
    "de": {
      "name": "EdApp",
      "desc":
          "EdApp – Mobile Microlearning & Trainings mit KI-Optimierungen für Unternehmen.",
    },
  },
  "intelliHR": {
    "en": {
      "name": "intelliHR",
      "desc":
          "intelliHR is an AI analytics platform for HR—analyze employee engagement, performance metrics, and provide actionable workforce insights.",
    },
    "hi": {
      "name": "intelliHR",
      "desc":
          "intelliHR एआई के साथ कर्मचारी अनुभव, प्रदर्शन डेटा व HR विश्लेषण का प्लेटफ़ॉर्म है।",
    },
    "mr": {
      "name": "intelliHR",
      "desc":
          "intelliHR हे AI विश्लेषण प्लॅटफॉर्म, कर्मचारी अनुभव, कामगिरी मेट्रिक्स व HR अनालिटिक्ससाठी.",
    },
    "es": {
      "name": "intelliHR",
      "desc":
          "intelliHR: análisis de desempeño y gestión IA para talento y HR.",
    },
    "de": {
      "name": "intelliHR",
      "desc":
          "intelliHR ist eine Analyseplattform mit KI für HR-Daten, Mitarbeitermotivation & Leistungskennzahlen.",
    },
  },
  "Effy": {
    "en": {
      "name": "Effy",
      "desc":
          "Effy is an AI tool for automating employee feedback, 360° reviews, engagement surveys, and continuous performance management.",
    },
    "hi": {
      "name": "Effy",
      "desc":
          "Effy कर्मचारी फीडबैक, समीक्षा और प्रदर्शन ऑटोमेट करने का एआई टूल है।",
    },
    "mr": {
      "name": "Effy",
      "desc":
          "Effy हे कर्मचारी फीडबॅक व वेगवेगळ्या मूल्यांकनांसाठी AI आधारित टूल आहे.",
    },
    "es": {
      "name": "Effy",
      "desc":
          "Effy: automatiza feedback, encuestas y evaluaciones IA para equipos y empleados.",
    },
    "de": {
      "name": "Effy",
      "desc":
          "Effy automatisiert Feedback, 360°-Umfragen und Performance-Management mit KI.",
    },
  },
  "Uizard": {
    "en": {
      "name": "Uizard",
      "desc":
          "Uizard turns paper sketches or text descriptions into interactive app prototypes using AI. It accelerates design workflows and helps anyone test layout ideas quickly.",
    },
    "hi": {
      "name": "Uizard",
      "desc":
          "Uizard आपके कागज़ी स्केच या टेक्स्ट डिस्क्रिप्शन को AI से इंटरेक्टिव ऐप प्रोटोटाइप में बदल देता है। यह डिज़ाइन प्रक्रिया को तेज़ करता है और किसी को भी लेआउट आईडिया तुरंत टेस्ट करने में मदद करता है।",
    },
    "mr": {
      "name": "Uizard",
      "desc":
          "Uizard हे AI वापरून तुमच्या कागदी स्केच किंवा मजकूर वर्णनांना इंटरअॅक्टिव्ह अ‍ॅप प्रोटोटाइपमध्ये रूपांतरित करते. हे डिझाईन कार्यक्षमतेला गती देते आणि कोणालाही लेआउट कल्पना पटकन तपासायला मदत करते.",
    },
    "es": {
      "name": "Uizard",
      "desc":
          "Uizard convierte bocetos en papel o descripciones de texto en prototipos interactivos de apps usando IA. Acelera el flujo de trabajo de diseño y ayuda a probar ideas de layouts rápidamente.",
    },
    "de": {
      "name": "Uizard",
      "desc":
          "Uizard verwandelt Papierskizzen oder Textbeschreibungen mit KI in interaktive App-Prototypen. Beschleunigt Design-Workflows und ermöglicht schnelles Testen von Layout-Ideen.",
    },
  },
  "AIRoomPlanner": {
    "en": {
      "name": "AI Room Planner",
      "desc":
          "AI Room Planner lets you instantly create and visualize room layouts, try new decor and furniture options, and generate 2D/3D plans with AI suggestions to fit your style and needs.",
    },
    "hi": {
      "name": "AI Room Planner",
      "desc":
          "AI Room Planner की मदद से आप तुरंत कमरे का लेआउट बना सकते हैं, फर्नीचर/साज-सज्जा आज़मा सकते हैं और एआई सुझावों के साथ 2D/3D डिज़ाइन पा सकते हैं।",
    },
    "mr": {
      "name": "AI Room Planner",
      "desc":
          "AI Room Planner वापरून खोलीचे नियोजन, सजावट व फर्निचर पर्याय पटकन शोधा. 2D/3D डिझाइन व एआय सुचना मिळवा.",
    },
    "es": {
      "name": "AI Room Planner",
      "desc":
          "AI Room Planner facilita el diseño de habitaciones, probando muebles y decoraciones con sugerencias IA y planos en 2D/3D.",
    },
    "de": {
      "name": "AI Room Planner",
      "desc":
          "AI Room Planner erstellt Raumpläne & Möblierungsideen mit KI, bietet 2D/3D Entwürfe und Vorschläge für deinen Stil.",
    },
  },
  "RoomGPT": {
    "en": {
      "name": "RoomGPT",
      "desc":
          "RoomGPT reimagines any room from a photo—generate entirely new styles, layouts, and interior design themes for homes using AI.",
    },
    "hi": {
      "name": "RoomGPT",
      "desc":
          "RoomGPT एक फोटो से किसी भी कमरे का नया लुक, डेकोर व थीम बनाता है। एआई से घर को एकदम नए अंदाज में रीडिज़ाइन करें।",
    },
    "mr": {
      "name": "RoomGPT",
      "desc":
          "RoomGPT तुमच्या खोलीचा फोटो घेऊन नवीन लुक, थीम व सजावट सुचवतो—घरासाठी एआय डिझाइन.",
    },
    "es": {
      "name": "RoomGPT",
      "desc":
          "RoomGPT genera estilos y decoraciones interiores desde fotos gracias a IA.",
    },
    "de": {
      "name": "RoomGPT",
      "desc":
          "RoomGPT verwandelt Fotos in neue Raumkonzepte mit KI; Stil, Deko & Layouts schnell ausprobieren.",
    },
  },
  "ResumeMaker": {
    "en": {
      "name": "ResumeMaker",
      "desc":
          "ResumeMaker uses AI to build, edit, and format professional resumes. Select templates, auto-edit sections, and export easily for any job type.",
    },
    "hi": {
      "name": "ResumeMaker",
      "desc":
          "ResumeMaker एआई से प्रोफेशनल रिज़्यूमे बनाईये, टेम्पलेट चुनें, सेक्शन ऑटो-एडिट करें और आसानी से डाउनलोड करें।",
    },
    "mr": {
      "name": "ResumeMaker",
      "desc":
          "ResumeMaker AI द्वारे व्यावसायिक रिझ्युमे तयार करा, टेम्पलेट निवडा, विभाग संपादित करा व सोपे डाउनलोड करा.",
    },
    "es": {
      "name": "ResumeMaker",
      "desc":
          "ResumeMaker genera CVs y plantillas con IA, autocompleta y exporta para cualquier trabajo.",
    },
    "de": {
      "name": "ResumeMaker",
      "desc":
          "ResumeMaker erstellt und bearbeitet professionelle Lebensläufe per KI und bietet sofortige Vorlagen.",
    },
  },
  "Sonara": {
    "en": {
      "name": "Sonara",
      "desc":
          "Sonara automates your job search, scans listings, and applies on your behalf with AI—sending updates and tracking your opportunities.",
    },
    "hi": {
      "name": "Sonara",
      "desc":
          "Sonara एआई से जॉब खोज, आवेदन, अलर्ट और ट्रैकिंग को ऑटोमेट करता है।",
    },
    "mr": {
      "name": "Sonara",
      "desc": "Sonara AI ने नोकरी शोध, अर्ज व अलर्ट ऑटोमेट करते.",
    },
    "es": {
      "name": "Sonara",
      "desc":
          "Sonara automatiza la búsqueda y postulación laboral, y te envía alertas IA.",
    },
    "de": {
      "name": "Sonara",
      "desc":
          "Sonara sucht & bewirbt sich automatisch für Jobs mit KI, gibt Updates.",
    },
  },
  "CareerLock": {
    "en": {
      "name": "Career Lock",
      "desc":
          "Career Lock is an AI-powered platform for career guidance, opportunity alerts, and job tracking, helping you make smarter decisions at every step.",
    },
    "hi": {
      "name": "Career Lock",
      "desc":
          "Career Lock एआई करियर सलाह, जॉब अलर्ट्स व ट्रैकिंग प्लेटफ़ॉर्म है—हर स्टेप पर स्मार्ट निर्णय में मदद करें।",
    },
    "mr": {
      "name": "Career Lock",
      "desc":
          "Career Lock हे एआय आधारित करियर सल्ला, संधी अलर्ट, व नोकरी ट्रॅक करून मार्गदर्शन करते.",
    },
    "es": {
      "name": "Career Lock",
      "desc":
          "Career Lock te alerta sobre oportunidades, guía y seguimiento profesional IA.",
    },
    "de": {
      "name": "Career Lock",
      "desc":
          "Career Lock bietet Karriere-Alerts, Beratung und Job-Tracking mit KI-Unterstützung.",
    },
  },
  "Kickresume": {
    "en": {
      "name": "Kickresume",
      "desc":
          "Kickresume is an AI resume and cover letter builder—choose samples, auto-fill content, and fine-tune with AI suggestions for every application.",
    },
    "hi": {
      "name": "Kickresume",
      "desc":
          "Kickresume एआई रिज़्यूमे और कवर लेटर मेकर है—सैंपल चुनें और AI से कंटेंट लिखें।",
    },
    "mr": {
      "name": "Kickresume",
      "desc":
          "Kickresume हे एआयवर आधारलेले रिझ्युमे व कव्हर लेटर टूल आहे—नमुने निवडा, सामग्री भरा.",
    },
    "es": {
      "name": "Kickresume",
      "desc":
          "Kickresume crea CVs y cartas de presentación IA con muestras y autocompletado.",
    },
    "de": {
      "name": "Kickresume",
      "desc":
          "Kickresume generiert Lebensläufe und Anschreiben per KI – mit Vorlagen und Textvorschlägen.",
    },
  },
  "Homestyler": {
    "en": {
      "name": "Homestyler",
      "desc":
          "Homestyler is a 3D interior design platform to plan rooms, test furniture, decor ideas, and walk through virtual spaces powered by AI.",
    },
    "hi": {
      "name": "Homestyler",
      "desc":
          "Homestyler से 3D में कमरे की योजना बना सकते हैं, फर्नीचर व डेकोर ट्राइ करें और एआई वर्चुअल स्पेस एक्सप्लोर करें।",
    },
    "mr": {
      "name": "Homestyler",
      "desc":
          "Homestyler हे 3D इंटिरिअर डिझाइन साधन: खोली नियोजन, फर्निचर व डेकोर कल्पना, वर्च्युअल टूर एआय सह.",
    },
    "es": {
      "name": "Homestyler",
      "desc":
          "Homestyler es una plataforma de diseño interior 3D para probar muebles, ideas y planos virtuales IA.",
    },
    "de": {
      "name": "Homestyler",
      "desc":
          "Homestyler ist eine 3D-Innenarchitektur-Plattform für Raumplanung, Möbelideen und virtuelle Rundgänge per KI.",
    },
  },
  "Site123": {
    "en": {
      "name": "Site123",
      "desc":
          "Site123 is an easy website builder with AI guidance. Anyone can generate a site, pick from templates, and go live in minutes—no coding or design experience required.",
    },
    "hi": {
      "name": "Site123",
      "desc":
          "Site123 एआई गाइडेंस के साथ आसान वेबसाइट बिल्डर है। कोई भी मिनटों में साइट बना सकता है, टेम्प्लेट चुन सकता है और ऑनलाइन कर सकता है—ना कोडिंग की आवश्यकता, ना डिज़ाइन अनुभव।",
    },
    "mr": {
      "name": "Site123",
      "desc":
          "Site123 हा AI मार्गदर्शनासह सोपा वेबसाइट बिल्डर आहे. कोणतीही कोडिंग किंवा डिझाईन आवश्यक नाही—जे पाहिजे तेवढ्यात वेबसाइट तयार करा, टेम्प्लेट निवडा आणि काही मिनिटांतच प्रसिद्ध करा.",
    },
    "es": {
      "name": "Site123",
      "desc":
          "Site123 es un constructor web fácil de usar con IA. Cualquiera puede crear su sitio, elegir plantilla y publicarlo en minutos—sin programar ni tener experiencia en diseño.",
    },
    "de": {
      "name": "Site123",
      "desc":
          "Site123 ist ein einfacher Website-Baukasten mit KI-Hilfe. Jeder kann eine Seite erstellen, aus Vorlagen wählen und in Minuten online gehen – ohne Programmier- oder Designkenntnisse.",
    },
  },
  "Uizard1": {
    "en": {
      "name": "Uizard",
      "desc":
          "Uizard turns paper sketches or text descriptions into interactive app prototypes using AI. It accelerates design workflows and helps anyone test layout ideas quickly.",
    },
    "hi": {
      "name": "Uizard",
      "desc":
          "Uizard आपके कागज़ी स्केच या टेक्स्ट डिस्क्रिप्शन को AI से इंटरेक्टिव ऐप प्रोटोटाइप में बदल देता है। यह डिज़ाइन प्रक्रिया को तेज़ करता है और किसी को भी लेआउट आईडिया तुरंत टेस्ट करने में मदद करता है।",
    },
    "mr": {
      "name": "Uizard",
      "desc":
          "Uizard हे AI वापरून तुमच्या कागदी स्केच किंवा मजकूर वर्णनांना इंटरअॅक्टिव्ह अ‍ॅप प्रोटोटाइपमध्ये रूपांतरित करते. हे डिझाईन कार्यक्षमतेला गती देते आणि कोणालाही लेआउट कल्पना पटकन तपासायला मदत करते.",
    },
    "es": {
      "name": "Uizard",
      "desc":
          "Uizard convierte bocetos en papel o descripciones de texto en prototipos interactivos de apps usando IA. Acelera el flujo de trabajo de diseño y ayuda a probar ideas de layouts rápidamente.",
    },
    "de": {
      "name": "Uizard",
      "desc":
          "Uizard verwandelt Papierskizzen oder Textbeschreibungen mit KI in interaktive App-Prototypen. Beschleunigt Design-Workflows und ermöglicht schnelles Testen von Layout-Ideen.",
    },
  },
  "HealthifyMe": {
    "en": {
      "name": "HealthifyMe",
      "desc":
          "HealthifyMe is an AI-based health and nutrition app offering personalized diet plans, fitness coaching, real-time calorie tracking, and habit guidance.",
    },
    "hi": {
      "name": "HealthifyMe",
      "desc":
          "HealthifyMe एक एआई आधारित स्वास्थ्य और पोषण ऐप है, जो व्यक्तिगत डाइट, फिटनेस कोचिंग और रीयल-टाइम कैलोरी ट्रैकिंग की सुविधा देता है।",
    },
    "mr": {
      "name": "HealthifyMe",
      "desc":
          "HealthifyMe हे एआय आधारित आरोग्य आणि पोषण अ‍ॅप आहे, जे वैयक्तिक डाएट, फिटनेस मार्गदर्शन आणि कॅलरी ट्रॅकिंग सेवा देते.",
    },
    "es": {
      "name": "HealthifyMe",
      "desc":
          "HealthifyMe es una app IA que ofrece planes de dieta personalizados, consejo fitness y control de calorías en tiempo real.",
    },
    "de": {
      "name": "HealthifyMe",
      "desc":
          "HealthifyMe ist eine KI-App für Ernährung und Fitness mit persönlichen Diätplänen, Coaching und Kalorienzähler.",
    },
  },
  "PathAI": {
    "en": {
      "name": "PathAI",
      "desc":
          "PathAI is an AI-powered platform for fast, accurate pathology diagnosis and image analysis supporting medical research and workflow efficiency.",
    },
    "hi": {
      "name": "PathAI",
      "desc":
          "PathAI एक एआई आधारित पथविज्ञान निदान प्लेटफ़ॉर्म है, जो तेज़ और सटीक छवि विश्लेषण में मदद करता है।",
    },
    "mr": {
      "name": "PathAI",
      "desc":
          "PathAI हे एआय पॅथॉलॉजी निदान प्लॅटफॉर्म आहे, जे जलद व अचूक निदानासाठी मदत करते.",
    },
    "es": {
      "name": "PathAI",
      "desc":
          "PathAI es una plataforma de diagnóstico patológico con IA para análisis de imágenes y apoyo a la investigación clínica.",
    },
    "de": {
      "name": "PathAI",
      "desc":
          "PathAI ist eine KI-Plattform für Pathologiediagnostik und schnelle Bildanalyse, die Forschung und Diagnosen unterstützt.",
    },
  },
  "ETlitic": {
    "en": {
      "name": "ETlitic",
      "desc":
          "ETlitic leverages AI for automated analysis of medical images (X-ray, CT, MRI), supporting early diagnosis and clinical research.",
    },
    "hi": {
      "name": "ETlitic",
      "desc":
          "ETlitic एआई द्वारा स्वचालित चिकित्सा इमेज विश्लेषण, शीघ्र निदान और अनुसंधान में सहायक है।",
    },
    "mr": {
      "name": "ETlitic",
      "desc": "ETlitic वैद्यकीय इमेज विश्लेषण व संशोधनासाठी एआय वापरते.",
    },
    "es": {
      "name": "ETlitic",
      "desc":
          "ETlitic utiliza IA para el análisis automático de imágenes médicas (rayos X, CT, MRI) y apoya el diagnóstico temprano.",
    },
    "de": {
      "name": "ETlitic",
      "desc":
          "ETlitic nutzt KI zur automatisierten Analyse medizinischer Bilder für schnelles Screening und Diagnostik.",
    },
  },
  "FitnessAI": {
    "en": {
      "name": "FitnessAI",
      "desc":
          "FitnessAI is an AI-powered personal trainer app that creates strength training and workout routines tailored to your goals, tracks your progress, and adapts plans using advanced algorithms—for better results in less time.",
    },
    "hi": {
      "name": "FitnessAI",
      "desc":
          "FitnessAI एक एआई आधारित जिम ट्रेनर ऐप है, जो आपके लक्ष्य और प्रगति के अनुसार वर्कआउट प्लान बनाता व ट्रैक करता है, ताकि आप कम समय में बेहतर परिणाम पा सकें।",
    },
    "mr": {
      "name": "FitnessAI",
      "desc":
          "FitnessAI हे AI आधारित वैयक्तिक वर्कआउट मार्गदर्शक आहे, जे तुमच्या उद्दिष्टांनुसार व्यायाम योजना तयार करते व ट्रॅक करते.",
    },
    "es": {
      "name": "FitnessAI",
      "desc":
          "FitnessAI es un entrenador personal con IA que diseña rutinas y seguimiento según tus objetivos físicos, maximizando resultados.",
    },
    "de": {
      "name": "FitnessAI",
      "desc":
          "FitnessAI erstellt individuelle Trainingspläne, verfolgt Fortschritte und passt Workouts mit KI optimal an.",
    },
  },
  "CureFit": {
    "en": {
      "name": "CureFit",
      "desc":
          "CureFit is a digital fitness and health app offering AI-driven workouts, live classes, healthy recipes, and wellness tracking—ideal for holistic fitness and nutrition.",
    },
    "hi": {
      "name": "CureFit",
      "desc":
          "CureFit एक डिज़िटल फिटनेस व स्वास्थ्य ऐप है—AI वर्कआउट्स, लाइव क्लासेस, हेल्दी रेसिपीज़ और लाइफस्टाइल ट्रैकिंग के लिए।",
    },
    "mr": {
      "name": "CureFit",
      "desc":
          "CureFit हे AI तंत्रावर चालणारे डिजिटल फिटनेस व आरोग्य ॲप आहे—वर्कआउट्स, लाइव्ह क्लासेस, आहार आणि डायरी ट्रॅकिंगसाठी.",
    },
    "es": {
      "name": "CureFit",
      "desc":
          "CureFit es una app de fitness que ofrece clases, rutinas IA, comida saludable y seguimiento integral.",
    },
    "de": {
      "name": "CureFit",
      "desc":
          "CureFit bietet AI-gestützte Workouts, Live-Kurse, Ernährungsberatung und Gesundheits-Tracking.",
    },
  },
  "Plantix": {
    "en": {
      "name": "Plantix",
      "desc":
          "Plantix is an AI-powered app for farmers and gardeners—instantly diagnose plant diseases, pests, and nutrient deficiencies by photo, get treatment tips, and connect with a global agri-community for better crop health and yields.",
    },
    "hi": {
      "name": "Plantix",
      "desc":
          "Plantix एक एआई एग्री ऐप है: किसान फोटो द्वारा पौधों की बीमारी, कीट या पोषक तत्व की कमी पहचानें, निदान व समाधान पाएं, और कृषि समुदाय से जुड़ें।",
    },
    "mr": {
      "name": "Plantix",
      "desc":
          "Plantix हे एआय-चालित कृषी अ‍ॅप, फोटोवरून वनस्पतीचे आजार, कीटक किंवा खात्याची कमतरता ओळखते, योग्य उपचार व उपाय देते, आणि शेतकऱ्यांना एकत्र आणते.",
    },
    "es": {
      "name": "Plantix",
      "desc":
          "Plantix es una app IA que diagnostica enfermedades de plantas por foto y conecta a agricultores con consejos expertos.",
    },
    "de": {
      "name": "Plantix",
      "desc":
          "Plantix ist eine KI-App für Landwirte zur Erkennung von Pflanzenkrankheiten, Düngermangel und Schädlingsbefall per Foto.",
    },
  },
  "Banaya": {
    "en": {
      "name": "Banaya (Bayer)",
      "desc":
          "Banaya, by Bayer, is an AI-driven agri-platform offering crop insights, weather risk, planting strategies, and precision farming advice for smarter yield and sustainability.",
    },
    "hi": {
      "name": "Banaya (Bayer)",
      "desc":
          "Banaya (Bayer) एक एआई मंच—फसल डेटा, मौसम जोखिम, बोआई रणनीति और स्मार्ट कृषि सलाह के लिए।",
    },
    "mr": {
      "name": "Banaya (Bayer)",
      "desc":
          "Banaya हे Bayer चे AI कृषी मंच, पिक माहिती, हवामान, पेरणीसाठी सल्ला व शाश्वत उत्पन्नासाठी उपयोगी.",
    },
    "es": {
      "name": "Banaya (Bayer)",
      "desc":
          "Banaya de Bayer: IA para información de cultivos, clima y consejos agrícolas para maximizar la cosecha.",
    },
    "de": {
      "name": "Banaya (Bayer)",
      "desc":
          "Banaya (Bayer) bietet KI-gestützte Datenanalyse, Wetterratschläge und Präzisionslandwirtschaft für bessere Ernten.",
    },
  },
  "Aerobotics": {
    "en": {
      "name": "Aerobotics",
      "desc":
          "Aerobotics provides AI-powered drone and satellite crop monitoring for early detection of pests, disease, and growth anomalies, helping farmers optimize inputs and maximize yields.",
    },
    "hi": {
      "name": "Aerobotics",
      "desc":
          "Aerobotics एआई-ड्रोन व सैटेलाइट से फसल में बीमारी, कीट व विकास की समस्या पहले पहचानता है—फसल प्रबंधन और उत्पादकता के लिए।",
    },
    "mr": {
      "name": "Aerobotics",
      "desc":
          "Aerobotics हे AI ड्रोन/सॅटेलाइट्स द्वारे पीक निरीक्षण करते, रोग, कीटक व वाढीच्या समस्यांची लवकर ओळख व सल्ला देते.",
    },
    "es": {
      "name": "Aerobotics",
      "desc":
          "Aerobotics usa IA y drones/satélites para detectar plagas, enfermedades y anomalías precozmente en cultivos.",
    },
    "de": {
      "name": "Aerobotics",
      "desc":
          "Aerobotics überwacht Felder mit KI-Drohnen & Satelliten zur schnellen Schädlings-/Krankheitserkennung.",
    },
  },
  "ProcessSt": {
    "en": {
      "name": "Process.st",
      "desc":
          "Process.st is an AI-powered workflow automation platform for creating, tracking, and optimizing business processes, checklists, and recurring project tasks.",
    },
    "hi": {
      "name": "Process.st",
      "desc":
          "Process.st एक एआई वर्कफ़्लो ऑटोमेशन टूल है—प्रक्रिया, चेकलिस्ट और नियमित प्रोजेक्ट टास्क बनाने, ट्रैक करने और बेहतर करने के लिए।",
    },
    "mr": {
      "name": "Process.st",
      "desc":
          "Process.st हे एआय वर्कफ्लो ऑटोमेशन साधन आहे—प्रक्रिया, चेकलिस्ट व पुन्हा-पुन्हा होणाऱ्या कामासाठी.",
    },
    "es": {
      "name": "Process.st",
      "desc":
          "Process.st es una plataforma IA para flujos, checklist y procesos de proyecto automatizados.",
    },
    "de": {
      "name": "Process.st",
      "desc":
          "Process.st automatisiert Arbeitsabläufe, Checklisten und wiederkehrende Aufgaben durch KI.",
    },
  },
  "ProjectPlanner": {
    "en": {
      "name": "Project Planner",
      "desc":
          "Project Planner uses AI to build, schedule, and adapt project timelines, allocate resources, and generate Gantt charts for optimal delivery.",
    },
    "hi": {
      "name": "Project Planner",
      "desc":
          "Project Planner AI से प्रोजेक्ट टाइमलाइन, संसाधन आवंटन और गैंट चार्ट बनाएं—डिलीवरी सरल बनाएं।",
    },
    "mr": {
      "name": "Project Planner",
      "desc":
          "Project Planner AI प्रकल्प वेळापत्रक, साधनवाटप व Gantt चार्टसाठी उपयुक्त.",
    },
    "es": {
      "name": "Project Planner",
      "desc":
          "Project Planner utiliza IA para planificar proyectos, asignar recursos y crear cronogramas visuales.",
    },
    "de": {
      "name": "Project Planner",
      "desc":
          "Project Planner plant Projekte, erstellt Zeitpläne und Ressourcenallokation mit KI.",
    },
  },
  "Wrike": {
    "en": {
      "name": "Wrike",
      "desc":
          "Wrike is an AI-driven project management suite for teams—collaborate, manage tasks, monitor progress, and automate routine work for faster results.",
    },
    "hi": {
      "name": "Wrike",
      "desc":
          "Wrike टीमों के लिए एआई-आधारित प्रोजेक्ट मैनेजमेंट प्लेटफॉर्म है—एक साथ काम करें, कार्य ट्रैक करें और रिपोर्टिंग आसान बनाएं।",
    },
    "mr": {
      "name": "Wrike",
      "desc":
          "Wrike हे टीम्ससाठी AI प्रकल्प व्यवस्थापन साधन—सहकार्य, काम ट्रॅकिंग व प्रगतीचे ऑटो रिपोर्ट.",
    },
    "es": {
      "name": "Wrike",
      "desc":
          "Wrike es una suite IA para gestión, colaboración, y automatización de tareas de proyecto.",
    },
    "de": {
      "name": "Wrike",
      "desc":
          "Wrike vereinfacht Teamarbeit, Aufgaben und Workflows mit KI-gestütztem Projektmanagement.",
    },
  },
  "Notion": {
    "en": {
      "name": "Notion",
      "desc":
          "Notion combines project planning, documentation, wikis, and database functions in an AI-enabled workspace for maximum productivity and transparency.",
    },
    "hi": {
      "name": "Notion",
      "desc":
          "Notion एक AI-सक्षम वर्कस्पेस है—प्रोजेक्ट्स, नोट्स, विकी और डोक्युमेंटेशन के लिए सभी फीचर्स।",
    },
    "mr": {
      "name": "Notion",
      "desc":
          "Notion हे AI एकत्रित प्रकल्प व्यवस्थापन, दस्तऐवज, विकी व डेटाबेसworkspace आहे.",
    },
    "es": {
      "name": "Notion",
      "desc":
          "Notion integra proyectos, documentación, wikis y más—todo IA en un espacio de trabajo eficiente.",
    },
    "de": {
      "name": "Notion",
      "desc":
          "Notion kombiniert Projektplanung, Notizen und Datenbanken in einer KI-Arbeitsumgebung.",
    },
  },
  "agricopilot": {
    "en": {
      "name": "agricopilot",
      "desc":
          "AgVoice is a voice-powered AI platform for farmers to record, track, and share field activities and crop observations hands-free—boosting efficiency and data quality on the go.",
    },
    "hi": {
      "name": "agricopilot",
      "desc":
          "AgVoice किसानों को वाणी आदेश से खेत गतिविधियों का रिकॉर्डिंग, ट्रैकिंग और रिपोर्टिंग करने की सुविधा देता है—डाटा क्वालिटी और दक्षता बढ़ाता है।",
    },
    "mr": {
      "name": "agricopilot",
      "desc":
          "AgVoice हे शेतकऱ्यांसाठी व्हॉईस AI, हातमुक्त माहिती नोंद, निरीक्षण व अहवाल तयार करण्यासाठी मदत करते.",
    },
    "es": {
      "name": "agricopilot",
      "desc":
          "AgVoice permite a los agricultores registrar y compartir tareas del campo por voz, mejorando la eficiencia de la gestión agrícola.",
    },
    "de": {
      "name": "Agricopilotilot",
      "desc":
          "AgVoice ist eine KI-Sprachplattform für Landwirte für Sprachaufzeichnung und Dokumentation während der Feldarbeit.",
    },
  },
  "DreamStudio": {
    "en": {
      "name": "DreamStudio",
      "desc":
          "DreamStudio uses AI (Stable Diffusion) to generate custom game concept art, backgrounds, characters, and textures—from text prompts or sketches.",
    },
    "hi": {
      "name": "DreamStudio",
      "desc":
          "DreamStudio AI (स्टेबल डिफ्यूजन) से गेम आर्ट, कैरेक्टर, बैकग्राउंड और डिजाइन बनाता है—सिर्फ टेक्स्ट या स्केच से।",
    },
    "mr": {
      "name": "DreamStudio",
      "desc":
          "DreamStudio AI (Stable Diffusion) वापरून गेमसाठी आर्ट, पात्र, पार्श्वभूमी तयार करते—फक्त मजकूर/स्केच वरून.",
    },
    "es": {
      "name": "DreamStudio",
      "desc":
          "DreamStudio usa IA (Stable Diffusion) para crear arte, personajes y fondos para juegos a partir de texto o bosquejos.",
    },
    "de": {
      "name": "DreamStudio",
      "desc":
          "DreamStudio erstellt Spiel-Artworks, Hintergründe und Figuren mit KI (Stable Diffusion) aus Text oder Skizzen.",
    },
  },
  "Scenario": {
    "en": {
      "name": "Scenario",
      "desc":
          "Scenario is an AI toolkit for generating and managing custom art, characters, levels, and in-game assets—perfect for small studios and indie gamedevs.",
    },
    "hi": {
      "name": "Scenario",
      "desc":
          "Scenario AI से कस्टम आर्टवर्क, गेम कैरेक्टर व लेवल आसानी से तैयार—हर गेमिंग टीम के लिए उपयुक्त।",
    },
    "mr": {
      "name": "Scenario",
      "desc":
          "Scenario AI वापरून कस्टम आर्ट, पात्र, लेव्हल व गेम युएल तयार करा—सर्व गेम डेव्हलपर्ससाठी.",
    },
    "es": {
      "name": "Scenario",
      "desc":
          "Scenario es un kit IA para arte, personajes y recursos únicos para estudios y desarrolladores.",
    },
    "de": {
      "name": "Scenario",
      "desc":
          "Scenario ist ein KI-Toolset für individuelles Spiel-Artwork, Charaktere und Assets.",
    },
  },
  "LudoAI": {
    "en": {
      "name": "Ludo AI",
      "desc":
          "Ludo AI accelerates game ideation, market research, and asset generation—discover trends, brainstorm, and instantly prototype visuals with AI.",
    },
    "hi": {
      "name": "Ludo AI",
      "desc":
          "Ludo AI सोच, रिसर्च व एसेट बनाना तेज करता है—गेमिंग ट्रेंड खोजें, आइडिया जेनरेट करें, व AI से प्रोटोटाइप बनाएं।",
    },
    "mr": {
      "name": "Ludo AI",
      "desc":
          "Ludo AI गेम कल्पना, रिसर्च व एसेट क्रिएशन वेगवान करते—AI चा वापर ट्रेंड शोधण्यासाठी व व्हिज्युअल्स बनवण्यासाठी.",
    },
    "es": {
      "name": "Ludo AI",
      "desc":
          "Ludo AI acelera ideas, análisis y recursos IA para juegos; detecta tendencias y crea prototipos visuales.",
    },
    "de": {
      "name": "Ludo AI",
      "desc":
          "Ludo AI macht Ideenfindung, Recherche und Asset-Erstellung für Spiele schneller – KI findet Trends und erstellt Prototypen.",
    },
  },
  "Rosebud": {
    "en": {
      "name": "Rosebud",
      "desc":
          "Rosebud is a no-code AI game builder—design characters, animate, prototype, and build playable games and stories right from your browser.",
    },
    "hi": {
      "name": "Rosebud",
      "desc":
          "Rosebud एक कोड-फ्री AI प्लेटफ़ॉर्म—कैरेक्टर डिज़ाइन, गेम प्रोटोटाइप व स्टोरीज ब्राउज़र से बनाएं।",
    },
    "mr": {
      "name": "Rosebud",
      "desc":
          "Rosebud कोड-विनामूल्य AI गमेकर—पात्र, अ‍ॅनिमेशन, व खेळ सर्जनशीलपणे ब्राउझरमध्येच.",
    },
    "es": {
      "name": "Rosebud",
      "desc":
          "Rosebud es una plataforma IA sin código para crear juegos y personajes fácilmente online.",
    },
    "de": {
      "name": "Rosebud",
      "desc":
          "Rosebud ist ein No-Code-KI-Game-Builder spiele und entwerfe Spiele, Figuren und Storys direkt im Browser.",
    },
  },
  "DesignCom": {
    "en": {
      "name": "Design.com",
      "desc":
          "Design.com instantly generates professional logos and complete brand identity kits using AI. Easily customize colors, fonts, and layouts to create a unique visual for any business.",
    },
    "hi": {
      "name": "Design.com",
      "desc":
          "Design.com AI से प्रोफेशनल लोगो व ब्रांड आइडेंटिटी किट तुरंत बनाएँ—रंग, फॉन्ट, लेआउट बदलें और व्यापार का पहचान बनाएं।",
    },
    "mr": {
      "name": "Design.com",
      "desc":
          "Design.com AI वापरून प्रोफेशनल लोगो व ब्रँड किट क्षणात तयार करा—रंग, फॉन्ट, व लेआउट सहज बदला.",
    },
    "es": {
      "name": "Design.com",
      "desc":
          "Design.com genera logos y kits de marca IA al instante: personaliza colores, fuentes y estilo fácilmente.",
    },
    "de": {
      "name": "Design.com",
      "desc":
          "Design.com erstellt sofort professionelle KI-Logos & Marken-Kits – Farben, Fonts, Layouts einfach anpassen.",
    },
  },
  "LogoAI": {
    "en": {
      "name": "LogoAi",
      "desc":
          "LogoAi creates AI-generated logos and brand assets optimized for every platform—fast, customizable, with brandbook downloads and social media previews.",
    },
    "hi": {
      "name": "LogoAi",
      "desc":
          "LogoAi AI से हर प्लेटफॉर्म के लिए यूनिक लोगो व ब्रांड एसेट बनाएं—कस्टमाइज़ेबल और डाउनलोड संभव।",
    },
    "mr": {
      "name": "LogoAi",
      "desc":
          "LogoAi हे सर्व प्लॅटफॉर्मसाठी AI बेस्ड ब्रँड एसेट व लोगो क्षणात तयार करते.",
    },
    "es": {
      "name": "LogoAi",
      "desc":
          "LogoAi genera logos IA únicos, assets y preview para cada red social al instante.",
    },
    "de": {
      "name": "LogoAi",
      "desc":
          "LogoAi erstellt KI-Logos & Marken-Assets mit voll Anpassungen für alle Plattformen.",
    },
  },
  "TurboLogo": {
    "en": {
      "name": "TurboLogo",
      "desc":
          "TurboLogo offers ultra-fast logo creation powered by AI—explore countless templates and icons, adjust styles, and download print-ready files immediately.",
    },
    "hi": {
      "name": "TurboLogo",
      "desc":
          "TurboLogo AI से टेम्पलेट व आइकॉन चुनें, लोगो बनाएँ और तुरंत डाउनलोड करें—ब्रांडिंग के लिए परफेक्ट।",
    },
    "mr": {
      "name": "TurboLogo",
      "desc":
          "TurboLogo AI ने अनेक टेम्पलेट्स व आयकॉन्ससह लोगो बनवून लगेच डाउनलोड करा.",
    },
    "es": {
      "name": "TurboLogo",
      "desc":
          "TurboLogo: logos IA rápidos, plantillas e iconos, listos para imprimir.",
    },
    "de": {
      "name": "TurboLogo",
      "desc":
          "TurboLogo – blitzschnelle KI-Logos mit vielen Vorlagen & Icons sofort herunterladen.",
    },
  },
  "BlackBox": {
    "en": {
      "name": "BlackBox",
      "desc":
          "BlackBox is an AI coding assistant with advanced code search, real-time autocomplete, and powerful debugging features for developers.",
    },
    "hi": {
      "name": "BlackBox",
      "desc":
          "BlackBox एक AI आधारित कोड सर्च, ऑटो कंप्लीट और डिबगिंग टूल है—डेवलपर्स के लिए स्मार्ट सहायक।",
    },
    "mr": {
      "name": "BlackBox",
      "desc": "BlackBox हे AI आधारित कोड शोध, ऑटो-कम्प्लीट व डिबगिंग साधन आहे.",
    },
    "es": {
      "name": "BlackBox",
      "desc":
          "BlackBox es un asistente IA para programadores, con búsqueda, autocompletado y depuración de código.",
    },
    "de": {
      "name": "BlackBox",
      "desc":
          "BlackBox ist dein KI-Coding-Tool – Echtzeit-Suche, Autocomplete und Debugging.",
    },
  },
  "Grammarly": {
    "en": {
      "name": "Grammarly",
      "desc":
          "Grammarly provides AI-powered grammar, clarity, and tone corrections for all your writing—emails, documents, social posts, and more.",
    },
    "hi": {
      "name": "Grammarly",
      "desc":
          "Grammarly एआई लिखावट सुधार, व्याकरण और टोन सुझाव देता है—हर तरह के लेखन के लिए।",
    },
    "mr": {
      "name": "Grammarly",
      "desc":
          "Grammarly तुमच्या लेखनासाठी AI आधारित व्याकरण, स्पष्टता व टोन सुधारणा करते.",
    },
    "es": {
      "name": "Grammarly",
      "desc": "Grammarly corrige gramática y estilo IA en todos tus textos.",
    },
    "de": {
      "name": "Grammarly",
      "desc":
          "Grammarly prüft Grammatik, Klarheit & Ton – KI-gestützt für alle Texte.",
    },
  },
  "Copyai": {
    "en": {
      "name": "Copy.ai",
      "desc":
          "Copy.ai generates creative copy for ads, social posts, and blogs instantly with the help of AI.",
    },
    "hi": {
      "name": "Copy.ai",
      "desc":
          "Copy.ai AI के साथ विज्ञापन, ब्लॉग और सोशल मीडिया के लिए कॉपी तैयार करता है।",
    },
    "mr": {
      "name": "Copy.ai",
      "desc":
          "Copy.ai हे जाहिराती, ब्लॉग व सोशल पोस्टसाठी AI आधारित मजकूर तयार करते.",
    },
    "es": {
      "name": "Copy.ai",
      "desc":
          "Copy.ai crea textos comerciales y creativos con IA para redes sociales y más.",
    },
    "de": {
      "name": "Copy.ai",
      "desc": "Copy.ai generiert Werbe- und Social-Texte per KI.",
    },
  },
  "Ahrefs": {
    "en": {
      "name": "Ahrefs",
      "desc":
          "Ahrefs provides AI-powered SEO tools for keyword research, site audits, backlinks, and competitor analysis.",
    },
    "hi": {
      "name": "Ahrefs",
      "desc":
          "Ahrefs SEO के लिए AI टूल—कीवर्ड सर्च, साइट ऑडिट, बैकलिंक और कंपटीटर एनालिसिस।",
    },
    "mr": {
      "name": "Ahrefs",
      "desc":
          "Ahrefs हे SEO साठी AI टूल – कीवर्ड शोध, साईट ऑडिट व स्पर्धक विश्लेषण.",
    },
    "es": {
      "name": "Ahrefs",
      "desc":
          "Ahrefs te da herramientas IA para SEO, palabras clave y análisis de competencia.",
    },
    "de": {
      "name": "Ahrefs",
      "desc":
          "Ahrefs bietet KI-Tools für SEO, Keywords, Backlinks und Konkurrenz-Checks.",
    },
  },
  "JenniAI": {
    "en": {
      "name": "JenniAI",
      "desc":
          "JenniAI is an AI writing assistant for research papers, essays, and idea generation, with smart citations and academic tone help.",
    },
    "hi": {
      "name": "JenniAI",
      "desc":
          "JenniAI अनुसंधान, निबंध और विचार लेखन हेतु एआई सहायक है—स्मार्ट संदर्भ और एकेडमिक टोन के साथ।",
    },
    "mr": {
      "name": "JenniAI",
      "desc":
          "JenniAI हे संशोधन, निबंध आणि कल्पनेसाठी AI लेखन सहाय्यक, स्मार्ट संदर्भांसह.",
    },
    "es": {
      "name": "JenniAI",
      "desc":
          "JenniAI es asistente IA para ensayos, papers y generación de ideas (con referencias automáticas).",
    },
    "de": {
      "name": "JenniAI",
      "desc":
          "JenniAI ist ein KI-Schreibassistent für Aufsätze, Forschung und Idee-Generierung mit Zitaten.",
    },
  },
  "Blackbox": {
    "en": {
      "name": "BlackBox",
      "desc":
          "BlackBox is an AI coding assistant with advanced code search, real-time autocomplete, and powerful debugging features for developers.",
    },
    "hi": {
      "name": "BlackBox",
      "desc":
          "BlackBox एक AI आधारित कोड सर्च, ऑटो कंप्लीट और डिबगिंग टूल है—डेवलपर्स के लिए स्मार्ट सहायक।",
    },
    "mr": {
      "name": "BlackBox",
      "desc": "BlackBox हे AI आधारित कोड शोध, ऑटो-कम्प्लीट व डिबगिंग साधन आहे.",
    },
    "es": {
      "name": "BlackBox",
      "desc":
          "BlackBox es un asistente IA para programadores, con búsqueda, autocompletado y depuración de código.",
    },
    "de": {
      "name": "BlackBox",
      "desc":
          "BlackBox ist dein KI-Coding-Tool – Echtzeit-Suche, Autocomplete und Debugging.",
    },
  },
  "Grammarly@": {
    "en": {
      "name": "Grammarly",
      "desc":
          "Grammarly provides AI-powered grammar, clarity, and tone corrections for all your writing—emails, documents, social posts, and more.",
    },
    "hi": {
      "name": "Grammarly",
      "desc":
          "Grammarly एआई लिखावट सुधार, व्याकरण और टोन सुझाव देता है—हर तरह के लेखन के लिए।",
    },
    "mr": {
      "name": "Grammarly",
      "desc":
          "Grammarly तुमच्या लेखनासाठी AI आधारित व्याकरण, स्पष्टता व टोन सुधारणा करते.",
    },
    "es": {
      "name": "Grammarly",
      "desc": "Grammarly corrige gramática y estilo IA en todos tus textos.",
    },
    "de": {
      "name": "Grammarly",
      "desc":
          "Grammarly prüft Grammatik, Klarheit & Ton – KI-gestützt für alle Texte.",
    },
  },
  "Khromo": {
    "en": {
      "name": "Khromo",
      "desc":
          "Khromo offers AI-generated color palettes and unique graphic design inspiration tailored to your brand style. Discover modern palettes, visualize combinations, and get instant inspiration for any design project.",
    },
    "hi": {
      "name": "Khromo",
      "desc":
          "Khromo AI द्वारा ब्रांड के अनुसार अनूठे रंग पैलेट और डिजाइन समाधानों की प्रेरणा देता है। तुरंत नए, आकर्षक रंग संयोजन पाएं।",
    },
    "mr": {
      "name": "Khromo",
      "desc":
          "Khromo AI वर आधारित रंगपॅलेट व डिझाईन प्रेरणा – तुमच्या ब्रँडसाठी अद्वितीय, आकर्षक रंग योजना शोधा.",
    },
    "es": {
      "name": "Khromo",
      "desc":
          "Khromo genera paletas de colores IA y diseños creativos adaptados a la identidad de tu marca.",
    },
    "de": {
      "name": "Khromo",
      "desc":
          "Khromo liefert KI-generierte Farbpaletten und Designideen, perfekt abgestimmt auf Ihren Look.",
    },
  },
  "VirtalStaging": {
    "en": {
      "name": "VitalStaging",
      "desc":
          "VitalStaging uses AI to monitor, stage, and analyze real-time medical and vital data, providing actionable health insights and decision support for clinicians and patients.",
    },
    "hi": {
      "name": "VitalStaging",
      "desc":
          "VitalStaging एआई के साथ मेडिकल डेटा की वास्तविक समय में निगरानी, विश्लेषण और चरण निर्धारण करता है, डॉक्टरों व मरीजों के लिए महत्वपूर्ण स्वास्थ्य सलाह देता है।",
    },
    "mr": {
      "name": "VitalStaging",
      "desc":
          "VitalStaging हे AI वापरून रिअलटाइम वैद्यकीय डेटा विश्लेषण व आरोग्य टप्पे ओळखते, डॉक्टर व रुग्णांसाठी उपयुक्त माहिती देते.",
    },
    "es": {
      "name": "VitalStaging",
      "desc":
          "VitalStaging monitoriza y analiza datos médicos en tiempo real con IA, brindando diagnósticos y alertas para médicos y pacientes.",
    },
    "de": {
      "name": "VitalStaging",
      "desc":
          "VitalStaging analysiert medizinische Vitaldaten in Echtzeit und unterstützt mit KI die Gesundheitseinschätzung und Therapieeinleitung.",
    },
  },
  "CivilsAI": {
    "en": {
      "name": "CivilsAI",
      "desc":
          "CivilsAI is an intelligent exam prep assistant for civil services—suggesting study plans, answering practice questions, and explaining difficult topics using AI.",
    },
    "hi": {
      "name": "CivilsAI",
      "desc":
          "CivilsAI सिविल सेवा परीक्षा की तैयारी के लिए एआई आधारित सहायक है—परीक्षा योजना, अभ्यास और जटिल विषयों की व्याख्या में मदद करता है।",
    },
    "mr": {
      "name": "CivilsAI",
      "desc":
          "CivilsAI हा सेवापरीक्षा तयारीसाठी AI सहाय्यक — अभ्यासक्रम, सराव प्रश्न व विषय स्पष्ट व्याख्या मिळवा.",
    },
    "es": {
      "name": "CivilsAI",
      "desc":
          "CivilsAI es un asistente IA para oposiciones: planifica estudios, resuelve dudas y explica temas complejos.",
    },
    "de": {
      "name": "CivilsAI",
      "desc":
          "CivilsAI hilft bei der Vorbereitung auf Beamtenprüfungen: Studienpläne, Übungsfragen & Erklärungen per KI.",
    },
  },
  "ChatAI": {
    "en": {
      "name": "ChatAI",
      "desc":
          "ChatAI is a multi-purpose AI chatbot for instant Q&A, brainstorming, creative writing, tutoring, and productivity—all powered by advanced natural language processing.",
    },
    "hi": {
      "name": "ChatAI",
      "desc":
          "ChatAI बहुपरकारी AI चैटबॉट है—उत्तर दें, विचार करें, रचनात्मक लेखन या ट्यूटोरिंग, सबकुछ एक जगह।",
    },
    "mr": {
      "name": "ChatAI",
      "desc":
          "ChatAI हा सर्वसाधारण AI चॅटबॉट—चौकशी, उपाय, सर्जनशील लेखन व शिकवणीसाठी.",
    },
    "es": {
      "name": "ChatAI",
      "desc":
          "ChatAI es un chatbot IA versátil para preguntas, ideas y tareas creativas de todo tipo.",
    },
    "de": {
      "name": "ChatAI",
      "desc":
          "ChatAI ist ein vielseitiger KI-Chatbot für Antworten, Brainstorming, Text, Lernen und Produktivität.",
    },
  },
  "Copy.ai": {
    "en": {
      "name": "Copy.ai",
      "desc":
          "Copy.ai generates creative copy for ads, social posts, and blogs instantly with the help of AI.",
    },
    "hi": {
      "name": "Copy.ai",
      "desc":
          "Copy.ai AI के साथ विज्ञापन, ब्लॉग और सोशल मीडिया के लिए कॉपी तैयार करता है।",
    },
    "mr": {
      "name": "Copy.ai",
      "desc":
          "Copy.ai हे जाहिराती, ब्लॉग व सोशल पोस्टसाठी AI आधारित मजकूर तयार करते.",
    },
    "es": {
      "name": "Copy.ai",
      "desc":
          "Copy.ai crea textos comerciales y creativos con IA para redes sociales y más.",
    },
    "de": {
      "name": "Copy.ai",
      "desc": "Copy.ai generiert Werbe- und Social-Texte per KI.",
    },
  },
  "Ahrefs@": {
    "en": {
      "name": "Ahrefs",
      "desc":
          "Ahrefs provides AI-powered SEO tools for keyword research, site audits, backlinks, and competitor analysis.",
    },
    "hi": {
      "name": "Ahrefs",
      "desc":
          "Ahrefs SEO के लिए AI टूल—कीवर्ड सर्च, साइट ऑडिट, बैकलिंक और कंपटीटर एनालिसिस।",
    },
    "mr": {
      "name": "Ahrefs",
      "desc":
          "Ahrefs हे SEO साठी AI टूल – कीवर्ड शोध, साईट ऑडिट व स्पर्धक विश्लेषण.",
    },
    "es": {
      "name": "Ahrefs",
      "desc":
          "Ahrefs te da herramientas IA para SEO, palabras clave y análisis de competencia.",
    },
    "de": {
      "name": "Ahrefs",
      "desc":
          "Ahrefs bietet KI-Tools für SEO, Keywords, Backlinks und Konkurrenz-Checks.",
    },
  },
  "JenniAI@": {
    "en": {
      "name": "JenniAI",
      "desc":
          "JenniAI is an AI writing assistant for research papers, essays, and idea generation, with smart citations and academic tone help.",
    },
    "hi": {
      "name": "JenniAI",
      "desc":
          "JenniAI अनुसंधान, निबंध और विचार लेखन हेतु एआई सहायक है—स्मार्ट संदर्भ और एकेडमिक टोन के साथ।",
    },
    "mr": {
      "name": "JenniAI",
      "desc":
          "JenniAI हे संशोधन, निबंध आणि कल्पनेसाठी AI लेखन सहाय्यक, स्मार्ट संदर्भांसह.",
    },
    "es": {
      "name": "JenniAI",
      "desc":
          "JenniAI es asistente IA para ensayos, papers y generación de ideas (con referencias automáticas).",
    },
    "de": {
      "name": "JenniAI",
      "desc":
          "JenniAI ist ein KI-Schreibassistent für Aufsätze, Forschung und Idee-Generierung mit Zitaten.",
    },
  },
  "HotpotAI": {
    "en": {
      "name": "Hotpot AI",
      "desc":
          "Hotpot AI helps developers generate pixel art, icons, sprites, mockups and other game assets using AI from text and templates.",
    },
    "hi": {
      "name": "Hotpot AI",
      "desc":
          "Hotpot AI से डेवेलपर्स सिर्फ टेक्स्ट से पिक्सेल आर्ट, स्प्राइट, ग्राफिक्स व मो़कअप बना सकते हैं।",
    },
    "mr": {
      "name": "Hotpot AI",
      "desc":
          "Hotpot AI ने डेव्हलपर्सना फक्त मजकूर/टेम्पलेटवरून स्प्राइट्स, ग्राफिक्स बनवण्याची सुविधा.",
    },
    "es": {
      "name": "Hotpot AI",
      "desc":
          "Hotpot AI permite crear sprites, iconos y arte IA para juegos con texto y plantillas.",
    },
    "de": {
      "name": "Hotpot AI",
      "desc":
          "Hotpot AI generiert Sprites, Icons & Mockups aus Textvorlagen für Spiele-Assets.",
    },
  },
  "Perplexity": {
    "en": {
      "name": "Perplexity",
      "desc":
          "AI-powered code generator, research assistant, and tool for quickly finding code examples and answers.",
    },
    "hi": {
      "name": "Perplexity",
      "desc": "AI कोड जनरेटर व रिसर्च असिस्टेंट—कोड सर्च व त्वरित समाधान।",
    },
    "mr": {
      "name": "Perplexity",
      "desc": "AI कोड जनरेटर, सर्च व सहाय्यक.",
    },
    "es": {
      "name": "Perplexity",
      "desc": "Generador de código IA y asistente de investigación.",
    },
    "de": {
      "name": "Perplexity",
      "desc": "KI-Codegenerator & Recherche-Tool.",
    },
  },
  "FirebaseJotform": {
    "en": {
      "name": "Firebase Jotform",
      "desc":
          "App building platform combining forms, database, and AI-driven features for quick deployment.",
    },
    "hi": {
      "name": "Firebase Jotform",
      "desc": "एप्स बनाने के लिए फॉर्म, डेटाबेस व AI एक साथ।",
    },
    "mr": {
      "name": "Firebase Jotform",
      "desc": "फॉर्म, डेटाबेस आणि AI वापरून अ‍ॅप तयार करा.",
    },
    "es": {
      "name": "Firebase Jotform",
      "desc": "Construcción de apps con formularios y base de datos IA.",
    },
    "de": {
      "name": "Firebase Jotform",
      "desc": "App-Erstellung mit Formularen, Datenbank & KI.",
    },
  },
  "CreateXYZ": {
    "en": {
      "name": "CreateXYZ",
      "desc":
          "Generate web apps directly from natural language input—describe your idea and get a working tool.",
    },
    "hi": {
      "name": "CreateXYZ",
      "desc": "आसान भाषा लिखें, ऐप टूल पाएं (AI)।",
    },
    "mr": {
      "name": "CreateXYZ",
      "desc": "सोप्या भाषेतून अ‍ॅप तयार करा.",
    },
    "es": {
      "name": "CreateXYZ",
      "desc": "Crea apps desde ideas en lenguaje natural.",
    },
    "de": {
      "name": "CreateXYZ",
      "desc": "Apps per Sprachbeschreibung mit KI erstellen.",
    },
  },
  "TensorFlow": {
    "en": {
      "name": "TensorFlow",
      "desc":
          "Open-source framework for designing, training, and deploying AI/ML apps.",
    },
    "hi": {
      "name": "TensorFlow",
      "desc": "ओपन सोर्स AI और ML फ्रेमवर्क।",
    },
    "mr": {
      "name": "TensorFlow",
      "desc": "ओपनसोर्स AI/ML व्यासपीठ.",
    },
    "es": {
      "name": "TensorFlow",
      "desc": "Framework IA/ML de código abierto.",
    },
    "de": {
      "name": "TensorFlow",
      "desc": "Open-Source-KI/ML-Framework.",
    },
  },
  "Bubble": {
    "en": {
      "name": "Bubble",
      "desc":
          "Drag-and-drop web app builder with AI for logic, design, and data integration.",
    },
    "hi": {
      "name": "Bubble",
      "desc": "AI चालित ड्रैग-ड्रॉप वेब ऐप बिल्डर।",
    },
    "mr": {
      "name": "Bubble",
      "desc": "AI सह वेब अ‍ॅप ड्रॅग ड्रॉप बिल्डर.",
    },
    "es": {
      "name": "Bubble",
      "desc": "Creador web IA drag and drop.",
    },
    "de": {
      "name": "Bubble",
      "desc": "Drag-and-drop-Web-Builder mit KI.",
    },
  },
  "GitHubCopilot": {
    "en": {
      "name": "GitHub Copilot",
      "desc":
          "AI-powered code completion, suggestions, and automation tool for developers.",
    },
    "hi": {
      "name": "GitHub Copilot",
      "desc": "AI कोड ऑटो-सूझाव और ऑटोमेशन टूल।",
    },
    "mr": {
      "name": "GitHub Copilot",
      "desc": "AI सहकार्यासाठी कोड सहाय्यक.",
    },
    "es": {
      "name": "GitHub Copilot",
      "desc": "Ayudante IA para completar y sugerir código.",
    },
    "de": {
      "name": "GitHub Copilot",
      "desc": "KI-Codeassistent & Vervollständigung.",
    },
  },
  "UxPilot": {
    "en": {
      "name": "UxPilot",
      "desc":
          "UxPilot leverages AI to analyze app screens, suggest UX improvements, and automate user research, helping designers make data-driven design decisions for better usability and engagement.",
    },
    "hi": {
      "name": "UxPilot",
      "desc":
          "UxPilot एआई की मदद से ऐप की स्क्रीन का विश्लेषण, डिजाइन सुधार के सुझाव और यूज़र रिसर्च को ऑटोमेट करता है—बेहतर उपयोगिता और एंगेजमेंट के लिए।",
    },
    "mr": {
      "name": "UxPilot",
      "desc":
          "UxPilot AI वापरून स्क्रीन विश्लेषण, UX सुधार व युजर रिसर्च ऑटोमेट करते – डिझाईन निर्णयासाठी उपयुक्त.",
    },
    "es": {
      "name": "UxPilot",
      "desc":
          "UxPilot usa IA para analizar pantallas, sugerir mejoras de UX y automatizar la investigación de usuarios.",
    },
    "de": {
      "name": "UxPilot",
      "desc":
          "UxPilot analysiert Screens, gibt UX-Verbesserungsvorschläge und automatisiert Nutzerforschung mittels KI.",
    },
  },
  "Visily": {
    "en": {
      "name": "Visily",
      "desc":
          "Visily generates wireframes and high-fidelity mockups from simple text prompts, sketches, or screenshots, enabling rapid UI prototyping and collaboration with smart AI.",
    },
    "hi": {
      "name": "Visily",
      "desc":
          "Visily टेक्स्ट प्रॉम्प्ट, स्केच या स्क्रीनशॉट से वाइरफ्रेम व मॉकअप बनाता है—UI प्रोटोटाइप तुरंत तैयार करें।",
    },
    "mr": {
      "name": "Visily",
      "desc":
          "Visily मजकूर, स्केच किंवा स्क्रीनशॉटवरून वेगशील वायर्फ्रेम्स व मॉकअप्स तयार करते—AI सह जलद UI प्रोटोटायपिंग.",
    },
    "es": {
      "name": "Visily",
      "desc":
          "Visily genera wireframes y prototipos desde texto, bocetos o capturas, facilitando la colaboración UI con IA.",
    },
    "de": {
      "name": "Visily",
      "desc":
          "Visily erstellt Wireframes & Mockups aus Text, Skizzen oder Screenshots – KI für schnelles UI-Prototyping.",
    },
  },
  "GalileoAI": {
    "en": {
      "name": "GalileoAI",
      "desc":
          "GalileoAI offers instant UI design generation from natural language: type a prompt, and AI creates Figma-ready or web UIs with layouts, components, and visually cohesive styles.",
    },
    "hi": {
      "name": "GalileoAI",
      "desc":
          "GalileoAI टेक्स्ट प्रॉम्प्ट से तुरंत UI डिज़ाइन बनाता है—Figma या वेब के लिए रेडी लेआउट व स्टाइल्स AI से।",
    },
    "mr": {
      "name": "GalileoAI",
      "desc":
          "GalileoAI वेगाने UI डिझाईन तयार करते, फक्त प्रॉम्प्ट द्या—AI लेआउट्स, स्टाइल्स व कम्पोनंट्स देते.",
    },
    "es": {
      "name": "GalileoAI",
      "desc":
          "GalileoAI produce diseños UI instantáneos desde texto para Figma o webs completos con componentes visuales.",
    },
    "de": {
      "name": "GalileoAI",
      "desc":
          "GalileoAI erstellt UI-Designs in Sekunden aus Text – inklusive Figma-Layouts und Komponenten.",
    },
  },
  "Oddo": {
    "en": {
      "name": "Oddo",
      "desc":
          "Oddo (Odoo) is an all-in-one platform for creating, managing, and scaling e-commerce, business, or portfolio websites with AI integrations, templates, and business apps.",
    },
    "hi": {
      "name": "Oddo",
      "desc":
          "Oddo (Odoo) एक ऑल-इन-वन मंच—बिजनेस, ई-कॉमर्स या पोर्टफोलियो वेबसाइटें बनाएं, प्रबंधित करें व स्केल करें, AI फीचर्स के साथ।",
    },
    "mr": {
      "name": "Oddo",
      "desc":
          "Oddo (Odoo) हे संपूर्ण AI व टेम्पलेट आधारित व्यापार, ई-कॉमर्स व वेबसाइट निर्मितीचे टूल आहे.",
    },
    "es": {
      "name": "Oddo",
      "desc":
          "Oddo permite crear, gestionar y escalar webs de negocio o tienda IA todo en uno.",
    },
    "de": {
      "name": "Oddo",
      "desc":
          "Oddo ist die All-in-One Plattform für Business-Websites, eCommerce und KI-Integration.",
    },
  },
  "Wix": {
    "en": {
      "name": "Wix",
      "desc":
          "Wix offers an intuitive website builder with AI design, ready-made sections, and app integrations to launch professional websites fast—just drag, drop, and go live.",
    },
    "hi": {
      "name": "Wix",
      "desc":
          "Wix एक ड्रैग-ड्रॉप वेबसाइट बिल्डर है—AI डिजाइन, रेडीमेड सेक्शन और फास्ट लॉन्चिंग के लिए।",
    },
    "mr": {
      "name": "Wix",
      "desc": "Wix ड्रॅग-ड्रॉप, AI डिझाईन व जलद लॉन्चिंगसाठी अव्वल निवड आहे.",
    },
    "es": {
      "name": "Wix",
      "desc":
          "Wix: Plataforma fácil con IA, bloques listos y apps para publicar sitios en minutos.",
    },
    "de": {
      "name": "Wix",
      "desc":
          "Wix baut Websites per Drag&Drop, KI-Design und fertigen Elementen – ganz ohne Coding.",
    },
  },
  "Replit": {
    "en": {
      "name": "Replit",
      "desc":
          "Replit is a collaborative coding platform with AI code completion—develop, deploy, and share websites or apps with instant hosting and teamwork tools.",
    },
    "hi": {
      "name": "Replit",
      "desc":
          "Replit सहयोगी कोडिंग प्लेटफॉर्म है—AI कोड कम्पलीशन, वेबसाइट और ऐप लेकर फास्ट डिप्लॉय के लिए।",
    },
    "mr": {
      "name": "Replit",
      "desc":
          "Replit हे AI सहकार्य, वेब/अ‍ॅप डेव्हलपमेंट आणि इन्स्टंट होस्टिंगसाठी प्लॅटफॉर्म आहे.",
    },
    "es": {
      "name": "Replit",
      "desc":
          "Replit colabora y auto-completa código IA para crear, publicar y compartir sitios web/app.",
    },
    "de": {
      "name": "Replit",
      "desc":
          "Replit ermöglicht KI-gestütztes Kollaborieren, Entwickeln und Deployen von Websites und Apps.",
    },
  },
  "Renderforest": {
    "en": {
      "name": "Renderforest",
      "desc":
          "Renderforest lets anyone build websites, promo videos, logos, and graphics easily using AI templates—ideal for fast branding and online launch.",
    },
    "hi": {
      "name": "Renderforest",
      "desc":
          "Renderforest से AI टेम्पलेट द्वारा वेबसाइट, वीडियो, लोगो व ग्राफिक्स आसानी से बनाएं—ब्रांडिंग व लॉन्च के लिए।",
    },
    "mr": {
      "name": "Renderforest",
      "desc":
          "Renderforest AI टेम्पलेट्सने वेबसाइट, व्हिडिओ, ग्राफिक्स पटकन तयार करा—ब्रांडिंग व ऑनलाइन वापरासाठी.",
    },
    "es": {
      "name": "Renderforest",
      "desc":
          "Renderforest construye webs, videos, logos y más con plantillas IA—rápido y sencillo.",
    },
    "de": {
      "name": "Renderforest",
      "desc":
          "Mit Renderforest Websites, Videos, Logos & Grafiken per KI-Vorlagen schnell erstellen.",
    },
  },
  "Site123.": {
    "en": {
      "name": "Site123",
      "desc":
          "Site123 is an easy website builder with AI guidance. Anyone can generate a site, pick from templates, and go live in minutes—no coding or design experience required.",
    },
    "hi": {
      "name": "Site123",
      "desc":
          "Site123 एआई गाइडेंस के साथ आसान वेबसाइट बिल्डर है। कोई भी मिनटों में साइट बना सकता है, टेम्प्लेट चुन सकता है और ऑनलाइन कर सकता है—ना कोडिंग की आवश्यकता, ना डिज़ाइन अनुभव।",
    },
    "mr": {
      "name": "Site123",
      "desc":
          "Site123 हा AI मार्गदर्शनासह सोपा वेबसाइट बिल्डर आहे. कोणतीही कोडिंग किंवा डिझाईन आवश्यक नाही—जे पाहिजे तेवढ्यात वेबसाइट तयार करा, टेम्प्लेट निवडा आणि काही मिनिटांतच प्रसिद्ध करा.",
    },
    "es": {
      "name": "Site123",
      "desc":
          "Site123 es un constructor web fácil de usar con IA. Cualquiera puede crear su sitio, elegir plantilla y publicarlo en minutos—sin programar ni tener experiencia en diseño.",
    },
    "de": {
      "name": "Site123",
      "desc":
          "Site123 ist ein einfacher Website-Baukasten mit KI-Hilfe. Jeder kann eine Seite erstellen, aus Vorlagen wählen und in Minuten online gehen – ohne Programmier- oder Designkenntnisse.",
    },
  },
};
// R/ Example prompts per tool and language
const Map<String, Map<String, List<String>>> toolExamples = {
  "ChatGPT": {
    "en": [
      "Explain quantum computing in simple terms.",
      "Write a cover letter for a software developer role."
    ],
    "hi": [
      "क्वांटम कंप्यूटिंग को सरल शब्दों में समझाएं।",
      "सॉफ्टवेयर डेवलपर भूमिका के लिए एक कवर लेटर लिखें।"
    ],
    "mr": [
      "क्वांटम संगणन सोप्या शब्दात समजावून सांगा.",
      "सॉफ्टवेअर डेव्हलपर पदासाठी कव्हर लेटर लिहा."
    ],
    "es": [
      "Explica la computación cuántica en términos simples.",
      "Escribe una carta de presentación para un puesto de desarrollador de software."
    ],
    "de": [
      "Erkläre Quantencomputing in einfachen Worten.",
      "Schreibe ein Anschreiben für die Stelle als Softwareentwickler."
    ],
  },
  "Plantix": {
    "en": [
      "Diagnose leaf spot disease from this plant photo.",
      "Suggest organic pest control for tomato crops.",
      "Log field conditions and get fertilizer tips."
    ],
    "hi": [
      "इस पौधे की फोटो पर पत्ती बीमारी पहचानें।",
      "टमाटर फसल के लिए जैविक कीट नियंत्रण सुझाव दें।",
      "फील्ड कंडीशन लॉग करें और खाद सलाह पाएं।",
    ],
    "mr": [
      "या वनस्पतीच्या फोटोपासून रोग ओळखा.",
      "टोमॅटो पिकासाठी सेंद्रिय कीटक नियंत्रण सांगा.",
      "शेतीची स्थिती नोंदवा व खत सल्ला घ्या.",
    ],
    "es": [
      "Diagnostica enfermedad en hojas por foto.",
      "Sugiere control orgánico de plagas para tomates.",
      "Registra condiciones y recibe consejos de fertilizante.",
    ],
    "de": [
      "Erkenne Blattkrankheiten anhand von Fotos.",
      "Empfehle biologische Schädlingsbekämpfung bei Tomaten.",
      "Feldstatus dokumentieren & Düngetipps erhalten.",
    ],
  },
  "Banaya": {
    "en": [
      "Give crop-wise yield forecasts for the upcoming season.",
      "What are the weather risks for wheat planting this month?",
      "Analyze soil data for precision fertilizer advice."
    ],
    "hi": [
      "आगामी सीजन के लिए फसल की पैदावार भविष्यवाणी करें।",
      "इस महीने गेहूं बोआई के लिए मौसम जोखिम क्या हैं?",
      "सटीक खाद सलाह हेतु मिट्टी डेटा विश्लेषण करें।",
    ],
    "mr": [
      "येणाऱ्या हंगामासाठी पिकातील उत्पादनाचा अंदाज द्या.",
      "या महिन्यात गहू पेरणीसाठी हवामानाचा धोका सांगा.",
      "सेंद्रिय खत सल्ल्यासाठी मातीचा डेटा विश्लेषण करा.",
    ],
    "es": [
      "Proporciona pronósticos de cosecha para la próxima temporada.",
      "¿Riesgos climáticos para la siembra de trigo este mes?",
      "Analiza datos del suelo para consejo de fertilización.",
    ],
    "de": [
      "Gib Ernteprognosen nach Kultur für die nächste Saison.",
      "Welche Wetterriskiken gibt es für Weizensaat aktuell?",
      "Analysiere Bodendaten für Düngungsempfehlungen.",
    ],
  },
  "Aerobotics": {
    "en": [
      "Detect pest outbreaks in my orchard's drone imagery.",
      "Get growth anomaly alerts from satellite crop analysis.",
      "Visualize field maps of stressed or healthy plants."
    ],
    "hi": [
      "ड्रोन इमेज में बगीचे में कीट हमले पहचानें।",
      "सैटेलाइट डाटा से फसल में ग्रोथ समस्या अलर्ट पाएं।",
      "स्वस्थ और तनावग्रस्त पौधों का फील्ड मैप देखें।",
    ],
    "mr": [
      "ड्रोन इमेजवरील बागेतील कीटक हल्ला शोधा.",
      "सॅटेलाईट विश्लेषणाने पीक वाढीतील समस्या ओळखा.",
      "तणावाखाली किंवा निरोगी वनस्पतीचे फील्ड नकाशे पहा.",
    ],
    "es": [
      "Detecta plagas en imágenes de dron de mi huerto.",
      "Recibe alertas de anomalías en cultivos vía satélite.",
      "Visualiza mapas de campo de plantas sanas o enfermas.",
    ],
    "de": [
      "Entdecke Schädlingsbefall auf Drohnenbildern meines Feldes.",
      "Wachstumsanomalien per Satellit feststellen.",
      "Kartiere gesunde und gestresste Pflanzen im Feld.",
    ],
  },
  "agricopilot": {
    "en": [
      "Voice record today's irrigation and planting tasks.",
      "Log pesticide application report by voice.",
      "Share spoken crop observations with my agronomist."
    ],
    "hi": [
      "आज की सिंचाई और बोआई कार्य वॉयस में रिकॉर्ड करें।",
      "कीटनाशक छिड़काव रिपोर्ट वॉयस से लॉग करें।",
      "फसल अवलोकन का विवरण वॉयस द्वारा साझा करें।",
    ],
    "mr": [
      "आजची सिंचन व पेरणीचे काम व्हॉईसमध्ये नोंदवा.",
      "कीटकनाशक फवारणीची नोंद व्हॉईसमध्ये करा.",
      "पिक निरीक्षणे व्हॉईसने शेतीतज्ज्ञांशी शेअर करा.",
    ],
    "es": [
      "Registra tareas de riego y siembra por voz.",
      "Anota aplicaciones de pesticidas usando la voz.",
      "Comparte observaciones de cultivos verbalmente.",
    ],
    "de": [
      "Sprich heutige Bewässerung und Aussaat ein.",
      "Logge Pestizideinsatz per Spracheingabe.",
      "Teile Beobachtungen mit dem Agronomen per Sprachaufnahme.",
    ],
  },
  "FitnessAI": {
    "en": [
      "Create a strength training plan for beginners.",
      "Suggest progression for my current weightlifting routine.",
      "Track my gym workouts and adjust reps each week."
    ],
    "hi": [
      "शुरुआती के लिए स्ट्रेंथ ट्रेनिंग प्लान बनाएं।",
      "मौजूदा वजन अभ्यास के लिए बेहतर प्रगति सुझाएं।",
      "मेरे जिम वर्कआउट ट्रैक करें और हर हफ्ते बदलाव करें।"
    ],
    "mr": [
      "नवशिक्यांसाठी स्ट्रेंथ ट्रेनिंग प्लान बनवा.",
      "माझ्या व्यायाम दिनचर्येसाठी सुधारणा सुचवा.",
      "वर्कआउट ट्रॅक करा आणि आठवड्याला पुनरावलोकन करा."
    ],
    "es": [
      "Crea un plan de fuerza para principiantes.",
      "Ajusta el progreso de mi rutina de gimnasio.",
      "Haz seguimiento y adapta mis entrenamientos."
    ],
    "de": [
      "Erstelle einen Trainingsplan für Anfänger.",
      "Empfiehl Fortschritte für mein Krafttraining.",
      "Tracke Workouts und passe die Wiederholungen an."
    ],
  },
  "ComposerTrade": {
    "en": [
      "Design a momentum trading strategy using visual blocks.",
      "Backtest an ETF portfolio before deploying live.",
      "Automate buy and sell rules for your investment plan.",
    ],
    "hi": [
      "विजुअल ब्लॉक्स से ट्रेडिंग रणनीति बनाएं।",
      "ETF पोर्टफोलियो बैकटेस्ट करें और लाइव करें।",
      "खरीद/बिक्री नियम ऑटोमेट करें।",
    ],
    "mr": [
      "व्हिज्युअल ब्लॉक्सने ट्रेडिंग स्ट्रॅटेजी तयार करा.",
      "ETF पोर्टफोलिओचे बॅकटेस्ट करा.",
      "खरेदी-विक्री नियम ऑटोमेट करा.",
    ],
    "es": [
      "Diseña estrategias de trading visualmente.",
      "Backtest para un portafolio de ETFs.",
      "Automatiza reglas de compra y venta.",
    ],
    "de": [
      "Erstelle visuelle Handels-Strategien.",
      "ETF-Portfolio-Backtest durchführen.",
      "Kauf-/Verkaufsregeln automatisieren.",
    ],
  },
  "TradeIdeas": {
    "en": [
      "Scan the US stock market for breakout signals.",
      "Set auto-alerts for new trade opportunities.",
      "View AI-ranked buy and sell trade ideas.",
    ],
    "hi": [
      "ब्रेकआउट सिग्नल के लिए स्टॉक स्कैन करें।",
      "नई ट्रेडिंग अवसर के ऑटो-अलर्ट लगाएं।",
      "AI रैंक किए गए ट्रेडिंग विचार देखें।",
    ],
    "mr": [
      "ब्रेकआउट सिग्नलसाठी स्टॉक्स स्कॅन करा.",
      "नवीन ट्रेडिंग संधीसाठी अलर्ट सेट करा.",
      "AI मूल्यांकित ट्रेडिंग कल्पना बघा.",
    ],
    "es": [
      "Escanea mercado en busca de señales.",
      "Recibe alertas IA de oportunidades.",
      "Ve ideas de trading clasificadas IA.",
    ],
    "de": [
      "Markt nach Ausbruchs-Signalen scannen.",
      "Neue Tradingchancen automatisch melden.",
      "KI-bewertete Kauf/Verkaufs-Ideen anzeigen.",
    ],
  },
  "Sigmoidal": {
    "en": [
      "Run a machine learning forecast on commodities pricing.",
      "Detect unusual trading patterns to prevent fraud.",
      "Analyze historical data for investment insights.",
    ],
    "hi": [
      "कमोडिटी मूल्य के लिए मशीन लर्निंग पूर्वानुमान करें।",
      "असामान्य ट्रेडिंग पैटर्न पहचानें।",
      "निवेश के लिए डेटा का विश्लेषण करें।",
    ],
    "mr": [
      "कमोडिटीसाठी ML वर भाकीत करा.",
      "फ्रॉड प्रिव्हेन्शनसाठी वाइट ट्रेडिंग शोधा.",
      "मागील डेटा परीक्षण करून गुंतवणूक सल्ला घ्या.",
    ],
    "es": [
      "Haz predicción IA sobre precios de materias.",
      "Detecta fraudes en los patrones de trading.",
      "Analiza histórico para invertir mejor.",
    ],
    "de": [
      "Prognose für Rohstoffpreise per KI.",
      "Ungewöhnliche Handelsmuster erkennen.",
      "Datenanalyse für Investitionsentscheide.",
    ],
  },
  "Eginbot": {
    "en": [
      "Deploy a crypto trading bot for automated profits.",
      "Backtest forex algorithms before live trading.",
      "Set stop-loss rules for risk management.",
    ],
    "hi": [
      "ऑटोमेटेड प्रॉफिट के लिए क्रिप्टो बोट लगाएं।",
      "फोरेक्स एल्गोरिद्म बैकटेस्ट करें।",
      "जोखिम प्रबंधन हेतु स्टॉप-लॉस सेट करें।",
    ],
    "mr": [
      "ऑटोमेटेड कमाईसाठी क्रिप्टो बोट वापरा.",
      "फॉरेक्स ट्रेडिंगसाठी बॅकटेस्ट करा.",
      "जोखमीसाठी स्टॉप-लॉस सेट करा.",
    ],
    "es": [
      "Usa un bot IA de trading cripto automático.",
      "Haz backtest con algoritmos para forex.",
      "Define reglas de stop-loss IA.",
    ],
    "de": [
      "Krypto-Bot für automatischen Handel nutzen.",
      "Forex-Strategien vorab testen.",
      "Risiko-Management: Stop-Loss automatisieren.",
    ],
  },
  "TheNewBluilk": {
    "en": [
      "Automate file uploads between cloud apps.",
      "Set up auto-notifications for project status updates.",
      "Sync team calendars and tasks across tools.",
    ],
    "hi": [
      "क्लाउड ऐप्स के बीच फाइल अपलोड ऑटोमेट करें।",
      "प्रोजेक्ट स्टेटस अपडेट्स पर ऑटो-नोटिफिकेशन सेट करें।",
      "टीम कैलेंडर और टास्क्स को सिंक करें।",
    ],
    "mr": [
      "क्लाउड अ‍ॅप्समधील फाइल अपलोड ऑटोमेट करा.",
      "प्रोजेक्ट स्टेटससाठी स्वयंचलित सूचना पाठवा.",
      "टीमचे टास्क व कॅलेंडर सिंक करा.",
    ],
    "es": [
      "Automatiza subidas de archivos entre nubes.",
      "Notifica estados de proyecto automáticamente.",
      "Sincroniza agendas y tareas de equipo.",
    ],
    "de": [
      "Dateiuploads zwischen Cloud-Apps automatisieren.",
      "Automatische Status-Benachrichtigung einrichten.",
      "Team-Kalender & Aufgaben synchronisieren.",
    ],
  },
  "AIbdO": {
    "en": [
      "Run a custom sales data analysis for last quarter.",
      "Automate daily performance reports for teams.",
      "Optimize business workflows with AI-based suggestions.",
    ],
    "hi": [
      "पिछली तिमाही के लिए कस्टम सेल्स विश्लेषण करें।",
      "टीमों के लिए रोज़ रिपोर्ट ऑटोमेट करें।",
      "AI सुझावों से व्यापार वर्कफ्लो ऑप्टिमाइज़ करें।",
    ],
    "mr": [
      "मागील तिमाहीसाठी विक्रीचा डेटा विश्लेषण करा.",
      "टीमसाठी रोजची रिपोर्टिंग ऑटोमेट करा.",
      "AI सुचनांनी वर्कफ्लो ऑप्टिमाइझ करा.",
    ],
    "es": [
      "Analiza ventas del último trimestre con IA.",
      "Automatiza reportes diarios del equipo.",
      "Optimiza procesos con sugerencias IA.",
    ],
    "de": [
      "Umsatzdaten vom letzten Quartal auswerten.",
      "Täglich Teamberichte automatisieren.",
      "Workflows mit KI-Empfehlungen optimieren.",
    ],
  },
  "CureFit": {
    "en": [
      "Book a live online workout class.",
      "Get healthy vegetarian recipes via AI.",
      "Log my yoga, sleep and calorie data daily."
    ],
    "hi": [
      "लाइव ऑनलाइन वर्कआउट क्लास बुक करें।",
      "AI से हेल्दी वेज रेसिपी पाएं।",
      "रोज़ाना योग, नींद व कैलोरी लॉग करें।"
    ],
    "mr": [
      "लाइव्ह ऑनलाइन वर्कआउट क्लास बुक करा.",
      "AI द्वारे हेल्दी रेसिपी मिळवा.",
      "रोज योगा, झोप आणि कॅलरी लॉग करा."
    ],
    "es": [
      "Reserva una clase de ejercicio en vivo.",
      "Solicita recetas saludables.",
      "Registra yoga, sueño y calorías cada día."
    ],
    "de": [
      "Buche einen Live-Workout-Kurs.",
      "Erhalte gesunde Rezepte per KI.",
      "Tägliches Yoga, Schlaf und Kalorien dokumentieren."
    ],
  },
  "Perplexity": {
    "en": [
      "Summarize the latest breakthroughs in renewable energy research.",
      "List the pros and cons of electric vs. hydrogen vehicles.",
      "What are recent studies on the effectiveness of online education?",
      "Find key statistics on remote work productivity.",
      "Explain the causes and effects of inflation with sources."
    ],
    "hi": [
      "नवीकरणीय ऊर्जा अनुसंधान में नवीनतम प्रगति का सारांश दें।",
      "इलेक्ट्रिक और हाइड्रोजन वाहनों की तुलना करें (फायदे-नुकसान)।",
      "ऑनलाइन शिक्षा की प्रभावशीलता पर हाल की स्टडीज़ खोजें।",
      "रिमोट वर्क उत्पादकता के मुख्य आंकड़े बताएं।",
      "मुद्रास्फीति के कारण और प्रभाव स्रोत सहित समझाएं।"
    ],
    "mr": [
      "नवीनीकरणीय ऊर्जा संशोधनातील प्रमुख घडामोडी संक्षेप करा.",
      "इलेक्ट्रिक व हायड्रोजन वाहनांची तुलना (फायदे-तोटे) सांगा.",
      "ऑनलाईन शिक्षणाच्या परिणामकारकतेवरील अलीकडील अभ्यास शोधा.",
      "रिमोट कामाच्या उत्पादकतेची मुख्य आकडेवारी द्या.",
      "महागाईची कारणे व परिणाम स्रोतांसह समजावून सांगा."
    ],
    "es": [
      "Resume los últimos avances en investigación de energías renovables.",
      "Enumera ventajas y desventajas de autos eléctricos vs. de hidrógeno.",
      "¿Cuáles son los estudios recientes sobre la efectividad de la educación online?",
      "Muestra estadísticas clave sobre productividad en trabajo remoto.",
      "Explica causas y efectos de la inflación con fuentes."
    ],
    "de": [
      "Fasse die neuesten Durchbrüche bei erneuerbaren Energien zusammen.",
      "Nenne Vor- und Nachteile von Elektro- vs. Wasserstofffahrzeugen.",
      "Was sagen aktuelle Studien zur Wirksamkeit von Online-Bildung?",
      "Zeige wichtige Statistiken zur Produktivität im Homeoffice.",
      "Erkläre Ursachen und Auswirkungen der Inflation mit Quellen."
    ],
    // Add additional languages as needed
  },
  "ManusAI": {
    "en": [
      "Create a to-do list app from scratch with templates.",
      "Build a fitness tracking app without coding.",
    ],
    "hi": [
      "टेम्पलेट से टु-डू लिस्ट ऐप बनाएं।",
      "कोड के बिना फिटनेस ट्रैकर ऐप तैयार करें।",
    ],
    "mr": [
      "टेम्पलेटवर नवीन अ‍ॅप तयार करा.",
      "कोड न वापरता फिटनेस अ‍ॅप बनवा.",
    ],
    "es": [
      "Crea una app de tareas desde cero.",
      "Haz una app de fitness sin código.",
    ],
    "de": [
      "Erstelle To-Do-Listen-App mit Vorlage.",
      "Fitness-App ohne Programmieren bauen.",
    ],
  },
  "FirebaseJotform": {
    "en": [
      "Build a job application form and connect to database.",
      "Generate analytics dashboard for survey results.",
    ],
    "hi": [
      "जॉब फॉर्म बनाएं, डाटाबेस से जोड़ें।",
      "सर्वे डेटा के लिए डैशबोर्ड बनाएं।",
    ],
    "mr": [
      "जॉब फॉर्म व डाटाबेस कनेक्ट करा.",
      "सर्वे डॅशबोर्ड तयार करा.",
    ],
    "es": [
      "Crea formulario de empleo y conecta base.",
      "Haz paneles de resultados de encuestas.",
    ],
    "de": [
      "Bewerbungsformular mit Datenbank verbinden.",
      "Analyse-Dashboard für Umfrage generieren.",
    ],
  },
  "Uizard": {
    "en": [
      "Turn this napkin sketch into a working prototype.",
      "Convert user flow description to app design.",
    ],
    "hi": [
      "स्केच से प्रोटोटाइप बनाएं।",
      "यूजर फ्लो को डिज़ाइन में बदलें।",
    ],
    "mr": [
      "स्केचवरून प्रोटोटाइप तयार करा.",
      "डिझाईनमध्ये यूजर फ्लो रूपांतरित करा.",
    ],
    "es": [
      "Haz prototipo desde un boceto.",
      "Convierte descripción en diseño app.",
    ],
    "de": [
      "Mache aus Skizze einen Prototyp.",
      "Userflow-Beschreibung in App-Design umwandeln.",
    ],
  },
  "CreateXYZ": {
    "en": [
      "Describe a budgeting tool and auto-generate the app.",
      "Make a simple weather widget from a plain prompt.",
    ],
    "hi": [
      "बजट टूल लिखें, ऐप ऑटो-बनाएं।",
      "सिर्फ़ वाक्य से वेदर विजेट बनाएं।",
    ],
    "mr": [
      "बजेट टूलचे वर्णन करा, अ‍ॅप तयार करा.",
      "सोपी माहिती देऊन हवामान विजेट बनवा.",
    ],
    "es": [
      "Describe herramienta y genera app IA.",
      "Haz un widget del tiempo desde una frase.",
    ],
    "de": [
      "Beschreibe ein Tool, App wird erstellt.",
      "Einfaches Wetter-Widget aus Prompts bauen.",
    ],
  },
  "TensorFlow": {
    "en": [
      "Build a neural network for image classification.",
      "Create and train a chatbot with TensorFlow.",
    ],
    "hi": [
      "इमेज क्लासिफिकेशन के लिए न्यूरल नेटवर्क बनाएं।",
      "TensorFlow से चैटबॉट तैयार करें।",
    ],
    "mr": [
      "प्रतिमा वर्गीकरणसाठी न्यूरल नेटवर्क तयार करा.",
      "TensorFlow ने चॅटबॉट ट्रेन करा.",
    ],
    "es": [
      "Crea red neuronal para imágenes IA.",
      "Entrena un chatbot con TensorFlow.",
    ],
    "de": [
      "Neuronales Netz zur Bilderkennung bauen.",
      "Chatbot mit TensorFlow trainieren.",
    ],
  },
  "Bubble": {
    "en": [
      "Design a task management web-app visually.",
      "Add AI chatbot to your Bubble project.",
    ],
    "hi": [
      "टास्क मैनेजमेंट वेब-ऐप डिजाइन करें।",
      "Bubble ऐप में AI चैटबॉट जोड़ें।",
    ],
    "mr": [
      "टास्क मॅनेजमेंट वेबसाईट करा.",
      "Bubble प्रकल्पात AI chatbot जोडा.",
    ],
    "es": [
      "Diseña app web de tareas visualmente.",
      "Agrega chatbot IA a tu proyecto Bubble.",
    ],
    "de": [
      "Visuell Web-App zum Aufgabenmanagement bauen.",
      "Füge AI-Chatbot in Bubble-Projekt ein.",
    ],
  },
  "GitHubCopilot": {
    "en": [
      "Autocomplete a REST API route in Python.",
      "Suggest tests for my login controller.",
    ],
    "hi": [
      "Python में REST API रूट ऑटोकम्प्लीट करें।",
      "मेरे लॉगिन कंट्रोलर के लिए टेस्ट सुझाएँ।",
    ],
    "mr": [
      "Python मध्ये REST API मार्ग ऑटो-कम्प्लीट करा.",
      "लॉगिन कंट्रोलरसाठी टेस्ट सुचवा.",
    ],
    "es": [
      "Autocompleta rutas API REST en Python.",
      "Sugiere tests para mi login controller.",
    ],
    "de": [
      "REST-API-Routen für Python vervollständigen.",
      "Testfälle für Login-Controller vorschlagen.",
    ],
  },
  "ChatGPT1": {
    "en": [
      "Explain quantum computing in simple terms.",
      "Write a cover letter for a software developer role.",
      "Suggest ideas for a birthday party plan.",
      "Summarize the key points from this news article.",
      "Draft an apology email to a client."
    ],
    "hi": [
      "क्वांटम कंप्यूटिंग को सरल शब्दों में समझाएं।",
      "सॉफ्टवेयर डेवलपर भूमिका के लिए एक कवर लेटर लिखें।",
      "बर्थडे पार्टी की योजनाओं के लिए सुझाव दें।",
      "इस समाचार लेख के मुख्य बिंदु सारांशित करें।",
      "क्लाइंट को माफ़ी मांगते हुए ईमेल लिखें।"
    ],
    "mr": [
      "क्वांटम संगणन सोप्या शब्दात समजावून सांगा.",
      "सॉफ्टवेअर डेव्हलपर पदासाठी कव्हर लेटर लिहा.",
      "वाढदिवसाच्या पार्टीसाठी कल्पना सुचवा.",
      "या बातमीचे मुख्य मुद्दे संक्षेप करा.",
      "ग्राहकाला क्षमायाचना करणारे ईमेल लिहा."
    ],
    "es": [
      "Explica la computación cuántica en términos simples.",
      "Escribe una carta de presentación para un puesto de desarrollador de software.",
      "Sugiere ideas para una fiesta de cumpleaños.",
      "Resume los puntos clave de este artículo de noticias.",
      "Redacta un correo de disculpa para un cliente."
    ],
    "de": [
      "Erkläre Quantencomputing in einfachen Worten.",
      "Schreibe ein Anschreiben für die Stelle als Softwareentwickler.",
      "Mache Vorschläge für eine Geburtstagsfeier.",
      "Fassen Sie die wichtigsten Punkte dieses Nachrichtenartikels zusammen.",
      "Verfassen Sie eine Entschuldigungsmail an einen Kunden."
    ],
  },
  "Plerplexit": {
    "en": [
      "Summarize recent advances in artificial intelligence.",
      "What are common use cases for large language models?",
      "List scientific papers about renewable energy breakthroughs.",
      "Compare the top five chatbot frameworks for developers.",
      "Find the most cited authors in modern physics."
    ],
    "hi": [
      "कृत्रिम बुद्धिमत्ता में हालिया प्रगति का सारांश दें।",
      "लार्ज लैंग्वेज मॉडल के आम उपयोग मामलों की सूची बनाएं।",
      "नवीकरणीय ऊर्जा की खोजों पर वैज्ञानिक पत्रों को सूचीबद्ध करें।",
      "डेवलपर्स के लिए शीर्ष 5 चैटबोट फ़्रेमवर्क्स की तुलना करें।",
      "आधुनिक भौतिकी में सबसे अधिक उद्धृत लेखकों का पता करें।"
    ],
    "mr": [
      "कृत्रिम बुद्धिमत्तेतील अलीकडील प्रगतीचे संक्षेप करा.",
      "मोठ्या भाषिक मॉडेल्ससाठी सामान्य उपयोग प्रकरणे कोणती आहेत?",
      "नवीकरणीय ऊर्जेच्या शोधांवरील शास्त्रीय कागदांची यादी करा.",
      "डेव्हलपर्ससाठी टॉप ५ चॅटबॉट फ्रेमवर्क्सची तुलना करा.",
      "आधुनिक भौतिकशास्त्रातील सर्वाधिक उद्धृत लेखक मिळवा."
    ],
    "es": [
      "Resume los avances recientes en inteligencia artificial.",
      "¿Cuáles son los casos de uso comunes de los grandes modelos lingüísticos?",
      "Lista artículos científicos sobre innovaciones en energía renovable.",
      "Compara los cinco principales frameworks de chatbot para desarrolladores.",
      "Encuentra los autores más citados en física moderna."
    ],
    "de": [
      "Fassen Sie die jüngsten Fortschritte in der künstlichen Intelligenz zusammen.",
      "Welche sind die häufigsten Anwendungsfälle für große Sprachmodelle?",
      "Listen Sie wissenschaftliche Arbeiten zu Durchbrüchen in erneuerbarer Energie auf.",
      "Vergleichen Sie die fünf wichtigsten Chatbot-Frameworks für Entwickler.",
      "Finden Sie die meistzitierten Autoren in der modernen Physik."
    ],
  },
  "HealthifyMe": {
    "en": [
      "Generate a meal plan for diabetes management.",
      "Track calories for a weight loss goal.",
      "Connect with a personal AI nutrition coach.",
    ],
    "hi": [
      "डायबिटीज नियंत्रण के लिए भोजन योजना बनाएं।",
      "वजन घटाने का लक्ष्य हेतु कैलोरी ट्रैक करें।",
      "AI पोषण कोच से जुड़ें।",
    ],
    "mr": [
      "डायबिटीजसाठी आहार योजना तयार करा.",
      "वजन कमी करण्यासाठी कॅलरीज ट्रॅक करा.",
      "व्यक्तिगत AI पोषण कोचशी जोडा.",
    ],
    "es": [
      "Genera un plan alimenticio para la diabetes.",
      "Controla calorías para bajar de peso.",
      "Contacta un coach nutricional IA.",
    ],
    "de": [
      "Erstelle einen Ernährungsplan für Diabetes.",
      "Kalorien für ein Abnehmziel tracken.",
      "Mit dem KI-Ernährungscoach verbinden.",
    ],
  },
  "EdApp": {
    "en": [
      "Build a microlearning course on workplace safety.",
      "Assign AI-personalized training for sales teams.",
      "Track completion rates and assessment scores."
    ],
    "hi": [
      "वर्कप्लेस सुरक्षा पर शॉर्ट कोर्स बनाएं।",
      "सेल्स टीम के लिए AI से पर्सनल ट्रेनिंग दें।",
      "अभ्यास पूर्णता व स्कोर ट्रैक करें।"
    ],
    "mr": [
      "वर्कप्लेस सेफ्टीवरील कोर्स बनवा.",
      "AI वापरून सेल्स टीमला प्रशिक्षण द्या.",
      "समाप्त केलेली मॉड्यूल्स व गुण तपासा."
    ],
    "es": [
      "Crea un curso breve sobre seguridad laboral.",
      "Asigna formaciones personalizadas por IA.",
      "Monitorea finalización y resultados."
    ],
    "de": [
      "Erstelle Microlearning-Kurse für Arbeitssicherheit.",
      "Individuelle KI-Trainings an Teams zuweisen.",
      "Abschlussquoten im Blick behalten."
    ],
  },
  "PathAI": {
    "en": [
      "Analyze this biopsy slide for potential cancerous cells.",
      "Generate a diagnostic report for a pathology image.",
      "Compare sample images for disease markers.",
    ],
    "hi": [
      "कैंसर सेल्स के लिए इस बायोप्सी स्लाइड का विश्लेषण करें।",
      "पैथोलॉजी छवि के लिए निदान रिपोर्ट बनाएं।",
      "रोग मार्कर के लिए छवियों की तुलना करें।",
    ],
    "mr": [
      "कर्करोग पेशींसाठी ही बायोप्सी स्लाइड निवडा.",
      "पॅथॉलॉजी इमेजसाठी निदान अहवाल तयार करा.",
      "रोग मार्कर्स साठी प्रतिमा तुलना करा.",
    ],
    "es": [
      "Analiza esta biopsia para células cancerosas.",
      "Genera un reporte diagnóstico de una imagen patológica.",
      "Compara imágenes en busca de marcadores de enfermedad.",
    ],
    "de": [
      "Analysiere diesen Biopsie-Schnitt auf Krebszellen.",
      "Erzeuge einen Diagnosebericht für ein Pathologiebild.",
      "Vergleiche Probenbilder auf Krankheitsmarker.",
    ],
  },
  "ETlitic": {
    "en": [
      "Screen a chest X-ray for pneumonia indicators.",
      "Detect bone fractures in uploaded images.",
      "Summarize abnormal findings in a CT scan.",
    ],
    "hi": [
      "न्युमोनिया के संकेत के लिए छाती एक्स-रे की जांच करें।",
      "अपलोड की गई छवियों में हड्डी के फ्रैक्चर डिटेक्ट करें।",
      "सीटी स्कैन में असामान्य परिणामों का सारांश बनाएं।",
    ],
    "mr": [
      "न्युमोनियासाठी छातीचा एक्स-रे तपासा.",
      "अपलोड चित्रात हाडांचे फ्रॅक्चर ओळखा.",
      "सीटी स्कॅनमध्ये असामान्य शोधांचे सार संक्षेप करा.",
    ],
    "es": [
      "Analiza una radiografía de tórax para neumonía.",
      "Detecta fracturas en imágenes médicas.",
      "Resume hallazgos anormales en un CT.",
    ],
    "de": [
      "Lungenentzündung in einem Röntgenbild erkennen.",
      "Knochenbrüche in Bildern finden.",
      "Abnormale Befunde im CT-Scan zusammenfassen.",
    ],
  },
  "Blackbox": {
    "en": [
      "Generate code for a login form in React.",
      "Explain this block of Python code.",
      "Convert this JavaScript snippet into Python.",
      "Detect bugs in my sorting algorithm implementation.",
      "Suggest optimizations for a SQL database query."
    ],
    "hi": [
      "React में लॉगिन फ़ॉर्म के लिए कोड जनरेट करें।",
      "इस पायथन कोड ब्लॉक को समझाएं।",
      "इस जावास्क्रिप्ट स्निपेट को पायथन में बदलें।",
      "मेरे सॉर्टिंग एल्गोरिदम में बग्स निकालें।",
      "SQL डेटाबेस क्वेरी के लिए सुधार सुझाएँ।"
    ],
    "mr": [
      "React मध्ये लॉगिन फॉर्मसाठी कोड तयार करा.",
      "हा Python कोड समजावून सांगा.",
      "हा JavaScript कोड Python मध्ये रूपांतरित करा.",
      "माझ्या सॉर्टिंग अल्गोरिदममधील बग शोधा.",
      "SQL डेटाबेस क्वेरीसाठी ऑप्टिमायझेशन सुचवा."
    ],
    "es": [
      "Genera código para un formulario de inicio de sesión en React.",
      "Explica este bloque de código Python.",
      "Convierte este fragmento de JavaScript a Python.",
      "Detecta errores en mi implementación de algoritmo de ordenamiento.",
      "Sugiere optimizaciones para una consulta SQL."
    ],
    "de": [
      "Generiere Code für ein Login-Formular in React.",
      "Erkläre diesen Python-Codeblock.",
      "Wandle diesen JavaScript-Code in Python um.",
      "Finde Fehler in meinem Sortieralgorithmus.",
      "Schlage Optimierungen für eine SQL-Abfrage vor."
    ],
  },
  "Grammarly": {
    "en": [
      "Check this paragraph for grammar mistakes.",
      "Suggest improvements for formal writing.",
      "Analyze my email for tone and clarity.",
      "Rewrite this sentence to be more concise.",
      "Is this business letter free of spelling errors?"
    ],
    "hi": [
      "इस अनुच्छेद को व्याकरणिक错误 के लिए जांचें।",
      "औपचारिक लेखन के लिए सुधार सुझाएँ।",
      "मेरे ईमेल का टोन और स्पष्टता विश्लेषित करें।",
      "इस वाक्य को और संक्षिप्त बनाएं।",
      "क्या यह बिज़नेस लेटर वर्तनी की ग़लतियों से मुक्त है?"
    ],
    "mr": [
      "या परिच्छेदात व्याकरणाच्या चुका तपासा.",
      "औपचारिक लेखनासाठी सुधारणा सुचवा.",
      "माझ्या ई-मेलचे टोन व स्पष्टता तपासा.",
      "हे वाक्य संक्षिप्तरित्या लिहा.",
      "हे व्यवसाय पत्र शुद्धलेखन चुका-मुक्त आहे का?"
    ],
    "es": [
      "Revisa este párrafo por errores gramaticales.",
      "Sugiere mejoras para redacción formal.",
      "Analiza el tono y la claridad de mi correo.",
      "Reescribe esta oración para que sea más concisa.",
      "¿Esta carta empresarial está libre de errores ortográficos?"
    ],
    "de": [
      "Überprüfen Sie diesen Absatz auf Grammatikfehler.",
      "Schlagen Sie Verbesserungen für formales Schreiben vor.",
      "Analysieren Sie meine E-Mail auf Ton und Klarheit.",
      "Formulieren Sie diesen Satz kürzer.",
      "Ist dieser Geschäftsbrief frei von Rechtschreibfehlern?"
    ],
  },
  "Canva": {
    "en": [
      "Design a logo for a bakery.",
      "Create a poster for a science fair.",
      "Make a business card for a freelance photographer.",
      "Generate a flyer for an online course.",
      "Build an Instagram post for Earth Day."
    ],
    "hi": [
      "बेकरी के लिए एक लोगो डिज़ाइन करें।",
      "साइंस फेयर के लिए पोस्टर बनाएं।",
      "फ़्रीलांस फ़ोटोग्राफर के लिए विजिटिंग कार्ड बनाएं।",
      "ऑनलाइन कोर्स के लिए फ्लायर तैयार करें।",
      "अर्थ डे के लिए इंस्टाग्राम पोस्ट तैयार करें।"
    ],
    "mr": [
      "बेकरीसाठी लोगो डिझाइन करा.",
      "सायन्स फेअरसाठी पोस्टर तयार करा.",
      "फ्रीलान्स फोटोग्राफरसाठी व्हिजिटिंग कार्ड बनवा.",
      "ऑनलाईन कोर्ससाठी फ्लायर तयार करा.",
      "अर्थ डे साठी Instagram पोस्ट तयार करा."
    ],
    "es": [
      "Diseña un logo para una panadería.",
      "Crea un cartel para una feria de ciencias.",
      "Haz una tarjeta de visita para un fotógrafo freelance.",
      "Genera un folleto para un curso en línea.",
      "Crea una publicación de Instagram sobre el Día de la Tierra."
    ],
    "de": [
      "Gestalten Sie ein Logo für eine Bäckerei.",
      "Erstellen Sie ein Poster für einen Wissenschaftswettbewerb.",
      "Erstellen Sie eine Visitenkarte für einen freiberuflichen Fotografen.",
      "Erstellen Sie einen Flyer für einen Online-Kurs.",
      "Erstellen Sie einen Instagram-Post für den Earth Day."
    ],
  },
  "Khromo": {
    "en": [
      "Suggest a modern color palette for a travel app.",
      "Generate a color theme inspired by nature.",
      "Pick brand colors for a tech startup.",
      "Recommend a palette for a minimalist website.",
      "Combine warm and cool shades for a summer campaign."
    ],
    "hi": [
      "ट्रैवल ऐप के लिए आधुनिक रंग पैलेट सुझाएँ।",
      "प्रकृति से प्रेरित रंग थीम तैयार करें।",
      "टेक स्टार्टअप के लिए ब्रांड रंग चुनें।",
      "मिनिमलिस्ट वेबसाइट के लिए पैलेट सुझाएँ।",
      "समर कैंपेन के लिए गर्म और ठंडे रंग मिलाएँ।"
    ],
    "mr": [
      "प्रवास अ‍ॅपसाठी आधुनिक रंगस्कीम सुचवा.",
      "निसर्गावर आधारित रंग थीम तयार करा.",
      "टेक स्टार्टअपसाठी ब्रँड रंग निवडा.",
      "मिनिमलिस्ट वेबसाइटसाठी रंगसंयोजन द्या.",
      "उन्हाळी मोहिमेसाठी तापमान आणि गार रंग एकत्र करा."
    ],
    "es": [
      "Sugiere una paleta moderna para una app de viajes.",
      "Genera una paleta inspirada en la naturaleza.",
      "Elige colores de marca para una startup tecnológica.",
      "Recomienda una paleta para un sitio minimalista.",
      "Combina tonos cálidos y fríos para una campaña veraniega."
    ],
    "de": [
      "Schlagen Sie eine moderne Farbpalette für eine Reise-App vor.",
      "Generieren Sie eine von der Natur inspirierte Farbgebung.",
      "Wählen Sie Markenfarben für ein Tech-Startup.",
      "Empfehlen Sie eine Palette für eine minimalistische Website.",
      "Kombinieren Sie warme und kühle Farbtöne für eine Sommerkampagne."
    ],
  },
  "VirtalStaging": {
    "en": [
      "Stage a modern living room virtually for real estate.",
      "Visualize furniture arrangement options for a small apartment.",
      "Simulate different color schemes for a bedroom.",
      "Create a 3D-render of a renovated kitchen.",
      "Preview open-space concepts for a new property listing."
    ],
    "hi": [
      "रियल एस्टेट के लिए आधुनिक लिविंग रूम वर्चुअली सजाएँ।",
      "छोटे अपार्टमेंट के लिए फर्नीचर के विकल्प देखें।",
      "शयनकक्ष के लिए विभिन्न रंग योजनाएँ प्रदर्शित करें।",
      "नवीन रसोई का 3D-रेंडर तैयार करें।",
      "नई प्रोपर्टी लिस्टिंग के लिए ओपन-स्पेस कॉन्सेप्ट का पूर्वावलोकन करें।"
    ],
    "mr": [
      "रिअल इस्टेटसाठी आधुनिक लिव्हिंग रूम वर्च्युअली सेट करा.",
      "लहान अपार्टमेंटसाठी फर्निचर व्यवस्थेचे पर्याय पहा.",
      "बेडरूमसाठी विविध रंगयोजना दाखवा.",
      "नुतनीकृत स्वयंपाकघराचे 3D-रेंडर करा.",
      "नवीन मालमत्ता लिस्टिंगसाठी ओपन-स्पेस संकल्पना पहा."
    ],
    "es": [
      "Escenifica virtualmente una sala moderna para inmobiliarias.",
      "Visualiza opciones de mobiliario para un departamento pequeño.",
      "Simula diferentes esquemas de color para un dormitorio.",
      "Crea un render 3D de una cocina renovada.",
      "Previsualiza conceptos de espacio abierto para nuevas propiedades."
    ],
    "de": [
      "Richten Sie ein modernes Wohnzimmer für Immobilien virtuell ein.",
      "Visualisieren Sie Möbeloptionen für eine kleine Wohnung.",
      "Simulieren Sie verschiedene Farbkonzepte für ein Schlafzimmer.",
      "Erstellen Sie ein 3D-Rendering einer renovierten Küche.",
      "Vorschau auf Open-Space-Konzepte für ein neues Immobilienangebot."
    ],
  },
  "CivilsAI": {
    "en": [
      "Analyze bridge safety using AI data models.",
      "Suggest sustainable materials for infrastructure projects.",
      "Predict maintenance needs for urban roadways.",
      "Evaluate potential risks for a new dam construction.",
      "Optimize city park design for foot traffic."
    ],
    "hi": [
      "AI डेटा मॉडल से पुल की सुरक्षा विश्लेषित करें।",
      "बुनियादी ढांचे के लिए टिकाऊ सामग्री सुझाएँ।",
      "शहरी सड़कों के रखरखाव की आवश्यकता का पूर्वानुमान करें।",
      "नई बांध परियोजना के जोखिम का मूल्यांकन करें।",
      "शहर पार्क के पैदल यात्री डिजाइन का अनुकूलन करें।"
    ],
    "mr": [
      "AI डेटा मॉडेल्सचा वापर करून ब्रिज सेफ्टीचे विश्लेषण करा.",
      "इन्फ्रास्ट्रक्चर प्रकल्पांसाठी शाश्वत साहित्य सूचवा.",
      "शहरी रस्त्यांच्या देखरेखीच्या गरजांचा अंदाज लावा.",
      "नवीन धरण प्रकल्पाच्या जोखमीचे मूल्यांकन करा.",
      "शहरातील पार्कचे डिझाईन रहदारीसाठी ऑप्टिमाइझ करा."
    ],
    "es": [
      "Analiza la seguridad de puentes con modelos IA.",
      "Sugiere materiales sostenibles para proyectos de infraestructura.",
      "Predice necesidades de mantenimiento en calles urbanas.",
      "Evalúa riesgos de construir una nueva presa.",
      "Optimiza el diseño del parque para el tráfico peatonal."
    ],
    "de": [
      "Analysieren Sie die Brückensicherheit mit KI-Datenmodellen.",
      "Schlagen Sie nachhaltige Materialien für Infrastrukturprojekte vor.",
      "Prognostizieren Sie Wartungsbedarf für städtische Straßen.",
      "Bewerten Sie Risiken beim Bau eines neuen Damms.",
      "Optimieren Sie das Design von Stadtparks für Fußgänger."
    ],
  },
  "ChatAI": {
    "en": [
      "What are the steps to apply for a building permit?",
      "How can I file a civic complaint online?",
      "List the top citizen services available in my locality.",
      "What documents are needed for property tax registration?",
      "How to track road repair requests in my ward?"
    ],
    "hi": [
      "बिल्डिंग परमिट के लिए आवेदन करने के स्टेप्स क्या हैं?",
      "ऑनलाइन नागरिक शिकायत कैसे दर्ज करें?",
      "मेरे क्षेत्र में उपलब्ध प्रमुख नागरिक सेवाओं की सूची बनाएं।",
      "संपत्ति टैक्स पंजीकरण के लिए कौन-कौन से दस्तावेज जरूरी हैं?",
      "अपने वार्ड में सड़क मरम्मत अनुरोध कैसे ट्रैक करें?"
    ],
    "mr": [
      "बिल्डिंग परमिटसाठी अर्ज कसा करावा?",
      "नागरिक तक्रार ऑनलाइन कशी दाखल करावी?",
      "माझ्या परिसरातील मुख्य नागरिक सेवा कोणत्या आहेत?",
      "मालमत्ता कर नोंदणीसाठी कोणते दस्तऐवज लागतात?",
      "माझ्या वॉर्डमध्ये रस्ता दुरुस्तीची मागणी कशी ट्रॅक करावी?"
    ],
    "es": [
      "¿Cuáles son los pasos para solicitar un permiso de construcción?",
      "¿Cómo presento una queja ciudadana en línea?",
      "Enumera los principales servicios ciudadanos en mi área.",
      "¿Qué documentos se requieren para registrar el impuesto de propiedad?",
      "¿Cómo rastrear las solicitudes de reparación de carreteras en mi distrito?"
    ],
    "de": [
      "Welche Schritte sind notwendig, um eine Baugenehmigung zu beantragen?",
      "Wie reiche ich eine Bürgerbeschwerde online ein?",
      "Nennen Sie die wichtigsten Bürgerdienste in meiner Region.",
      "Welche Dokumente sind für die Grundsteueranmeldung erforderlich?",
      "Wie kann ich Straßenreparaturanfragen in meinem Bezirk verfolgen?"
    ],
  },
  "roamaround": {
    "en": [
      "Suggest the best room layout for a 5-person family trip to Paris.",
      "Find shared private rooms near city center under .",
      "Organize space for friends traveling together to Tokyo."
    ],
    "hi": [
      "पेरिस यात्रा के लिए 5 लोगों के परिवार हेतु सबसे अच्छा रूम लेआउट सुझाएँ।",
      "सिटी सेंटर के पास  से कम में साझा प्राइवेट रूम खोजें।",
      "दोस्तों के साथ टोक्यो यात्रा के लिए जगह का आयोजन करें।"
    ],
    "mr": [
      "पॅरिसमध्ये ५ जणांच्या कुटुंबासाठी सर्वोत्तम रूम लेआउट सांगा.",
      "खाली सिटी सेंटरजवळ शेअर रूम शोधा.",
      "टोkyo प्रवासी मित्रांसाठी जागा आयोजन करा."
    ],
    "es": [
      "Sugiere la mejor distribución de habitaciones para una familia de 5 en París.",
      "Encuentra habitaciones compartidas cerca del centro de la ciudad por menos de .",
      "Organiza el espacio para un grupo de amigos viajando a Tokio."
    ],
    "de": [
      "Schlage das beste Zimmer-Layout für eine 5-köpfige Familie in Paris vor.",
      "Finde geteilte Zimmer nahe Stadtzentrum unter ",
      "Organisiere den Raum für Freunde, die gemeinsam nach Tokio reisen."
    ],
  },
  "VaeayChatbot": {
    "en": [
      "What are some unique local experiences in Rome?",
      "Where should I eat vegetarian food in Bangkok?",
      "What is the best time to visit the pyramids in Egypt?"
    ],
    "hi": [
      "रोम में कुछ अनोखे स्थानीय अनुभव क्या हैं?",
      "बैंकॉक में शाकाहारी भोजन कहाँ खाएँ?",
      "मिस्र के पिरामिड देखने का सबसे अच्छा समय क्या है?"
    ],
    "mr": [
      "रोममध्ये स्थानिक अनोखी अनुभव कोणती आहेत?",
      "बँकॉकमध्ये शाकाहारी जेवण कुठे मिळेल?",
      "इजिप्तमधील पिरॅमिड पाहण्याचा सर्वोत्तम कालावधी कोणता?"
    ],
    "es": [
      "¿Cuáles son experiencias locales únicas en Roma?",
      "¿Dónde comer comida vegetariana en Bangkok?",
      "¿Cuál es el mejor momento para visitar las pirámides de Egipto?"
    ],
    "de": [
      "Was sind besondere lokale Erlebnisse in Rom?",
      "Wo gibt es vegetarisches Essen in Bangkok?",
      "Wann ist die beste Zeit, die Pyramiden in Ägypten zu besuchen?"
    ],
  },
  "TripPlannerAI": {
    "en": [
      "Plan a 7-day trip to Japan covering Tokyo, Kyoto, and Osaka.",
      "Generate a weekend getaway itinerary for a couple in Barcelona.",
      "Suggest a day-by-day Paris trip for a family with kids.",
    ],
    "hi": [
      "टोक्यो, क्योटो और ओसाका के लिए 7-दिन की जापान यात्रा की योजना बनाएं।",
      "एक कपल के लिए बार्सिलोना में वीकेंड गेटअवे योजना बनाएं।",
      "बच्चों के साथ परिवार के लिए पेरिस यात्रा की दिन-प्रतिदिन योजना बताएं।"
    ],
    "mr": [
      "टोक्यो, क्योटो व ओसाका यांसाठी ७ दिवसांची जपान ट्रिप बनवा.",
      "बार्सिलोनात जोडप्यांसाठी वीकेंड ट्रिप तयार करा.",
      "मुलांसह कुटुंबासाठी दिवसागणिक पॅरिस ट्रिप सांगा."
    ],
    "es": [
      "Planifica un viaje de 7 días en Japón pasando por Tokio, Kioto y Osaka.",
      "Genera un itinerario de fin de semana en Barcelona para una pareja.",
      "Sugiere un viaje día a día por París para una familia con niños."
    ],
    "de": [
      "Plane eine 7-tägige Japanreise mit Tokio, Kyoto und Osaka.",
      "Erstelle eine Wochenendreise für ein Paar in Barcelona.",
      "Schlage einen Tagesplan für Paris mit Kindern vor."
    ],
  },
  "The Newbluilk": {
    "en": [
      "Write about a moment when you felt truly passionate.",
      "Reflect on a recent hobby that made you excited.",
      "Describe your dream project and the steps to achieve it.",
    ],
    "hi": [
      "उस क्षण के बारे में लिखें जब आप सबसे ज़्यादा जुनूनी महसूस कर रहे थे।",
      "अभी-अभी की किसी हॉबी पर विचार करें जिससे आप उत्साहित हुए।",
      "अपने ड्रीम प्रोजेक्ट और उसे पाने के कदम लिखें।",
    ],
    "mr": [
      "तुम्ही कधी अत्यंत उत्कट अनुभवलात, त्या क्षणावर लिहा.",
      "अलीकडील छंदाबद्दल लिहा ज्याने तुम्ही उत्साहित झाला.",
      "तुमच्या स्वप्नातील प्रकल्पाचे वर्णन करा आणि तो साध्य करण्याची पावले लिहा.",
    ],
    "es": [
      "Escribe sobre un momento en el que sentiste verdadera pasión.",
      "Reflexiona sobre un pasatiempo reciente que te emocionó.",
      "Describe tu proyecto ideal y los pasos para lograrlo.",
    ],
    "de": [
      "Schreibe über einen Moment, in dem du echte Leidenschaft gefühlt hast.",
      "Reflektiere über ein Hobby, das dich begeistert hat.",
      "Beschreibe dein Traumprojekt und wie du es umsetzt.",
    ],
  },
  "AlbdO": {
    "en": [
      "Suggest a creative story idea involving time travel.",
      "Give me a poetic prompt inspired by the night sky.",
      "Propose an artistic theme for a digital illustration.",
    ],
    "hi": [
      "समय यात्रा से जुड़ी रचनात्मक कहानी का विचार दें।",
      "रात के आसमान से प्रेरित काव्यात्मक संकेत दें।",
      "डिजिटल चित्र के लिए एक कलात्मक थीम प्रस्तावित करें।",
    ],
    "mr": [
      "टाइम ट्रॅव्हलवर आधारित कल्पक कथा सांग.",
      "रात्रीच्या आकाशावरून प्रेरित कविता सुचवा.",
      "डिजिटल चित्रासाठी एक कलात्मक थीम सुचवा.",
    ],
    "es": [
      "Sugiere una idea de historia creativa sobre viajes en el tiempo.",
      "Dame un tema poético inspirado en el cielo nocturno.",
      "Propón un tema artístico para una ilustración digital.",
    ],
    "de": [
      "Schlage eine kreative Zeitreise-Geschichte vor.",
      "Gib ein poetisches Thema inspiriert vom Nachthimmel.",
      "Mache einen Vorschlag für ein künstlerisches digitales Bild.",
    ],
  },
  "Copy.ai": {
    "en": [
      "Write a catchy tagline for a fashion sale.",
      "Generate Facebook ad copy for my startup.",
      "Create a product description for a new gadget.",
    ],
    "hi": [
      "फैशन सेल के लिए टैगलाइन बनाएं।",
      "स्टार्टअप के लिए फेसबुक विज्ञापन कॉपी बनाएं।",
      "नए गैजेट के लिए प्रोडक्ट डिस्क्रिप्शन लिखें।"
    ],
    "mr": [
      "फॅशन सेलसाठी आकर्षक टैगलाइन सुचवा.",
      "स्टार्टअपसाठी Facebook जाहिरात मजकूर तयार करा.",
      "नविन गॅजेटसाठी उत्पादन वर्णन तयार करा."
    ],
    "es": [
      "Haz un eslogan para una venta de moda.",
      "Crea texto para un anuncio de Facebook.",
      "Describe un producto tecnológico nuevo."
    ],
    "de": [
      "Slogan für Modetrend erstellen.",
      "Facebook-Werbtext für ein Startup generieren.",
      "Produktbeschreibung für neues Gadget verfassen."
    ],
  },
  "UxPilot": {
    "en": [
      "Analyze onboarding screen for usability issues.",
      "Get UX improvement tips for the checkout flow.",
      "Identify confusing elements in my sign-up process.",
    ],
    "hi": [
      "ऑनबोर्डिंग स्क्रीन की उपयोगिता जांचें।",
      "चेकआउट UX सुधार सुझाव प्राप्त करें।",
      "साइन-अप में उलझन वाली बातें पाएं।",
    ],
    "mr": [
      "ऑनबोर्डिंग स्क्रीन उपयोगिता तपासा.",
      "चेकआउटसाठी UX सुधारणा मिळवा.",
      "साईनअपमधील गैरसमज सुचना द्या.",
    ],
    "es": [
      "Analiza facilidad de uso de onboarding.",
      "Sugiere mejoras UX al flujo de pago.",
      "Detecta confusiones en registro.",
    ],
    "de": [
      "Onboarding-Screen auf UX-Probleme prüfen.",
      "Tipps zur Checkout-UX anfordern.",
      "Verwirrende Elemente im Anmeldeprozess finden.",
    ],
  },
  "Visily": {
    "en": [
      "Turn a napkin sketch into a mobile wireframe.",
      "Generate a SaaS dashboard mockup from a prompt.",
      "Collaborate on UI design with real-time feedback.",
    ],
    "hi": [
      "स्केच को मोबाइल वायर्फ्रेम में बदलें।",
      "प्रॉम्प्ट से SaaS डैशबोर्ड बनाएं।",
      "रियल-टाइम फीडबैक के साथ डिज़ाइन करें।",
    ],
    "mr": [
      "स्केचवरून मोबाईल वायर्फ्रेम करा.",
      "प्रांप्टमधून SaaS डॅशबोर्ड तयार करा.",
      "रिअलटाइम फीडबॅकसह डिजाइन करा.",
    ],
    "es": [
      "Convierte boceto en wireframe móvil.",
      "Crea dashboard SaaS desde un prompt.",
      "Diseña UI en colaboración IA.",
    ],
    "de": [
      "Skizze in Mobile-Wireframe umwandeln.",
      "SaaS-Dashboard per Prompt generieren.",
      "Gemeinsam UI gestalten und Feedback erhalten.",
    ],
  },
  "GalileoAI": {
    "en": [
      "Create a login page UI from a short prompt.",
      "Design onboarding flow in Figma with AI.",
      "Generate a landing page with modern styles.",
    ],
    "hi": [
      "प्रॉम्प्ट से लॉगिन पेज बनाएं।",
      "AI से Figma में ऑनबोर्डिंग डिजाइन करें।",
      "मॉडर्न स्टाइल में लैंडिंग पेज पाएं।",
    ],
    "mr": [
      "प्रॉम्प्टवरून लॉगिन पेज तयार करा.",
      "Figma मध्ये AI ने ऑनबोर्डिंग बनवा.",
      "मॉडर्न लुकसह लँडिंग पेज तयार करा.",
    ],
    "es": [
      "Crea página login desde texto.",
      "Diseña onboarding con IA en Figma.",
      "Genera landing moderna al instante.",
    ],
    "de": [
      "Login-Page via Textprompt erstellen.",
      "Onboarding-Flow mit KI in Figma designen.",
      "Modernes Landingpage-Design generieren.",
    ],
  },
  "Site123": {
    "en": [
      "Create a simple website for a bakery in under 10 minutes.",
      "Customize a blog template and launch with mobile support.",
      "Add contact forms and image galleries without coding.",
    ],
    "hi": [
      "बेकर के लिए 10 मिनट में वेबसाइट बनाएं।",
      "ब्लॉग टेम्पलेट को कस्टमाइज़ और मोबाइल समर्थ बनाएं।",
      "कोड के बिना संपर्क फॉर्म व गैलरी जोड़ें।",
    ],
    "mr": [
      "10 मिनिटांत बेकरीसाठी वेबसाइट तयार करा.",
      "ब्लॉग टेम्पलेट बदलून मोबाइल फ्रेंडली लॉन्च करा.",
      "कोड न करता फॉर्म व गॅलरी जोडा.",
    ],
    "es": [
      "Crea un sitio para panadería en minutos.",
      "Personaliza plantillas y lanza tu blog móvil.",
      "Agrega formularios y galerías sin programar.",
    ],
    "de": [
      "Baue eine Bäckerei-Webseite in 10 Minuten.",
      "Passe Blog-Templates an & aktiviere Mobilansicht.",
      "Formulare & Galerien ohne Coding einbauen.",
    ],
  },
  "Oddo": {
    "en": [
      "Set up an online store with payment methods and analytics.",
      "Integrate business CRM with website for customer management.",
      "Launch a portfolio site using ready-made business apps.",
    ],
    "hi": [
      "ऑनलाइन शॉप के लिए पेमेंट और एनालिटिक्स जोड़ें।",
      "ग्राहक प्रबंधन हेतु CRM इंटीग्रेट करें।",
      "रेडी-बिज़नेस ऐप से पोर्टफोलियो साइट लॉन्च करें।",
    ],
    "mr": [
      "पेमेंट व एनालिटिक्ससह ऑनलाइन स्टोअर सुरू करा.",
      "ग्राहक व्यवस्थेसाठी CRM संलग्न करा.",
      "बिझनेस अ‍ॅप्सने पोर्टफोलियो साइट तयार करा.",
    ],
    "es": [
      "Configura tienda web con pagos y análisis.",
      "Integra CRM y gestiona clientes online.",
      "Lanza un portfolio con apps listas IA.",
    ],
    "de": [
      "Onlineshop mit Zahlsystem & Analyse einrichten.",
      "CRM mit Website zur Kundenverwaltung verbinden.",
      "Portfolio dank fertiger Business-Apps starten.",
    ],
  },
  "Wix": {
    "en": [
      "Design a photography website with drag-and-drop editor.",
      "Use AI to optimize for SEO and mobile devices.",
      "Integrate e-commerce tools into a Wix site easily.",
    ],
    "hi": [
      "ड्रैग-एंड-ड्रॉप एडिटर से फोटोग्राफी वेबसाइट बनाएं।",
      "AI से SEO व मोबाइल के लिए ऑप्टिमाइज़ करें।",
      "ई-कॉमर्स टूल Wix वेबसाइट में जोड़ें।",
    ],
    "mr": [
      "ड्रॅग-ड्रॉपने फोटोग्राफी साइट डिझाईन करा.",
      "AI ने SEO व मोबाईलसाठी ऑप्टीमाइज करा.",
      "Wix वर ई-कॉमर्स टूल सहज वापरा.",
    ],
    "es": [
      "Diseña web de fotos con editor visual.",
      "Optimiza SEO/móvil automático IA.",
      "Añade e-commerce a tu web con Wix.",
    ],
    "de": [
      "Fotoseite mit Editor gestalten.",
      "SEO/Mobile durch KI optimieren.",
      "E-Commerce-Tools einfach integrieren.",
    ],
  },
  "Replit": {
    "en": [
      "Collaborate live to build a landing page.",
      "Host and instantly deploy your web app with AI-powered tools.",
      "Use AI code completions for faster dev cycles.",
    ],
    "hi": [
      "लाइव कोडिंग से लैंडिंग पेज बनाएं।",
      "AI टूल्स से वेबऐप तुरंत होस्ट करें।",
      "कोड पूरा करने के लिए AI का उपयोग करें।",
    ],
    "mr": [
      "एकत्रितपणे लँडिंग पेज बनवा.",
      "AI टूल्सने जलद वेबअॅप होस्ट करा.",
      "फास्ट कोडिंगसाठी AI वापरा.",
    ],
    "es": [
      "Colabora en vivo creando landing web.",
      "Aloja y lanza tu app web con IA.",
      "Completa código con AI y acelera dev.",
    ],
    "de": [
      "Gemeinsam Landingpage entwickeln.",
      "Web-App per KI im Team hosten.",
      "Entwicklung per KI-Autovervollständigung beschleunigen.",
    ],
  },
  "Renderforest": {
    "en": [
      "Generate a logo and website for your startup instantly.",
      "Build a video intro for a landing page with ready templates.",
      "Combine images, text, and video for a full web portfolio.",
    ],
    "hi": [
      "स्टार्टअप के लिए लोगो व वेबसाइट बनाएं।",
      "लैंडिंग के लिए वीडियो इंट्रो तैयार करें।",
      "इमेज, टेक्स्ट, वीडियो के साथ पोर्टफोलियो वेबसाइट बनाएं।",
    ],
    "mr": [
      "स्टार्टअपने वेबसाइट व लोगो तयार करा.",
      "लँडिंगसाठी व्हिडिओ इंट्रो बनवा.",
      "चित्र, मजकूर व व्हिडिओसह पोर्टफोलियो तयार करा.",
    ],
    "es": [
      "Genera logo y web para startup rápido.",
      "Haz intro de video con plantillas IA.",
      "Arma web portafolio con imágenes y IA.",
    ],
    "de": [
      "Logo & Website für Startup generieren.",
      "Video-Intro mit Templates bauen.",
      "Portfolio mit Bild, Text, Video zusammenstellen.",
    ],
  },
  "Copyai": {
    "en": [
      "Write a catchy tagline for a fashion sale.",
      "Generate Facebook ad copy for my startup.",
      "Create a product description for a new gadget.",
    ],
    "hi": [
      "फैशन सेल के लिए टैगलाइन बनाएं।",
      "स्टार्टअप के लिए फेसबुक विज्ञापन कॉपी बनाएं।",
      "नए गैजेट के लिए प्रोडक्ट डिस्क्रिप्शन लिखें।"
    ],
    "mr": [
      "फॅशन सेलसाठी आकर्षक टैगलाइन सुचवा.",
      "स्टार्टअपसाठी Facebook जाहिरात मजकूर तयार करा.",
      "नविन गॅजेटसाठी उत्पादन वर्णन तयार करा."
    ],
    "es": [
      "Haz un eslogan para una venta de moda.",
      "Crea texto para un anuncio de Facebook.",
      "Describe un producto tecnológico nuevo."
    ],
    "de": [
      "Slogan für Modetrend erstellen.",
      "Facebook-Werbtext für ein Startup generieren.",
      "Produktbeschreibung für neues Gadget verfassen."
    ],
  },
  "Ahrefs": {
    "en": [
      "Find high-traffic keywords for a cooking blog.",
      "Audit my website for SEO issues.",
      "Analyze competitors’ backlinks and ranking.",
    ],
    "hi": [
      "कुकिंग ब्लॉग के लिए ट्रैफिक कीवर्ड खोजें।",
      "वेबसाइट के SEO समस्याओं का ऑडिट करें।",
      "स्पर्धी वेबसाइट्स के बैकलिंक्स का विश्लेषण करें।"
    ],
    "mr": [
      "कुकिंग ब्लॉगसाठी ट्रॅफिक कीवर्ड शोधा.",
      "वेबसाइटचा SEO ऑडिट करा.",
      "स्पर्धकांची बॅकलिंक्स व रँकिंग विश्लेषण करा."
    ],
    "es": [
      "Busca keywords populares para blog de cocina.",
      "Haz un análisis SEO de mi web.",
      "Analiza enlaces y ranking de la competencia."
    ],
    "de": [
      "Hochwertige Keywords für Kochblog suchen.",
      "Website auf SEO-Probleme prüfen.",
      "Backlinks & Rankings der Konkurrenz analysieren."
    ],
  },
  "JenniAI": {
    "en": [
      "Write an academic essay on climate policy.",
      "Summarize research papers with smart citations.",
      "Generate ideas for a neuroscience article.",
    ],
    "hi": [
      "क्लाइमेट पॉलिसी पर एकेडमिक निबंध लिखें।",
      "रिसर्च पेपर्स का सारांश व रिफरेंस बनाएं।",
      "न्यूरोसाइंस आर्टिकल के लिए विचार सुझाएं।"
    ],
    "mr": [
      "क्लायमेट पॉलिसीवर अकादमिक निबंध लिहा.",
      "संशोधन पेपरचे सारांश करा व संदर्भ द्या.",
      "न्यूरोसायन्स लेखासाठी कल्पना सुचवा."
    ],
    "es": [
      "Redacta un ensayo sobre política climática.",
      "Resume papers con referencias automáticas.",
      "Genera ideas para un artículo de neurociencia."
    ],
    "de": [
      "Verfasse einen Essay zu Klimapolitik.",
      "Fasse Papers mit Quellenangabe zusammen.",
      "Ideen für Neuroartikel generieren."
    ],
  },
  "LogoCopy": {
    "en": [
      "Create a tech startup logo with a modern look.",
      "Generate a monochrome logo for a coffee brand."
    ],
    "hi": [
      "एक टेक स्टार्टअप के लिए आधुनिक लोगो बनाएं।",
      "एक कॉफी ब्रांड के लिए मोनोक्रोम लोगो जेनरेट करें।"
    ],
    "mr": [
      "टेक स्टार्टअपसाठी आधुनिक लोगो तयार करा.",
      "कॉफी ब्रँडसाठी मोनोक्रोम लोगो तयार करा."
    ],
    "es": [
      "Crea un logo moderno para una startup tecnológica.",
      "Genera un logo monocromático para una marca de café."
    ],
    "de": [
      "Erstelle ein modernes Logo für ein Tech-Startup.",
      "Erzeuge ein einfarbiges Logo für eine Kaffeebrand."
    ],
  },
  "DesignCom": {
    "en": [
      "Design a minimal logo for a fitness brand.",
      "Generate a colorful logo for an e-commerce site."
    ],
    "hi": [
      "फिटनेस ब्रांड के लिए मिनिमल लोगो डिज़ाइन करें।",
      "ई-कॉमर्स साइट के लिए रंगीन लोगो बनाएं।"
    ],
    "mr": [
      "फिटनेस ब्रँडसाठी मिनिमल लोगो डिझाइन करा.",
      "ई-कॉमर्स साइटसाठी रंगीत लोगो तयार करा."
    ],
    "es": [
      "Diseña un logo minimalista para una marca de fitness.",
      "Genera un logo colorido para un sitio de e-commerce."
    ],
    "de": [
      "Gestalte ein minimalistisches Logo für eine Fitnessmarke.",
      "Erstelle ein farbenfrohes Logo für eine E-Commerce-Website."
    ],
  },
  "LogoAI": {
    "en": [
      "Produce a vintage logo for a bakery.",
      "Make a creative vector logo for a non-profit."
    ],
    "hi": [
      "एक बेकरी के लिए विंटेज लोगो तैयार करें।",
      "एक गैर-लाभकारी संस्था के लिए क्रिएटिव वेक्टर लोगो बनाएं।"
    ],
    "mr": [
      "बेकरीसाठी विंटेज लोगो तयार करा.",
      "नॉन प्रॉफिट साठी सर्जनशील वेक्टर लोगो तयार करा."
    ],
    "es": [
      "Produce un logo vintage para una panadería.",
      "Crea un logo vectorial creativo para una ONG."
    ],
    "de": [
      "Erstelle ein Vintage-Logo für eine Bäckerei.",
      "Entwickle ein kreatives Vektor-Logo für eine Non-Profit-Organisation."
    ],
  },
  "LoGo": {
    "en": [
      "Generate a geometric logo for a finance company.",
      "Create a modern logo using only shades of blue."
    ],
    "hi": [
      "एक वित्तीय कंपनी के लिए ज्यामितीय लोगो बनाएं।",
      "केवल नीले रंगों का उपयोग कर एक आधुनिक लोगो बनाएँ।"
    ],
    "mr": [
      "फायनान्स कंपनीसाठी ज्यामितीय लोगो तयार करा.",
      "फक्त निळ्या छटा वापरून आधुनिक लोगो तयार करा."
    ],
    "es": [
      "Genera un logo geométrico para una empresa financiera.",
      "Crea un logo moderno solo con tonos azules."
    ],
    "de": [
      "Erzeuge ein geometrisches Logo für ein Finanzunternehmen.",
      "Erstelle ein modernes Logo nur in Blautönen."
    ],
  },
  "LogoPony": {
    "en": [
      "Design an instant playful logo for a toy store.",
      "Create a simple, elegant logo for a boutique."
    ],
    "hi": [
      "खिलौना स्टोर के लिए एक मजेदार लोगो डिज़ाइन करें।",
      "एक बुटीक के लिए सरल, आकर्षक लोगो तैयार करें।"
    ],
    "mr": [
      "खेळण्यांच्या दुकानासाठी आकर्षक लोगो तयार करा.",
      "बुटीकसाठी सोपा, देखणा लोगो तयार करा."
    ],
    "es": [
      "Diseña un logo divertido para una tienda de juguetes.",
      "Crea un logo sencillo y elegante para una boutique."
    ],
    "de": [
      "Entwirf ein spielerisches Logo für einen Spielzeugladen.",
      "Erstelle ein einfaches, elegantes Logo für eine Boutique."
    ],
  },
  "LogoMaker": {
    "en": [
      "Create a unique logo for a tech podcast.",
      "Design a new identity for a clothing line."
    ],
    "hi": [
      "एक टेक पॉडकास्ट के लिए अनोखा लोगो बनाएं।",
      "कपड़ों की लाइन के लिए नई पहचान डिज़ाइन करें।"
    ],
    "mr": [
      "टेक पॉडकास्टसाठी अनोखा लोगो तयार करा.",
      "कपड्यांच्या लाईनसाठी नवीन ओळख डिझाइन करा."
    ],
    "es": [
      "Crea un logo único para un pódcast tecnológico.",
      "Diseña una nueva identidad para una línea de ropa."
    ],
    "de": [
      "Erstellen Sie ein einzigartiges Logo für einen Technik-Podcast.",
      "Entwerfen Sie eine neue Identität für eine Bekleidungslinie."
    ],
  },
  "TurboLogo": {
    "en": [
      "Generate a logo with your company initials.",
      "Create a startup logo in under a minute."
    ],
    "hi": [
      "अपनी कंपनी के नाम के अक्षरों के साथ लोगो बनाएं।",
      "एक मिनट में स्टार्टअप लोगो तैयार करें।"
    ],
    "mr": [
      "तुमच्या कंपनीच्या आद्याक्षरांसह लोगो तयार करा.",
      "एका मिनिटात स्टार्टअप लोगो तयार करा."
    ],
    "es": [
      "Genera un logo con las iniciales de tu empresa.",
      "Crea un logo para startup en menos de un minuto."
    ],
    "de": [
      "Erzeuge ein Logo mit den Initialen deines Unternehmens.",
      "Erstelle ein Startup-Logo in weniger als einer Minute."
    ],
  },
  "Visenze": {
    "en": [
      "Find similar shoes by uploading a photo.",
      "Show me red handbags under with floral patterns.",
      "Discover furniture sets matching my living room theme.",
    ],
    "hi": [
      "फोटो अपलोड कर के मिलते-जुलते जूते खोजें।",
      "100 डॉलर से कम की रेड हैंडबैग्स और फ्लोरल पैटर्न दिखाएँ।",
      "मेरे लिविंग रूम के थीम से मेल खाते फर्नीचर सेट खोजें।",
    ],
    "mr": [
      "फोटो अपलोड करून तत्सम शूज शोधा.",
      "₹8000 पेक्षा कमी किंमतीचे लाल फिळोरसह हँडबॅग दाखवा.",
      "माझ्या लिव्हिंग रूम थीमशी जुळणारे फर्निचर संच शोधा.",
    ],
    "es": [
      "Encuentra zapatos similares subiendo una foto.",
      "Muéstrame bolsos rojos de menos de 100€ con estampado floral.",
      "Descubre juegos de muebles que combinen con el estilo de mi sala.",
    ],
    "de": [
      "Finde ähnliche Schuhe, indem du ein Foto hochlädst.",
      "Zeige mir rote Handtaschen unter 100€ mit Blumenmuster.",
      "Entdecke Möbelsets, die zu meinem Wohnzimmer passen.",
    ],
  },
  "BlueShift": {
    "en": [
      "Segment users and send targeted email campaigns for winter sales.",
      "Automate SMS reminders to cart abandoners across channels.",
      "Personalize product recommendations based on past purchases.",
    ],
    "hi": [
      "विंटर सेल के लिए यूजर को सेगमेंट करें और लक्षित ईमेल भेजें।",
      "कार्ट छोड़ने वालों को विभिन्न चैनलों पर SMS रिमाइंडर भेजें।",
      "पिछली खरीद के आधार पर उत्पाद सिफारिशें वैयक्तिकृत करें।",
    ],
    "mr": [
      "विण्टर सेलसाठी युजर्सचे विभाजन करा आणि लक्षित ईमेल पाठवा.",
      "कार्ट सोडणाऱ्यांना SMS आठवणी अनेक चॅनेलवर पाठवा.",
      "मागील खरेदी आधारावर उत्पादन शिफारस वैयक्तिकृत करा.",
    ],
    "es": [
      "Segmenta usuarios y envía campañas de email dirigidas para ventas de invierno.",
      "Automatiza recordatorios SMS para carritos abandonados en todos los canales.",
      "Personaliza las recomendaciones de productos según compras anteriores.",
    ],
    "de": [
      "Segmentiere Nutzer und sende zielgerichtete E-Mail-Kampagnen für Wintersales.",
      "Automatisiere SMS-Erinnerungen an Warenkorbabbrecher über alle Kanäle.",
      "Personalisiere Produktempfehlungen basierend auf früheren Käufen.",
    ],
  },
  "LivePerson": {
    "en": [
      "Automate answers to common customer questions via chat.",
      "Analyze conversations for sales opportunities.",
      "Set up a 24/7 virtual shopping assistant.",
    ],
    "hi": [
      "चैट के जरिए सामान्य ग्राहक प्रश्नों के जवाब स्वचालित करें।",
      "बिक्री के अवसरों के लिए बातचीत का विश्लेषण करें।",
      "24/7 वर्चुअल शॉपिंग असिस्टेंट सेट करें।",
    ],
    "mr": [
      "चॅटद्वारे सामान्य प्रश्नांची उत्तरे स्वयंचलित करा.",
      "विक्री संधींसाठी संभाषणे विश्लेषित करा.",
      "24/7 वर्चुअल शॉपिंग सहाय्यक सेट करा.",
    ],
    "es": [
      "Automatiza respuestas a preguntas frecuentes de clientes mediante chat.",
      "Analiza conversaciones en busca de oportunidades de venta.",
      "Configura un asistente virtual de compras 24/7.",
    ],
    "de": [
      "Automatisiere Antworten auf häufige Kundenfragen per Chat.",
      "Analysiere Gespräche auf Verkaufsmöglichkeiten.",
      "Richte einen 24/7 virtuellen Einkaufsassistenten ein.",
    ],
  },
  "ClerkIO": {
    "en": [
      "Recommend products based on user’s browsing history.",
      "Display personalized product carousels on homepage.",
      "Upsell accessories to recent purchasers.",
    ],
    "hi": [
      "उपयोगकर्ता के ब्राउज़िंग इतिहास के आधार पर उत्पाद सुझाएं।",
      "होमपेज पर व्यक्तिगत उत्पाद कैरोसेल दिखाएं।",
      "हाल ही में खरीदारों को सहायक उत्पाद बेचें।",
    ],
    "mr": [
      "वापरकर्त्याच्या ब्राउझिंगच्या आधारे उत्पादने शिफारस करा.",
      "होमपेजवर वैयक्तिकृत उत्पादन कारुसल दाखवा.",
      "अलीकडील खरेदीदारांना अॅक्सेसरी विक्री करा.",
    ],
    "es": [
      "Recomienda productos según el historial de navegación del usuario.",
      "Muestra carruseles de productos personalizados en la página principal.",
      "Vende accesorios a compradores recientes.",
    ],
    "de": [
      "Empfehle Produkte basierend auf dem Browserverlauf des Nutzers.",
      "Zeige personalisierte Produktkarussells auf der Startseite an.",
      "Verkaufe Zubehör an kürzliche Käufer hoch.",
    ],
  },
  "Style": {
    "en": [
      "Suggest matching accessories for a blue dress.",
      "Show me popular looks for summer 2025.",
      "Find outfits based on my body type and color preferences.",
    ],
    "hi": [
      "नीले कपड़े के लिए मेल खाते सामान सुझाएं।",
      "मुझे 2025 की गर्मियों के लिए लोकप्रिय लुक दिखाएं।",
      "मेरे शरीर के प्रकार और रंग प्राथमिकताओं के आधार पर आउटफिट खोजें।",
    ],
    "mr": [
      "निळ्या कपड्यासाठी जुळणारे अॅक्सेसरीज सुचवा.",
      "मला 2025 च्या उन्हाळ्यासाठी प्रसिद्ध लुक दाखवा.",
      "माझ्या शरीराच्या प्रकारावर आणि रंग पसंतीवर आधारित आउटफिट शोधा.",
    ],
    "es": [
      "Sugiere accesorios que combinen con un vestido azul.",
      "Muéstrame looks populares para el verano de 2025.",
      "Encuentra conjuntos basados en mi tipo de cuerpo y preferencias de color.",
    ],
    "de": [
      "Schlage passende Accessoires zu einem blauen Kleid vor.",
      "Zeige mir beliebte Looks für den Sommer 2025.",
      "Finde Outfits basierend auf meinem Körpertyp und Farbvorlieben.",
    ],
  },
  "TomeAI": {
    "en": [
      "Create a compelling story presentation about climate change.",
      "Generate a pitch deck for a new AI product."
    ],
    "hi": [
      "जलवायु परिवर्तन पर प्रेरक कहानी प्रस्तुति बनाएं।",
      "नए AI उत्पाद के लिए पिच डेक बनाएं।"
    ],
    "mr": [
      "हवामान बदलाबद्दल आकर्षक कथा सादरीकरण तयार करा.",
      "नवीन AI उत्पादनासाठी पिच डेक तयार करा."
    ],
    "es": [
      "Crea una presentación persuasiva sobre el cambio climático.",
      "Genera una presentación para un nuevo producto de IA."
    ],
    "de": [
      "Erstelle eine überzeugende Story-Präsentation zum Klimawandel.",
      "Erzeuge ein Pitch-Deck für ein neues KI-Produkt."
    ],
  },
  "DecktopusAT": {
    "en": [
      "Generate a slide deck on market analysis.",
      "Create a product launch presentation in one click."
    ],
    "hi": [
      "बाजार विश्लेषण पर स्लाइड डेक तैयार करें।",
      "एक क्लिक में उत्पाद लॉन्च प्रस्तुति बनाएं।"
    ],
    "mr": [
      "मार्केट विश्लेषणावर स्लाइड डेक तयार करा.",
      "एका क्लिकमध्ये उत्पादन लॉन्च सादरीकरण तयार करा."
    ],
    "es": [
      "Genera una presentación sobre análisis de mercado.",
      "Crea una presentación de lanzamiento de producto en un clic."
    ],
    "de": [
      "Erstellen Sie ein Slide-Deck zur Marktanalyse.",
      "Erstellen Sie eine Produktpräsentation mit nur einem Klick."
    ],
  },
  "Perplexity1": {
    "en": [
      "What are the key statistics for remote work productivity?",
      "Summarize the latest research on AI in education."
    ],
    "hi": [
      "रिमोट कार्य उत्पादकता के मुख्य आंकड़े क्या हैं?",
      "शिक्षा में AI पर नवीनतम शोध का सारांश दें।"
    ],
    "mr": [
      "रिमोट वर्क उत्पादकतेसाठी मुख्य आकडेवारी सांगा.",
      "शिक्षण क्षेत्रातील AI वरील ताज्या संशोधनाचा सारांश द्या."
    ],
    "es": [
      "¿Cuáles son las estadísticas clave sobre productividad en trabajo remoto?",
      "Resume la investigación más reciente sobre IA en educación."
    ],
    "de": [
      "Was sind die wichtigsten Statistiken zur Produktivität bei Remote-Arbeit?",
      "Fassen Sie die aktuelle Forschung zu KI in der Bildung zusammen."
    ],
  },
  "Gemini": {
    "en": [
      "Help me brainstorm topics for a workshop.",
      "Suggest presentation structure for a business plan."
    ],
    "hi": [
      "वर्कशॉप के लिए विषय सोचने में मदद करें।",
      "व्यावसायिक योजना के लिए प्रस्तुति संरचना सुझाएं।"
    ],
    "mr": [
      "वर्कशॉपसाठी विषयांची कल्पना द्या.",
      "बिझनेस प्लॅनसाठी सादरीकरण रचना सुचवा."
    ],
    "es": [
      "Ayúdame a generar ideas para un taller.",
      "Sugiere la estructura de una presentación para un plan de negocios."
    ],
    "de": [
      "Hilf mir, Themen für einen Workshop zu brainstormen.",
      "Schlage eine Präsentationsstruktur für einen Businessplan vor."
    ],
  },
  "Gamma": {
    "en": [
      "Generate creative slides for a design portfolio.",
      "Build an interactive sales proposal in minutes."
    ],
    "hi": [
      "डिज़ाइन पोर्टफोलियो के लिए रचनात्मक स्लाइड बनाएं.",
      "कुछ ही मिनटों में इंटरैक्टिव सेल्स प्रस्ताव तैयार करें।"
    ],
    "mr": [
      "डिझाइन पोर्टफोलियोसाठी सर्जनशील स्लाईड्स तयार करा.",
      "काही मिनिटांत संवादात्मक विक्री प्रस्ताव बनवा."
    ],
    "es": [
      "Genera diapositivas creativas para un portafolio de diseño.",
      "Crea una propuesta de ventas interactiva en minutos."
    ],
    "de": [
      "Erstellen Sie kreative Folien für ein Design-Portfolio.",
      "Bauen Sie ein interaktives Verkaufsangebot in Minuten."
    ],
  },
  "DreamStudio": {
    "en": [
      "Create a fantasy RPG background from text.",
      "Generate a set of enemy sprites for my mobile game.",
      "Visualize game worlds from rough sketches."
    ],
    "hi": [
      "टेक्स्ट से एक फैंटेसी गेम बैकग्राउंड बनाएं।",
      "मोबाइल गेम के लिए एनिमी स्प्राइट्स बनाएं।",
      "स्केच से गेम की दुनिया तैयार करें।"
    ],
    "mr": [
      "मजकूरावरून फँटेसी गेम बॅकग्राउंड तयार करा.",
      "मोबाइल गेमसाठी शत्रू स्प्राइट्स बनवा.",
      "रफ स्केचवरून गेम सीन साकार करा."
    ],
    "es": [
      "Crea fondos RPG de fantasía desde texto.",
      "Genera sprites de enemigos para tu juego.",
      "Visualiza mundos de juego desde un boceto."
    ],
    "de": [
      "Erschaffe ein Fantasy-Gaming-Background aus Text.",
      "Erzeuge Feind-Sprites für ein Handyspiel.",
      "Wandle Skizzen in Spielwelten um."
    ],
  },
  "Scenario": {
    "en": [
      "Auto-generate item icons for a platformer.",
      "Create new enemy designs based on my style.",
      "Populate a level with AI-generated art."
    ],
    "hi": [
      "प्लैटफ़ॉर्मर गेम के लिए आइटम आइकॉन तैयार करें।",
      "मेरे गेम स्टाइल के अनुसार नए एनिमी डिज़ाइन करें।",
      "AI से ग्राफिक्स बनाकर लेवल सजाएं।"
    ],
    "mr": [
      "प्लॅटफॉर्मर साठी आयटम आयकॉन ऑटो-जेनरेट करा.",
      "माझ्या स्टाईलप्रमाणे नवीन शत्रू डिझाइन बनवा.",
      "AI आर्ट वापरून लेव्हल साजरा करा."
    ],
    "es": [
      "Crea iconos de objetos automáticamente.",
      "Diseña enemigos nuevos según mi estilo.",
      "Decora niveles con arte generado por IA."
    ],
    "de": [
      "Automatisch Item-Icons für ein Plattformer-Spiel.",
      "Neue Gegner nach meinem Stil generieren.",
      "Level mit KI-Art befüllen."
    ],
  },
  "LudoAI": {
    "en": [
      "Generate unique game ideas based on existing markets.",
      "Research popular puzzle game mechanics with AI.",
      "Get concept art suggestions for my game pitch."
    ],
    "hi": [
      "मौजूदा बाज़ार के अनुसार नये गेम आइडिया जेनरेट करें।",
      "AI से पजल गेम्स की फीचर्स रिसर्च करें।",
      "गेम पिच के लिए आर्ट सुझाव लें।"
    ],
    "mr": [
      "सध्याच्या मार्केटवर आधारित नवीन गेम कल्पना शोधा.",
      "AI वापरून लोकप्रिय गेम मेकॅनिक्स रिसर्च करा.",
      "गेम पिचसाठी आर्ट सुचना घ्या."
    ],
    "es": [
      "Genera ideas de juego según tendencias.",
      "Investiga mecánicas de puzzles con IA.",
      "Solicita arte conceptual para tu juego."
    ],
    "de": [
      "Spieleideen passend zum Markt generieren.",
      "Rätsel-Mechaniken mit KI analysieren.",
      "Artworks für eine Game-Präsentation vorschlagen lassen."
    ],
  },
  "Rosebud": {
    "en": [
      "Design and test a custom game character with AI.",
      "Prototype a simple adventure game directly online.",
      "Animate a story scene without coding."
    ],
    "hi": [
      "AI से खुद का गेम कैरेक्टर डिज़ाइन करें।",
      "ऑनलाइन सिंपल गेम प्रोटोटाइप करें।",
      "कोडिंग के बिना कहानी सीन एनिमेट करें।"
    ],
    "mr": [
      "AI वापरून कस्टम गेम पात्र बनवा.",
      "आनलाइन सोपी गेम प्रोटोटाईप करा.",
      "कोडशिवाय स्टोरी सीन अ‍ॅनिमेट करा."
    ],
    "es": [
      "Diseña un personaje de juego IA personalizado.",
      "Prototipa un juego simple en línea.",
      "Anima escenas sin necesidad de código."
    ],
    "de": [
      "KI-Game-Charakter selbst gestalten.",
      "Einfaches Abenteuerspiel online prototypen.",
      "Story-Szenen animieren – ohne Programmieren."
    ],
  },
  "HotpotAI": {
    "en": [
      "Create pixel-art tilesets from text prompts.",
      "Design game achievement icons instantly.",
      "Generate UI mockups for game menus."
    ],
    "hi": [
      "टेक्स्ट से पिक्सेल आर्ट टाइलसेट्स बनाएं।",
      "गेम अचीवमेंट आइकॉन बनाएं।",
      "गेम मेन्यू के लिए UI मॉकअप AI से बनाएं।"
    ],
    "mr": [
      "मजकूरावरून पिक्सेल-आर्ट टाइलसेट तयार करा.",
      "गेम उपलब्धता आयकॉन्स डिझाइन करा.",
      "गेम मेनूसाठी UI मॉकअप जनरेट करा."
    ],
    "es": [
      "Crea tilesets pixel-art desde texto.",
      "Diseña iconos de logros en segundos.",
      "Haz maquetas de menús para juegos."
    ],
    "de": [
      "Erzeuge Pixel-Art-Tilesets aus Texteingaben.",
      "Designe Spiel-Erfolgsicons sofort.",
      "Mockups für Spiele-Menüs per KI erstellen."
    ],
  },
  "Canva1": {
    "en": [
      "Design a presentation for a bakery opening.",
      "Create animated slides for a science project."
    ],
    "hi": [
      "बेकरी उद्घाटन के लिए प्रस्तुति डिज़ाइन करें.",
      "विज्ञान प्रोजेक्ट के लिए एनिमेटेड स्लाइड बनाएं।"
    ],
    "mr": [
      "बेकरी उद्घाटनासाठी सादरीकरण डिझाइन करा.",
      "सायन्स प्रोजेक्टसाठी अॅनिमेटेड स्लाईड्स तयार करा."
    ],
    "es": [
      "Diseña una presentación para la apertura de una panadería.",
      "Crea diapositivas animadas para un proyecto de ciencias."
    ],
    "de": [
      "Gestalten Sie eine Präsentation zur Eröffnung einer Bäckerei.",
      "Erstellen Sie animierte Folien für ein Wissenschaftsprojekt."
    ],
  },
  "SheetAI": {
    "en": [
      "Generate a sprite sheet from uploaded character images.",
      "Auto-arrange and export animation sequences for a game.",
      "Edit and label frames in a sprite sheet using AI."
    ],
    "hi": [
      "अपलोड की गई इमेज से स्प्राइट शीट जेनरेट करें।",
      "AI से गेम का एनिमेशन सीक्वेंस बनाएं।",
      "AI का उपयोग कर फ्रेम को एडिट व लेबल करें।"
    ],
    "mr": [
      "अपलोड केलेल्या प्रतिमांपासून स्प्राइट शीट तयार करा.",
      "AI सह गेमसाठी अ‍ॅनिमेशन सर्तनियोजन व निर्यात करा.",
      "AI वापरून स्प्राइट शीटमध्ये फ्रेम संपदित करा."
    ],
    "es": [
      "Genera hojas de sprites a partir de imágenes.",
      "Organiza animaciones y expórtalas para juegos.",
      "Edita y etiqueta sprites automáticamente con IA."
    ],
    "de": [
      "Erzeuge Sprite-Sheets aus Figurenbildern.",
      "Animationen für Spiele anordnen und exportieren.",
      "Frames im Sprite-Sheet per KI bearbeiten und labeln."
    ],
  },
  "CoefficientsAI": {
    "en": [
      "Automatically sync art asset lists from Sheets to your game engine.",
      "Auto-fill missing sprite sheet data using AI.",
      "Connect multiple data sources for asset tracking."
    ],
    "hi": [
      "Sheets से गेम इंजन तक आर्ट असैट्स ऑटो सिंक करें।",
      "AI से स्प्राइट शीट डेटा ऑटो-पूरा करें।",
      "मल्टी डाटा सोर्सेज़ कनेक्ट करें।"
    ],
    "mr": [
      "शीट्समधील ॲसेट्स गेम इंजिनमध्ये ऑटो सिंक करा.",
      "AI वापरून स्प्राइट शीट डेटा भरा.",
      "अनेक डेटासोर्सशी कनेक्ट व्हा."
    ],
    "es": [
      "Sincroniza listas de arte desde Sheets al motor de juego.",
      "Rellena datos de sprites de forma automática.",
      "Conecta diferentes fuentes de datos IA."
    ],
    "de": [
      "Art-Assets automatisch aus Sheets ins Game-Engine übertragen.",
      "Fehlende Sprite-Sheet-Daten per KI ergänzen.",
      "Mehrere Datenquellen verbinden für Asset-Tracking."
    ],
  },
  "PromptLoop": {
    "en": [
      "Summarize sprite descriptions or classify animation types in Sheets.",
      "Auto-fill Excel columns with AI-generated captions.",
      "Run bulk text-to-art prompts directly in a spreadsheet."
    ],
    "hi": [
      "Sheets में स्प्राइट डिस्क्रिप्शन का सारांश बनाएं।",
      "AI से एक्सेल कॉलम ऑटो-फिल करें।",
      "स्प्रेडशीट में बल्क प्रोम्प्ट चलाएं।"
    ],
    "mr": [
      "शीटमध्ये स्प्राइट डिस्क्रिप्शन सारांश तयार करा.",
      "AI सह एक्सेल कॉलम भरा.",
      "स्प्रेडशीटमध्ये bulk प्रॉम्प्ट चालवा."
    ],
    "es": [
      "Resume descripciones de sprites en Sheets.",
      "Rellena columnas de Excel con IA.",
      "Ejecuta prompts de arte masivos IA desde hoja."
    ],
    "de": [
      "Sprite-Beschreibungen in Sheets mit KI zusammenfassen.",
      "Excel-Spalten automatisch per KI ausfüllen.",
      "Text-zu-Art-Prompts direkt im Spreadsheet ausführen."
    ],
  },
  "AIRoomPlanner": {
    "en": [
      "Generate a bedroom layout for a small apartment.",
      "Suggest modern furniture for my living room.",
      "Create a 3D visual of my renovated workspace."
    ],
    "hi": [
      "छोटे अपार्टमेंट के लिए बैडरूम लेआउट बनाएं।",
      "लिविंग रूम के लिए आधुनिक फर्नीचर सुझाव दें।",
      "अपने कार्यक्षेत्र का 3D प्लान तैयार करें।"
    ],
    "mr": [
      "लहान घरासाठी बेडरूम लेआउट तयार करा.",
      "लिव्हिंग रूमसाठी आधुनिक फर्निचर सुचवा.",
      "रेनोवेट केलेल्या कार्यालयाचे 3D दृश्य बनवा."
    ],
    "es": [
      "Planifica una recámara para piso pequeño.",
      "Sugiere muebles modernos para la sala.",
      "Crea un visual 3D de mi oficina renovada."
    ],
    "de": [
      "Erstelle ein Schlafzimmerlayout für eine kleine Wohnung.",
      "Schlage moderne Möbel fürs Wohnzimmer vor.",
      "Erzeuge eine 3D-Ansicht meines Arbeitszimmers."
    ],
  },
  "Microdesigner": {
    "en": [
      "Quickly create icons for a mobile app.",
      "Generate vector illustrations for blog articles.",
      "Design custom infographic elements with AI."
    ],
    "hi": [
      "मोबाइल ऐप के लिए त्वरित आइकन बनाएं।",
      "ब्लॉग आर्टिकल के लिए वेक्टर चित्रण बनाएं।",
      "AI से इनफोग्राफिक एलिमेंट डिज़ाइन करें।"
    ],
    "mr": [
      "मोबाइल अ‍ॅपसाठी जलद आयकॉन्स तयार करा.",
      "ब्लॉगसाठी व्हेक्टर चित्र मिळवा.",
      "AI वापरुन इन्फोग्राफिक तयार करा."
    ],
    "es": [
      "Haz íconos para app en minutos.",
      "Crea ilustraciones vectoriales para blogs.",
      "Diseña infografías IA personalizadas."
    ],
    "de": [
      "Schnell Icons für Apps entwerfen.",
      "Vektorillustrationen fürs Blog generieren.",
      "Infografik-Elemente mit KI gestalten."
    ],
  },
  "Nisme": {
    "en": [
      "Get personalized graphics for an online shop.",
      "Suggest brand-consistent banners for advertising.",
      "Generate unique visuals matching company guidelines."
    ],
    "hi": [
      "ऑनलाइन शॉप के लिए ग्राफिक्स प्राप्त करें।",
      "ब्रांड के अनुरूप विज्ञापन बैनर सुझाएं।",
      "कंपनी स्टाइल गाइड के अनुसार ग्राफिक्स बनाएं।"
    ],
    "mr": [
      "ऑनलाइन शॉपसाठी ग्राफिक्स मिळवा.",
      "ब्रँडनुसार जाहिरात बॅनर सुचवा.",
      "कंपनी मार्गदर्शिकेसह ग्राफिक्स तयार करा."
    ],
    "es": [
      "Recibe gráficos IA para tu tienda online.",
      "Sugiere banners acordes a tu marca.",
      "Genera imágenes según tu estilo."
    ],
    "de": [
      "Individuelle Grafiken fürs Online-Shop.",
      "Bannervorschläge im Corporate Design.",
      "Grafiken passend zu Markenrichtlinien generieren."
    ],
  },
  "DesignAI": {
    "en": [
      "Auto-generate a full logo design package.",
      "Create animated marketing videos with brand colors.",
      "Draft poster concepts for an event automatically."
    ],
    "hi": [
      "लोगो डिजाइन पैकेज ऑटोमेटेड बनाएं।",
      "ब्रांड रंगों के साथ वीडियो बनाएं।",
      "इवेंट पोस्टर की थीम AI से तैयार करें।"
    ],
    "mr": [
      "लोगो डिझाईन पॅकेज आपोआप घ्या.",
      "ब्रॅंड रंगासह व्हिडिओ तयार करा.",
      "AI वापरुन इव्हेंट पोस्टर संकल्पना तयार करा."
    ],
    "es": [
      "Genera paquete de logos IA.",
      "Crea videos animados de marca.",
      "Esboza pósters para eventos automáticamente."
    ],
    "de": [
      "Logo-Design-Paket automatisch erstellen.",
      "Werbevideos im Markenstil animieren.",
      "Event-Poster-Konzepte mit KI entwerfen."
    ],
  },
  "OpenArtAI": {
    "en": [
      "Generate digital art from a text prompt.",
      "Create unique illustrations for children’s books.",
      "Produce a set of concept artworks for games."
    ],
    "hi": [
      "टेक्स्ट से डिजिटल आर्ट बनाएं।",
      "बाल पुस्तक के लिए चित्रण बनाएं।",
      "गेम्स के लिए कॉन्सेप्ट आर्टवर्क बनाएं।"
    ],
    "mr": [
      "मजकूरावरून डिजिटल कला तयार करा.",
      "बालपुस्तकासाठी चित्रे तयार करा.",
      "गेमसाठी आर्टवर्क्स तयार करा."
    ],
    "es": [
      "Genera arte digital desde texto.",
      "Ilustra cuentos infantiles únicos.",
      "Produce arte conceptual para juegos."
    ],
    "de": [
      "Digitale Kunst aus Texteingaben erstellen.",
      "Einzigartige Illustrationen für Kinderbücher.",
      "Konzept-Designs für Spiele generieren."
    ],
  },
  "RoomGPT": {
    "en": [
      "Redesign my kitchen with a minimalist theme.",
      "See how my bedroom would look in Scandinavian style.",
      "Try boho and industrial looks on my living room photo."
    ],
    "hi": [
      "मिनिमलिस्ट थीम के साथ किचन रीडिज़ाइन करें।",
      "स्कैंडेनेवियन स्टाइल में बेडरूम का नया लुक देखें।",
      "लिविंग रूम फोटो में बोहो या इंडस्ट्रियल थीम आज़माएं।"
    ],
    "mr": [
      "किचन मिनिमल थीमने पुन्हा डिझाइन करा.",
      "स्कँडिनेव्हियन शैलीत बेडरूम पाहा.",
      "लिव्हिंग रूम फोटोवर बोहो/इंडस्ट्रियल लुक अजमवा."
    ],
    "es": [
      "Rediseña la cocina en estilo minimalista.",
      "Mira tu habitación en estilo escandinavo.",
      "Prueba tema boho e industrial en tu sala."
    ],
    "de": [
      "Gestalte meine Küche minimalistisch um.",
      "Zeige mein Schlafzimmer als skandinavisches Design.",
      "Teste Boho- und Industrie-Looks am Wohnzimmerfoto."
    ],
  },
  "Homestyler": {
    "en": [
      "Visualize a modern 3D living room with all furniture.",
      "Simulate different wall colors for my office.",
      "Take a virtual walkthrough of a new flat layout."
    ],
    "hi": [
      "सभी फर्नीचर के साथ 3D में आधुनिक लिविंग रूम देखें।",
      "ऑफिस के लिए अलग-अलग दीवार रंगों का सिमुलेशन करें।",
      "नए फ्लैट लेआउट का वर्चुअल भ्रमण करें।"
    ],
    "mr": [
      "सर्व फर्निचरसह 3D आधुनिक लिव्हिंग रूम पाहा.",
      "ऑफिससाठी भिंतीच्या विविध रंगांचा अंदाज घ्या.",
      "नवीन फ्लॅट लेआउटचे वर्च्युअल फेरफटका घ्या."
    ],
    "es": [
      "Visualiza una sala moderna 3D amueblada.",
      "Simula distintos colores en las paredes del despacho.",
      "Haz un recorrido virtual por un nuevo piso."
    ],
    "de": [
      "Visualisiere modernes Wohnzimmer in 3D.",
      "Simuliere verschiedene Wandfarben fürs Büro.",
      "Mache einen virtuellen Rundgang durch einen neuen Grundriss."
    ],
  },
  "SuperAI": {
    "en": [
      "Summarize meeting notes swiftly.",
      "Generate weekly productivity reports."
    ],
    "hi": [
      "बैठक नोट्स जल्दी से संक्षिप्त करें।",
      "साप्ताहिक उत्पादकता रिपोर्ट बनाएं।"
    ],
    "mr": [
      "बैठकी नोट्स लवकर संक्षेप करा.",
      "साप्ताहिक उत्पादकता अहवाल तयार करा."
    ],
    "es": [
      "Resumen rápidamente las notas de la reunión.",
      "Generar informes semanales de productividad."
    ],
    "de": [
      "Fassen Sie die Besprechungsnotizen schnell zusammen.",
      "Erstellen Sie wöchentliche Produktivitätsberichte."
    ],
  },
  "Midjourney": {
    "en": ["A futuristic city at sunset.", "Minimalist illustration of a cat."],
    "hi": [
      "सूर्यास्त में एक भविष्यवादी शहर।",
      "एक बिल्ली का मिनिमलिस्ट चित्रण।"
    ],
    "mr": [
      "सूर्यास्ताच्या वेळी एक भविष्यकालीन शहर.",
      "मिनिमलिस्ट मांजरीचे चित्रण."
    ],
    "es": [
      "Una ciudad futurista al atardecer.",
      "Ilustración minimalista de un gato."
    ],
    "de": [
      "Eine futuristische Stadt bei Sonnenuntergang.",
      "Minimale Illustration einer Katze."
    ],
  },
  "Resume.io": {
    "en": [
      "Create a resume for a marketing manager.",
      "Suggest skills for a data analyst role."
    ],
    "hi": [
      "मार्केटिंग मैनेजर के लिए एक रिज़्यूमे बनाएं।",
      "डेटा एनालिस्ट भूमिका के लिए कौशल सुझाएं।"
    ],
    "mr": [
      "मार्केटिंग मॅनेजरसाठी रिझ्युमे तयार करा.",
      "डेटा विश्लेषक भूमिकेसाठी कौशल्ये सुचवा."
    ],
    "es": [
      "Crea un currículum para un gerente de marketing.",
      "Sugiere habilidades para un puesto de analista de datos."
    ],
    "de": [
      "Erstellen Sie einen Lebenslauf für einen Marketingmanager.",
      "Schlagen Sie Fähigkeiten für die Position eines Datenanalysten vor."
    ],
  },
  "GitHub Copilot": {
    "en": [
      "Generate a Python function for image resizing.",
      "Suggest tests for my login API."
    ],
    "hi": [
      "इमेज रिसाइजिंग के लिए एक पाइथन फ़ंक्शन बनाएं।",
      "मेरे लॉगिन एपीआई के लिए परीक्षण सुझाएं।"
    ],
    "mr": [
      "इमेज रीसाइजिंगसाठी पायथन फंक्शन तयार करा.",
      "माझ्या लॉगिन API साठी चाचण्या सुचवा."
    ],
    "es": [
      "Genera una función de Python para redimensionar imágenes.",
      "Sugiere pruebas para mi API de inicio de sesión."
    ],
    "de": [
      "Erstellen Sie eine Python-Funktion zum Ändern der Bildgröße.",
      "Schlagen Sie Tests für meine Login-API vor."
    ],
  },
  "Canva Magic Write": {
    "en": [
      "Draft a product launch email.",
      "Write an Instagram post for a bakery."
    ],
    "hi": [
      "एक उत्पाद लॉन्च ईमेल तैयार करें।",
      "एक बेकरी के लिए इंस्टाग्राम पोस्ट लिखें।"
    ],
    "mr": [
      "उत्पादन लाँचसाठी ईमेल तयार करा.",
      "बेकरीसाठी इंस्टाग्राम पोस्ट लिहा."
    ],
    "es": [
      "Redacta un correo de lanzamiento de producto.",
      "Escribe una publicación de Instagram para una panadería."
    ],
    "de": [
      "Erstellen Sie eine E-Mail zum Produktlaunch.",
      "Schreiben Sie einen Instagram-Post für eine Bäckerei."
    ],
  },
  "ProcessSt": {
    "en": [
      "Automate onboarding process checklists for new hires.",
      "Track recurring QA tasks for each project milestone.",
      "Generate real-time workflow reports.",
    ],
    "hi": [
      "नए कर्मचारियों के लिए ऑनबोर्डिंग चेकलिस्ट ऑटोमेट करें।",
      "हर प्रोजेक्ट माइलस्टोन पर QA टास्क ट्रैक करें।",
      "रीयल-टाइम वर्कफ़्लो रिपोर्ट बनाएं।",
    ],
    "mr": [
      "नवीन कर्मचाऱ्यांसाठी ऑनबोर्डिंग चेकलिस्ट ऑटोमेट करा.",
      "प्रत्येक प्रोजेक्ट टप्प्यावर QA टास्क ट्रॅक करा.",
      "रीयल-टाइम वर्कफ्लो अहवाल तयार करा.",
    ],
    "es": [
      "Automatiza checklists de onboarding para empleados.",
      "Monitorea QA recurrente en cada hito.",
      "Genera reportes de flujos de trabajo al instante.",
    ],
    "de": [
      "Automatisiere Onboarding-Checklisten.",
      "Erfasse wiederkehrende QA-Aufgaben pro Meilenstein.",
      "Erstelle Berichte zum Workflow in Echtzeit.",
    ],
  },
  "ProjectPlanner": {
    "en": [
      "Suggest a timeline for launching a new app.",
      "Generate a Gantt chart for my marketing campaign.",
      "Allocate team resources for next quarter.",
    ],
    "hi": [
      "नए ऐप लॉंच का टाइमलाइन सुझाएं।",
      "मार्केटिंग कैम्पेन के लिए गैंट चार्ट बनाएं।",
      "अगली तिमाही के लिए संसाधन आवंटित करें।",
    ],
    "mr": [
      "नवीन ॲप लाँचसाठी वेळापत्रक सांगा.",
      "मार्केटिंग मोहिमेसाठी गॅन्ट चार्ट तयार करा.",
      "पुढील तिमाहीसाठी साधनवाटप सुचवा.",
    ],
    "es": [
      "Sugiere cronograma para lanzar una app.",
      "Genera un diagrama de Gantt para campaña.",
      "Asigna recursos al equipo para el trimestre.",
    ],
    "de": [
      "Empfiehl einen Zeitplan für den App-Launch.",
      "Erstelle Gantt-Chart für eine Kampagne.",
      "Teile Team-Ressourcen für das nächste Quartal ein.",
    ],
  },
  "Wrike": {
    "en": [
      "Set up team projects and task dependencies.",
      "Automate reminders for overdue activities.",
      "Visualize project timelines and progress.",
    ],
    "hi": [
      "टीम प्रोजेक्ट सेट करें और टास्क डिपेंडेंसी जोड़ें।",
      "ओवरड्यू कार्यों के लिए रिमाइंडर ऑटोमेट करें।",
      "प्रोजेक्ट टाइमलाइन और प्रगति को विज़ुअलाइज़ करें।",
    ],
    "mr": [
      "टीम प्रकल्प आणि कामांची परस्परदायित्वे सेट करा.",
      "विलंबित कामांसाठी स्मरणपत्र ऑटोमेट करा.",
      "प्रकल्प टाईमलाइन आणि प्रगतीचे दृश्य पहा.",
    ],
    "es": [
      "Organiza proyectos y dependencias de tareas.",
      "Automatiza recordatorios para tareas vencidas.",
      "Visualiza cronogramas y progreso de proyectos.",
    ],
    "de": [
      "Projekte und Aufgabenabhängigkeiten einrichten.",
      "Überfällige Aktivitäten automatisch erinnern.",
      "Visualisiere Zeitpläne und Projektfortschritt.",
    ],
  },
  "Workable": {
    "en": [
      "Screen applicants and shortlist best matches.",
      "Automate job interview scheduling via AI.",
      "Generate a report of hiring funnel metrics."
    ],
    "hi": [
      "आवेदकों की स्क्रीनिंग करें एवं सर्वश्रेष्ठ चुनें।",
      "AI द्वारा इंटरव्यू शेड्यूल ऑटोमेट करें।",
      "हायरिंग लक्ष्यों पर रिपोर्ट बनाएं।"
    ],
    "mr": [
      "उमेदवारांचे स्क्रीनिंग करा व सर्वोत्तम निवडा.",
      "AI ने मुलाखतीचे वेळापत्रक ठरवा.",
      "भरती रिपोर्ट जनरेट करा."
    ],
    "es": [
      "Filtra y selecciona candidatos automáticamente.",
      "Agenda entrevistas con IA.",
      "Genera reportes del proceso de selección."
    ],
    "de": [
      "Bewerber automatisiert filtern und auswählen.",
      "Interviews mit KI timen.",
      "Berichte zu Einstellungsprozessen erzeugen."
    ],
  },
  "Toptal": {
    "en": [
      "Find top freelance iOS developers for a project.",
      "Filter remote designers by specialized skill.",
      "Match project requirements to vetted talent."
    ],
    "hi": [
      "iOS प्रोजेक्ट के फ्रीलांसर खोजें।",
      "विशेषज्ञ कौशल से डिजाइनर्स फ़िल्टर करें।",
      "प्रोजेक्ट की आवश्यकता के अनुसार टैलेंट चुनें।"
    ],
    "mr": [
      "iOS प्रोजेक्टसाठी तज्ज्ञ फ्रीलांसर्स शोधा.",
      "विशेष कौशल्यांसाठी डिझायनर्स निवडा.",
      "प्रोजेक्ट गरजेनुसार तज्ञ जोडा."
    ],
    "es": [
      "Busca freelancers expertos en iOS.",
      "Filtra diseñadores freelance por habilidad.",
      "Empareja proyectos con talento certificado."
    ],
    "de": [
      "Finde Top-iOS-Freelancer für dein Projekt.",
      "Desiger nach Fachkenntnis filtern.",
      "Passendes Talent zu Projektanforderungen finden."
    ],
  },
  "ResumeMaker": {
    "en": [
      "Generate a resume for data analyst jobs.",
      "Pick a modern template and auto-fill my work history.",
      "Edit and export a resume as PDF for job applications."
    ],
    "hi": [
      "डेटा विश्लेषक के लिए रिज़्यूमे बनाएं।",
      "आधुनिक टेम्पलेट चुनें और कार्य अनुभव ऑटो-फिल करें।",
      "रिज़्यूमे PDF में सेव करें।"
    ],
    "mr": [
      "डेटा विश्लेषकसाठी रिझ्युमे तयार करा.",
      "आधुनिक टेम्पलेट निवडा, कामाचा इतिहास भरा.",
      "नोकरीसाठी रिझ्युमे PDF मध्ये एक्सपोर्ट करा."
    ],
    "es": [
      "Crea un CV para puestos de analista de datos.",
      "Elige una plantilla moderna y completa mi historial.",
      "Guarda el CV en PDF para las postulaciones."
    ],
    "de": [
      "Erstelle einen Lebenslauf für Data-Analyst-Jobs.",
      "Wähle eine moderne Vorlage, fülle Werdegang aus.",
      "Lebenslauf als PDF für Bewerbungen exportieren."
    ],
  },
  "Sonara": {
    "en": [
      "Scan for remote business analyst jobs and apply automatically.",
      "Send daily job matches for my profile by email.",
      "Track which jobs I've applied to and get status alerts."
    ],
    "hi": [
      "रिमोट बिज़नेस एनालिस्ट जॉब्स खोजें और आवेदन करें।",
      "मेरे प्रोफाइल के लिए जॉब मेल में पाएं।",
      "जिन्हें आवेदन किया है उनका स्टेटस ट्रैक करें।"
    ],
    "mr": [
      "रिमोट बिझनेस अनॅलिस्ट जॉब्स शोधा व अर्ज करा.",
      "माझ्या प्रोफाइलसाठी दररोजचा जॉब मेल मिळवा.",
      "कोणत्या नोकऱ्यांना अर्ज केला ते ट्रॅक करा."
    ],
    "es": [
      "Busca trabajos remotos y postúlate automáticamente.",
      "Envía alertas de empleo a mi correo.",
      "Haz seguimiento al estatus de mis postulaciones."
    ],
    "de": [
      "Finde Remote-Jobs und bewerbe dich automatisch.",
      "Sende Tages-Jobangebote per E-Mail.",
      "Verfolge meine Bewerbungen & Status automatisch."
    ],
  },
  "CareerLock": {
    "en": [
      "Alert me to new tech roles matching my skills.",
      "Suggest next career steps based on trends.",
      "Track progress and feedback for each job application."
    ],
    "hi": [
      "मुझसे मेल खाते टेक जॉब्स पर अलर्ट भेजें।",
      "ट्रेंड के अनुसार करियर सलाह दें।",
      "प्रत्येक आवेदन की प्रगति ट्रैक करें।"
    ],
    "mr": [
      "माझ्या कौशल्यांना साजेशा नोकऱ्यांचे अलर्ट पाठवा.",
      "ट्रेंडनुसार पुढील करिअर स्टेप्स सुचवा.",
      "प्रत्येक अर्जाचे प्रगती ट्रॅक करा."
    ],
    "es": [
      "Alerta de puestos tecnológicos según mi perfil.",
      "Aconseja el siguiente paso profesional.",
      "Monitorea mis candidaturas y feedback recibido."
    ],
    "de": [
      "Informiere bei passenden Tech-Jobs.",
      "Karriereempfehlungen anhand von Trends vorschlagen.",
      "Bewerbungsstatus und Feedback verfolgen."
    ],
  },
  "Kickresume": {
    "en": [
      "Draft a cover letter for a marketing position.",
      "Auto-write a summary section for my CV with AI.",
      "Browse resume samples for engineers and edit live."
    ],
    "hi": [
      "मार्केटिंग पोस्ट के लिए कवर लेटर लिखें।",
      "AI से रिज़्यूमे सारांश तैयार करें।",
      "इंजीनियरिंग के सैंपल रिज़्यूमे देखें और एडिट करें।"
    ],
    "mr": [
      "मार्केटिंगसाठी कव्हर लेटर तयार करा.",
      "AI वापरून CV सारांश लिहा.",
      "इंजिनिअरिंगसाठी नमुना रिझ्युमे पाहा आणि संपादित करा."
    ],
    "es": [
      "Redacta una carta de presentación para marketing.",
      "Crea un resumen profesional con IA.",
      "Edita plantillas para ingenieros online."
    ],
    "de": [
      "Anschreiben für eine Marketingstelle verfassen.",
      "KI-gestützte Profilzusammenfassung schreiben.",
      "Resume-Vorlagen für Ingenieure live editieren."
    ],
  },
  "dApp": {
    "en": [
      "Build a microlearning course on workplace safety.",
      "Assign AI-personalized training for sales teams.",
      "Track completion rates and assessment scores."
    ],
    "hi": [
      "वर्कप्लेस सुरक्षा पर शॉर्ट कोर्स बनाएं।",
      "सेल्स टीम के लिए AI से पर्सनल ट्रेनिंग दें।",
      "अभ्यास पूर्णता व स्कोर ट्रैक करें।"
    ],
    "mr": [
      "वर्कप्लेस सेफ्टीवरील कोर्स बनवा.",
      "AI वापरून सेल्स टीमला प्रशिक्षण द्या.",
      "समाप्त केलेली मॉड्यूल्स व गुण तपासा."
    ],
    "es": [
      "Crea un curso breve sobre seguridad laboral.",
      "Asigna formaciones personalizadas por IA.",
      "Monitorea finalización y resultados."
    ],
    "de": [
      "Erstelle Microlearning-Kurse für Arbeitssicherheit.",
      "Individuelle KI-Trainings an Teams zuweisen.",
      "Abschlussquoten im Blick behalten."
    ],
  },
  "intelliHR": {
    "en": [
      "Analyze employee engagement survey results.",
      "Identify high-performing employees by AI analytics.",
      "Automate alerts for workplace disengagement."
    ],
    "hi": [
      "कर्मचारी सर्वेक्षण विश्लेषण करें।",
      "AI द्वारा शीर्ष परफॉर्मर पहचानें।",
      "डिसएंगेजमेंट के लिए अलर्ट सेट करें।"
    ],
    "mr": [
      "कर्मचारी सर्वेक्षणाचे विश्लेषण करा.",
      "AI विश्लेषणाने उत्तम कामगिरीचे कर्मचारी ओळखा.",
      "डिसएंगेजमेंटसाठी अलर्ट ऑटो सेट करा."
    ],
    "es": [
      "Analiza encuestas de compromiso laboral.",
      "Identifica empleados destacados con IA.",
      "Crea alertas para desmotivación laboral."
    ],
    "de": [
      "Analyse von Mitarbeiterbefragungen.",
      "Top-Mitarbeiter per KI-Analyse erkennen.",
      "Alarme für Demotivation automatisieren."
    ],
  },
  "Effy": {
    "en": [
      "Launch a 360-degree feedback survey automatically.",
      "Summarize team performance reviews with AI.",
      "Schedule regular engagement pulse checks."
    ],
    "hi": [
      "360° फीडबैक सर्वे ऑटोमेट करें।",
      "AI से टीम परफॉरमेंस समीक्षा संक्षिप्त करें।",
      "रेगुलर इंगेजमेंट जाँच शेड्यूल करें।"
    ],
    "mr": [
      "360° फीडबॅक सर्व्हे ऑटो राबवा.",
      "AI वापरून टीमचा परफॉरमेंस सारांश करा.",
      "नियमित एंगेजमेंटसाठी शेड्यूल करा."
    ],
    "es": [
      "Lanza encuestas 360º automáticamente.",
      "Resume evaluaciones con IA.",
      "Programa revisiones periódicas de equipo."
    ],
    "de": [
      "Automatische 360°-Feedback-Umfragen.",
      "Teamsreviews mit KI zusammenfassen.",
      "Regelmäßige Engagement-Checks planen."
    ],
  },
  "Notion": {
    "en": [
      "Create a project dashboard with kanban boards.",
      "Auto-summarize meeting notes and to-dos.",
      "Connect wikis, docs, and project timelines.",
    ],
    "hi": [
      "कानबन बोर्ड के साथ प्रोजेक्ट डैशबोर्ड बनाएं।",
      "मीटिंग नोट्स और टुडू ऑटो-संक्षिप्त करें।",
      "विकी, डॉक्युमेंट्स व प्रोजेक्ट टाइमलाइन कनेक्ट करें।",
    ],
    "mr": [
      "कानबन बोर्डसह प्रकल्प डॅशबोर्ड तयार करा.",
      "मीटिंग नोट्स व कामे ऑटो-संकलित करा.",
      "विकी, दस्तऐवज व टाइमलाईन्स एकत्र करा.",
    ],
    "es": [
      "Crea paneles de proyecto con kanban.",
      "Resume notas y tareas automáticamente.",
      "Conecta wikis, documentos y cronogramas.",
    ],
    "de": [
      "Projekt-Boards mit Kanban erstellen.",
      "Meeting-Notizen und Aufgaben automatisch zusammenfassen.",
      "Wikis, Dokumente und Timelines verbinden.",
    ],
  },
  "Grammly1": {
    "en": [
      "Check this paragraph for mistakes.",
      "Suggest improvements for my cover letter."
    ],
    "hi": [
      "इस अनुच्छेद को गलतियों के लिए जांचें।",
      "मेरे कवर लेटर के लिए सुधार सुझाएं।"
    ],
    "mr": ["या परिच्छेदात चुका तपासा.", "माझ्या कव्हर लेटरसाठी सुधारणा सुचवा."],
    "es": [
      "Revisa este párrafo en busca de errores.",
      "Sugiere mejoras para mi carta de presentación."
    ],
    "de": [
      "Prüfen Sie diesen Absatz auf Fehler.",
      "Schlagen Sie Verbesserungen für mein Anschreiben vor."
    ],
  },
};

// Tool data structure
final List<AiTool> toolsData = [
  AiTool(
    key: "ChatGPT",
    category: "Chatbots",
    shortDesc: {
      "en": "Conversational AI assistant.",
      "hi": "संवादी एआई सहायक।",
      "mr": "संवादी AI सहाय्यक.",
      "es": "Asistente de IA conversacional.",
      "de": "Konversationeller KI-Assistent.",
    },
    url: "https://chat.openai.com/",
  ),
  AiTool(
    key: "ResumeMaker",
    category: "Job Search AI",
    shortDesc: {
      "en": "AI resume builder with templates and instant edits.",
      "hi": "एआई आधारित रिज़्यूमे बिल्डर और टेम्पलेट्स।",
      "mr": "एआय रिझ्युमे बनवणारे आणि टेम्पलेट्स.",
      "es": "Creador de CVs con IA y plantillas rápidas.",
      "de": "KI-Lebenslauf-Generator mit Vorlagen & Sofortanpassung.",
    },
    url: "https://www.resumemaker.online/",
  ),
  AiTool(
    key: "Sonara",
    category: "Job Search AI",
    shortDesc: {
      "en": "Automated AI job search and smart applications.",
      "hi": "एआई से ऑटोमेटेड जॉब सर्च और आवेदन।",
      "mr": "एआय आधारित नोकरी शोध आणि अर्ज ऑटोमेशन.",
      "es": "Búsqueda y postulación de empleos IA automática.",
      "de": "Automatische Jobsuche & Bewerbung per KI.",
    },
    url: "https://www.sonara.ai/",
  ),
  AiTool(
    key: "CareerLock",
    category: "Job Search AI",
    shortDesc: {
      "en": "AI career advice, alerts, and opportunity tracking.",
      "hi": "एआई करियर सलाह, अलर्ट और ट्रैकिंग प्लेटफ़ॉर्म।",
      "mr": "एआय करियर मार्गदर्शन, अलर्ट आणि संधी ट्रॅकिंग.",
      "es": "Consejos y alertas de carrera automatizados IA.",
      "de": "KI-Karriereberatung, Chancen & Alarmfunktionen.",
    },
    url:
        "https://neuflextalent.com/index.php/CareerClockcom/index.php/CareerClock",
  ),
  AiTool(
    key: "Kickresume",
    category: "Job Search AI",
    shortDesc: {
      "en": "AI tool for building resumes & cover letters fast.",
      "hi": "एआई से तेज़ रिज़्यूमे और कवर लेटर बनाएँ।",
      "mr": "एआय वर झटपट रिझ्युमे आणि कव्हर लेटर तयार करा.",
      "es": "Redacta CVs y cartas de presentación con IA.",
      "de": "Lebenslauf & Anschreiben schnell per KI erstellen.",
    },
    url: "https://www.kickresume.com/",
  ),

  AiTool(
    key: "Workable",
    category: "HR AI",
    shortDesc: {
      "en": "AI-driven recruiting & applicant tracking platform.",
      "hi": "AI आधारित भर्ती और एप्लिकेंट ट्रैकिंग प्लेटफ़ॉर्म।",
      "mr": "एआय आधारित भरती व अर्जदार ट्रॅकिंग सिस्टीम.",
      "es": "Plataforma IA para reclutamiento y seguimiento.",
      "de": "KI-Plattform für Recruiting & Bewerbermanagement.",
    },
    url: "https://www.workable.com/",
  ),
  AiTool(
    key: "Toptal",
    category: "HR AI",
    shortDesc: {
      "en": "Elite global talent network with AI matching.",
      "hi": "AI आधारित प्रीमियम टैलेंट नेटवर्क (फ्रीलांसर/एक्सपर्ट्स)।",
      "mr": "AI आधारित जागतिक फ्रीलँसर व तज्ञ नेटवर्क.",
      "es": "Red global de talentos y matching con IA.",
      "de": "Globales Talentnetzwerk mit KI-Matching.",
    },
    url: "https://www.toptal.com/",
  ),
  AiTool(
    key: "EdApp",
    category: "HR AI",
    shortDesc: {
      "en": "AI-powered mobile microlearning and training.",
      "hi": "AI आधारित मोबाइल-लर्निंग व ट्रेनिंग मंच।",
      "mr": "AI आधारित लघु-शिक्षण व प्रशिक्षण अ‍ॅप.",
      "es": "Microlearning móvil y formaciones AI.",
      "de": "KI-basiertes Mobile Learning & Trainingsapp.",
    },
    url: "https://www.edapp.com/",
  ),
  AiTool(
    key: "intelliHR",
    category: "HR AI",
    shortDesc: {
      "en": "AI analytics for employee experience & performance.",
      "hi": "AI विश्लेषण—कर्मचारी अनुभव व प्रदर्शन हेतु।",
      "mr": "एआय विश्लेषण—कर्मचारी अनुभव व कामगिरीसाठी.",
      "es": "Análisis IA para experiencia y desempeño laboral.",
      "de": "KI-Analytics für Mitarbeiter-Performance & Engagement.",
    },
    url: "https://www.intellihr.ai/en/",
  ),
  AiTool(
    key: "Effy",
    category: "HR AI",
    shortDesc: {
      "en": "AI feedback, surveys, and performance management.",
      "hi": "AI फीडबैक, सर्वे और प्रदर्शन प्रबंधन टूल।",
      "mr": "एआय फीडबॅक, सर्व्हे व कामगिरी व्यवस्थापन.",
      "es": "Encuestas y evaluaciones laborales IA.",
      "de": "KI-Feedback, Umfragen & Performance Management.",
    },
    url: "https://projectplanner.ai/",
  ),

  AiTool(
    key: "ProcessSt",
    category: "Project Management AI",
    shortDesc: {
      "en": "AI-powered workflow & checklist automation.",
      "hi": "AI वर्कफ़्लो और चेकलिस्ट ऑटोमेशन टूल।",
      "mr": "एआय वर्कफ्लो व चेकलिस्ट ऑटोमेशन.",
      "es": "Automatización de flujos y listas IA.",
      "de": "KI-Workflow- & Checklisten-Automation.",
    },
    url: "https://www.process.st/",
  ),
  AiTool(
    key: "ProjectPlanner",
    category: "Project Management AI",
    shortDesc: {
      "en": "Smart AI project planning & timeline tools.",
      "hi": "स्मार्ट प्रोजेक्ट प्लानिंग व टाइमलाइन AI टूल्स।",
      "mr": "स्मार्ट AI प्रोजेक्ट नियोजन व वेळ रेखा साधने.",
      "es": "Herramienta IA para planes y cronogramas.",
      "de": "KI-gestützte Projektplanung & Zeitpläne.",
    },
    url: "https://www.projectplanner.app/",
  ),
  AiTool(
    key: "Wrike",
    category: "Project Management AI",
    shortDesc: {
      "en": "AI-driven team collaboration & project tracking.",
      "hi": "टीम सहयोग व प्रोजेक्ट ट्रैकिंग हेतु AI।",
      "mr": "एआय सहकारी प्रोजेक्ट ट्रॅकिंग.",
      "es": "Gestión y seguimiento de proyectos IA.",
      "de": "Projektmanagement & Teamarbeit mit KI.",
    },
    url: "https://www.wrike.com/",
  ),
  AiTool(
    key: "Notion",
    category: "Project Management AI",
    shortDesc: {
      "en": "All-in-one workspace with AI for projects.",
      "hi": "AI युक्त प्रोजेक्ट वर्कस्पेस।",
      "mr": "AI सह ओळखणारे परियोजना कार्यक्षेत्र.",
      "es": "Espacio de trabajo IA para proyectos.",
      "de": "KI-Arbeitsplatz für Projekte & Notizen.",
    },
    url: "https://www.notion.so/",
  ),

  AiTool(
    key: "Plantix",
    category: "Agriculture AI",
    shortDesc: {
      "en": "AI plant disease diagnosis & farming guidance.",
      "hi": "एआई पौधों की बीमारी निदान व कृषि सलाह।",
      "mr": "एआय वनस्पती निदान व शेतकरी मार्गदर्शन.",
      "es": "Diagnóstico de plantas y consejo agrícola IA.",
      "de": "KI-Pflanzenschutz & Landwirtschaftsberatung.",
    },
    url: "https://plantix.net/",
  ),
  AiTool(
    key: "Banaya",
    category: "Agriculture AI",
    shortDesc: {
      "en": "Bayer's AI platform for precision agri insights.",
      "hi": "बेयर का एआई प्लेटफ़ॉर्म: कृषि डेटा व सलाह।",
      "mr": "बायर चे AI कृषी सल्ला व डेटाप्लॅटफॉर्म.",
      "es": "Plataforma IA de Bayer para agricultura de precisión.",
      "de": "Bayers KI-Plattform für Agrardaten & Beratung.",
    },
    url: "https://www.bayer.com/en/agriculture",
  ),
  AiTool(
    key: "Aerobotics",
    category: "Agriculture AI",
    shortDesc: {
      "en": "AI drone crop monitoring & analytics.",
      "hi": "एआई ड्रोन से फसल सर्वेक्षण व विश्लेषण।",
      "mr": "एआय ड्रोन पीक निरीक्षण व विश्लेषण.",
      "es": "Drones IA para monitoreo y análisis de cultivos.",
      "de": "KI-Drohnen für Felder-Überwachung & Analysen.",
    },
    url: "https://aerobotics.com/",
  ),
  AiTool(
      key: "agricopilot",
      category: "Agriculture AI",
      shortDesc: {
        "en": "Voice-powered field data capture for farmers.",
        "hi": "किसानों के लिए वॉयस-डाटा रिकॉर्डिंग एआई।",
        "mr": "शेतकऱ्यांसाठी व्हॉईस डेटा कॅप्चर AI.",
        "es": "Registro de datos agrícolas por voz IA.",
        "de": "Sprachgesteuerte KI-Datenerfassung für Landwirte.",
      },
      url: "https://agricopilot.ai"),

  AiTool(
    key: "DreamStudio",
    category: "Game Development AI",
    shortDesc: {
      "en": "Create game art & assets with AI (Stable Diffusion).",
      "hi": "AI (स्टेबल डिफ्यूजन) से गेम ग्राफिक्स बनाएं।",
      "mr": "AI (Stable Diffusion) ने गेम ग्राफिक्स तयार करा.",
      "es": "Arte y recursos para juegos con IA (Stable Diffusion).",
      "de": "Spiel-Assets mit KI (Stable Diffusion) generieren.",
    },
    url: "https://dreamstudio.ai/",
  ),
  AiTool(
    key: "Scenario",
    category: "Game Development AI",
    shortDesc: {
      "en": "AI toolkit for custom in-game content & art.",
      "hi": "AI टूलकिट - कस्टम गेम आकृति, आर्ट और कंटेंट।",
      "mr": "AI टूल - कस्टम गेम आर्ट व कंटेंटसाठी.",
      "es": "Kit IA para arte y contenido de juegos personalizados.",
      "de": "KI-Werkzeug für individuelles Spiel-Artwork & Inhalte.",
    },
    url: "https://www.scenario.com/",
  ),
  AiTool(
    key: "LudoAI",
    category: "Game Development AI",
    shortDesc: {
      "en": "Game ideation, research, and asset AI platform.",
      "hi": "गेम विचार, रिसर्च और एसेट्स के लिए AI प्लेटफॉर्म।",
      "mr": "गेम कल्पना, संशोधन व एसेटसाठी AI.",
      "es": "IA para ideas, investigación y recursos de juegos.",
      "de": "KI-Plattform für Game-Ideen, Recherche & Assets.",
    },
    url: "https://ludo.ai/",
  ),
  AiTool(
    key: "Rosebud",
    category: "Game Development AI",
    shortDesc: {
      "en": "No-code platform for making AI games & characters.",
      "hi": "AI से गेम व कैरेक्टर बनाएं (कोड नहीं चाहिए)।",
      "mr": "AI ने कोडलेस गेम व कॅरेक्टर तयार करा.",
      "es": "Plataforma sin código para juegos y personajes IA.",
      "de": "No-Code-Plattform für Spiele und KI-Charaktere.",
    },
    url: "https://www.rosebud.ai/",
  ),
  AiTool(
    key: "SheetAI",
    category: "Sprite Sheet AI",
    shortDesc: {
      "en": "AI for creating and managing sprite sheets.",
      "hi": "स्प्राइट शीट बनाने और प्रबंधित करने के लिए एआई।",
      "mr": "स्प्राइट शीट तयार व व्यवस्थापनासाठी AI.",
      "es": "IA para crear y gestionar hojas de sprites.",
      "de": "KI zur Erstellung & Verwaltung von Sprite-Sheets.",
    },
    url: "https://sheetai.app/",
  ),
  AiTool(
    key: "CoefficientsAI",
    category: "Sprite Sheet AI",
    shortDesc: {
      "en": "AI plugin for spreadsheets: automate workflows and fill data.",
      "hi": "स्प्रेडशीट में ऑटोमैटेड AI कार्य और डेटा भरना।",
      "mr": "स्प्रेडशीटमध्ये AI ऑटोमेशन व डेटा भरणे.",
      "es": "Plugin IA para hojas de cálculo y automatización.",
      "de": "KI-Plugin für Tabellenautomation & Dateneingabe.",
    },
    url: "https://coef.ai/",
  ),
  AiTool(
    key: "PromptLoop",
    category: "Sprite Sheet AI",
    shortDesc: {
      "en": "Run AI formulas in Google Sheets & Excel for instant workflows.",
      "hi": "Google शीट्स और एक्सेल में एआई सूत्र चलाएं।",
      "mr": "Google Sheets व Excel मध्ये AI सूत्रे वापरा.",
      "es": "Ejecuta fórmulas IA en Google Sheets y Excel.",
      "de": "Führe KI-Formeln in Google Sheets & Excel aus.",
    },
    url: "https://promptloop.com/",
  ),

  AiTool(
    key: "HotpotAI",
    category: "Game Development AI",
    shortDesc: {
      "en": "Generate game sprites, icons & mockups with AI.",
      "hi": "AI से गेम आइकॉन, स्प्राइट्स और ग्राफिक्स बनाएं।",
      "mr": "AI ने गेम साठी स्प्राइट्स, आयकॉन्स, ग्राफिक्स तयार करा.",
      "es": "Crea sprites, iconos y gráficos con IA para juegos.",
      "de": "Sprites, Icons & Game-Grafiken per KI erzeugen.",
    },
    url: "https://hotpot.ai/",
  ),

  AiTool(
    key: "DreamStudio",
    category: "Game Development AI",
    shortDesc: {
      "en": "Create game art & assets with AI (Stable Diffusion).",
      "hi": "AI (स्टेबल डिफ्यूजन) से गेम ग्राफिक्स बनाएं।",
      "mr": "AI (Stable Diffusion) ने गेम ग्राफिक्स तयार करा.",
      "es": "Arte y recursos para juegos con IA (Stable Diffusion).",
      "de": "Spiel-Assets mit KI (Stable Diffusion) generieren.",
    },
    url: "https://dreamstudio.ai/",
  ),
  AiTool(
    key: "Scenario",
    category: "Game Development AI",
    shortDesc: {
      "en": "AI toolkit for custom in-game content & art.",
      "hi": "AI टूलकिट - कस्टम गेम आकृति, आर्ट और कंटेंट।",
      "mr": "AI टूल - कस्टम गेम आर्ट व कंटेंटसाठी.",
      "es": "Kit IA para arte y contenido de juegos personalizados.",
      "de": "KI-Werkzeug für individuelles Spiel-Artwork & Inhalte.",
    },
    url: "https://www.scenario.com/",
  ),
  AiTool(
    key: "LudoAI",
    category: "Game Development AI",
    shortDesc: {
      "en": "Game ideation, research, and asset AI platform.",
      "hi": "गेम विचार, रिसर्च और एसेट्स के लिए AI प्लेटफॉर्म।",
      "mr": "गेम कल्पना, संशोधन व एसेटसाठी AI.",
      "es": "IA para ideas, investigación y recursos de juegos.",
      "de": "KI-Plattform für Game-Ideen, Recherche & Assets.",
    },
    url: "https://ludo.ai/",
  ),
  AiTool(
    key: "Rosebud",
    category: "Game Development AI",
    shortDesc: {
      "en": "No-code platform for making AI games & characters.",
      "hi": "AI से गेम व कैरेक्टर बनाएं (कोड नहीं चाहिए)।",
      "mr": "AI ने कोडलेस गेम व कॅरेक्टर तयार करा.",
      "es": "Plataforma sin código para juegos y personajes IA.",
      "de": "No-Code-Plattform für Spiele und KI-Charaktere.",
    },
    url: "https://www.rosebud.ai/",
  ),
  AiTool(
    key: "HotpotAI",
    category: "Game Development AI",
    shortDesc: {
      "en": "Generate game sprites, icons & mockups with AI.",
      "hi": "AI से गेम आइकॉन, स्प्राइट्स और ग्राफिक्स बनाएं।",
      "mr": "AI ने गेम साठी स्प्राइट्स, आयकॉन्स, ग्राफिक्स तयार करा.",
      "es": "Crea sprites, iconos y gráficos con IA para juegos.",
      "de": "Sprites, Icons & Game-Grafiken per KI erzeugen.",
    },
    url: "https://hotpot.ai/",
  ),

  // Writing AI Tools
  AiTool(
    key: "Blackbox",
    category: "Writing AI Tools",
    shortDesc: {
      "en": "Code and content generation using advanced AI.",
      "hi": "कोड और सामग्री निर्माण के लिए एडवांस AI।",
      "mr": "कोड आणि कंटेंटसाठी प्रगत AI जनरेशन.",
      "es": "Generación de código y contenido con IA avanzada.",
      "de": "Code- und Inhaltserstellung mit KI.",
    },
    url: "https://blackbox.ai/",
  ),
  AiTool(
    key: "Grammarly",
    category: "Writing AI Tools",
    shortDesc: {
      "en": "Grammar and style checker for English writing.",
      "hi": "अंग्रेजी लेखन के लिए व्याकरण और शैली परीक्षक।",
      "mr": "इंग्रजी लेखनासाठी व्याकरण व शैली तपासणी.",
      "es": "Corrector de gramática y estilo en inglés.",
      "de": "Grammatik- und Stilprüfung für Englisch.",
    },
    url: "https://grammarly.com/",
  ),
  AiTool(
    key: "Copy.ai",
    category: "Writing AI Tools",
    shortDesc: {
      "en": "AI-powered copywriting and content generation.",
      "hi": "AI द्वारा संचालित कॉपीराइटिंग और कंटेंट निर्माण।",
      "mr": "AIद्वारे कॉपी व कंटेंट जनरेशन.",
      "es": "Redacción y creación de contenido con IA.",
      "de": "KI-gestützte Texterstellung.",
    },
    url: "https://copy.ai/",
  ),
  AiTool(
    key: "Ahrefs",
    category: "Writing AI Tools",
    shortDesc: {
      "en": "AI-driven SEO and keyword writing assistant.",
      "hi": "AI SEO और कीवर्ड लेखन सहायक।",
      "mr": "AI आधारित SEO व कीवर्ड लेखन सहाय्यक.",
      "es": "Asistente IA para SEO y escritura de palabras clave.",
      "de": "KI-SEO- und Keyword-Schreibhilfe.",
    },
    url: "https://ahrefs.com/",
  ),
  AiTool(
    key: "ManusAI",
    category: "App Builder AI Tools",
    shortDesc: {
      "en": "No-code mobile app builder powered by AI.",
      "hi": "एआई संचालित नो-कोड मोबाइल ऐप बिल्डर।",
      "mr": "AI द्वारे नो-कोड मोबाइल अ‍ॅप बिल्डर.",
      "es": "Creador de apps móviles sin código con IA.",
      "de": "No-Code-App-Builder mit KI.",
    },
    url: "https://manus.ai/",
  ),
  AiTool(
    key: "Perplexity",
    category: "App Builder AI Tools",
    shortDesc: {
      "en": "AI-powered code generator and research assistant.",
      "hi": "एआई संचालित कोड जनरेटर और रिसर्च असिस्टेंट।",
      "mr": "AI द्वारे कोड जनरेटर व रिसर्च सहाय्यक.",
      "es": "Generador de código con IA y asistente.",
      "de": "KI-basierter Codegenerator & Recherchetool.",
    },
    url: "https://perplexity.ai/",
  ),
  AiTool(
    key: "FirebaseJotform",
    category: "App Builder AI Tools",
    shortDesc: {
      "en": "Build and manage apps with forms, database & AI.",
      "hi": "एप्स बनाएं और फॉर्म, डेटाबेस व AI से प्रबंधित करें।",
      "mr": "फॉर्म, डाटाबेस व AI सह अ‍ॅप्स तयार व व्यवस्थापन.",
      "es": "Construye apps, gestiona formularios y datos (IA).",
      "de": "Apps mit Formularen, Datenbank & KI verwalten.",
    },
    url: "https://jotform.com/",
  ),
  AiTool(
    key: "Uizard",
    category: "App Builder AI Tools",
    shortDesc: {
      "en": "Turn sketches into app prototypes with AI.",
      "hi": "स्केच को AI सहयोग से एप प्रोटोटाइप में बदलें।",
      "mr": "AI वापरून स्केचचे अ‍ॅप प्रोटोटायपमध्ये रूपांतर.",
      "es": "Convierte bocetos en prototipos de app con IA.",
      "de": "Skizzen zu App-Prototypen mit KI.",
    },
    url: "https://uizard.io/",
  ),
  AiTool(
    key: "CreateXYZ",
    category: "App Builder AI Tools",
    shortDesc: {
      "en": "Create apps or tools from natural language ideas.",
      "hi": "आसान भाषा से ऐप्स व टूल्स बनाएं (AI द्वारा)।",
      "mr": "साध्या भाषेतून AI साधने तयार करा.",
      "es": "Crea apps desde ideas en lenguaje natural (IA).",
      "de": "Apps per Beschreibung mit KI erstellen.",
    },
    url: "https://create.xyz/",
  ),
  AiTool(
    key: "TensorFlow",
    category: "App Builder AI Tools",
    shortDesc: {
      "en": "Leading open-source AI/ML framework.",
      "hi": "अग्रणी ओपन सोर्स AI / ML फ्रेमवर्क।",
      "mr": "ओपनसोर्स AI/ML फ्रेमवर्क.",
      "es": "Plataforma IA/ML de código abierto líder.",
      "de": "Open-Source-KI/ML-Framework.",
    },
    url: "https://tensorflow.org/",
  ),
  AiTool(
    key: "Bubble",
    category: "App Builder AI Tools",
    shortDesc: {
      "en": "Drag-and-drop web app builder powered by AI.",
      "hi": "AI आधारित ड्रैग-एंड-ड्रॉप वेब ऐप बिल्डर।",
      "mr": "AI सह वेब अ‍ॅप ड्रॅग-ड्रॉप बिल्डर.",
      "es": "Creador web drag-and-drop con IA.",
      "de": "Drag-and-drop-Web-Builder mit KI.",
    },
    url: "https://bubble.io/",
  ),
  AiTool(
    key: "GitHubCopilot",
    category: "App Builder AI Tools",
    shortDesc: {
      "en": "AI pair programmer and code assistant.",
      "hi": "AI जोड़ीदार और कोड असिस्टेंट।",
      "mr": "AI सहकारी प्रोग्रामर व कोड सहाय्यक.",
      "es": "Programador asistente IA para código.",
      "de": "KI-Codeassistent & Co-Programmierer.",
    },
    url: "https://github.com/features/copilot",
  ),

  // UI Design Tool AI
  AiTool(
    key: "UxPilot",
    category: "UI Design Tool AI",
    shortDesc: {
      "en": "Automated UX research and design suggestions.",
      "hi": "ऑटोमेटेड UX रिसर्च व डिजाइन सुझाव।",
      "mr": "ऑटोमेटेड UX संशोधन आणि डिझाईन सुचवण्या.",
      "es": "Sugerencias automáticas de UX y diseño IA.",
      "de": "Automatisierte UX-Forschung & Designideen mit KI.",
    },
    url: "https://uxpilot.com/",
  ),
  AiTool(
    key: "Visily",
    category: "UI Design Tool AI",
    shortDesc: {
      "en": "Generate wireframes and mockups from text prompts.",
      "hi": "पाठ्य-प्रॉम्प्ट से वाइरफ्रेम व मॉकअप बनाएं।",
      "mr": "टेक्स्ट प्रॉम्प्टवरून वायर्फ्रेम्स तयार करा.",
      "es": "Crea wireframes y prototipos desde texto (IA).",
      "de": "Wireframes & Mockups aus Text mit KI.",
    },
    url: "https://www.visily.ai/",
  ),
  AiTool(
    key: "GalileoAI",
    category: "UI Design Tool AI",
    shortDesc: {
      "en": "Instant UI design with generative AI.",
      "hi": "जेनेरेटिव AI के साथ तुरंत UI डिज़ाइन।",
      "mr": "जेनेरेटिव AI सह सहज UI डिझाईन.",
      "es": "Diseño UI instantáneo con IA generativa.",
      "de": "Sofortiges UI-Design mit KI.",
    },
    url: "https://www.usegalileo.ai/",
  ),

  // Website Maker AI Tools
  AiTool(
    key: "Site123",
    category: "Website Maker AI Tools",
    shortDesc: {
      "en": "Easiest free website builder for everyone.",
      "hi": "सभी के लिए सबसे आसान फ्री वेबसाइट बिल्डर।",
      "mr": "सर्वांसाठी सोपा आणि मोफत वेबसाइट निर्माता.",
      "es": "El constructor de sitios web gratuito más fácil.",
      "de": "Einfachster kostenloser Website-Baukasten.",
    },
    url: "https://www.site123.com/",
  ),
  AiTool(
    key: "Oddo",
    category: "Website Maker AI Tools",
    shortDesc: {
      "en": "All-in-one business & e-commerce website platform.",
      "hi": "ऑल-इन-वन बिजनेस व ई-कॉमर्स वेबसाइट प्लेटफॉर्म।",
      "mr": "ऑल-इन-वन व्यवसाय व ई-कॉमर्स वेबसाइट समाधान.",
      "es": "Plataforma todo-en-uno para negocios y webs e-commerce.",
      "de": "All-in-One-Lösung für Business & Webshop.",
    },
    url: "https://odoo.com/",
  ),
  AiTool(
    key: "Wix",
    category: "Website Maker AI Tools",
    shortDesc: {
      "en": "Drag-and-drop website builder with AI features.",
      "hi": "एआई फीचर्स सहित ड्रैग-एंड-ड्रॉप वेबसाइट बिल्डर।",
      "mr": "AI वैशिष्ट्यांसह ड्रॅग-ड्रॉप वेबसाइट बिल्डर.",
      "es": "Creador web drag-and-drop con IA.",
      "de": "Drag-and-drop-Homepage-Baukasten mit KI.",
    },
    url: "https://wix.com/",
  ),
  AiTool(
    key: "Replit",
    category: "Website Maker AI Tools",
    shortDesc: {
      "en": "Collaborative website & app coding with AI.",
      "hi": "AI के साथ सहयोगी वेबसाइट/ऐप कोडिंग।",
      "mr": "AI सह सहयोगी वेबसाइट/अ‍ॅप कोडिंग.",
      "es": "Codificación colaborativa con IA para web/app.",
      "de": "Gemeinschaftliches Coding für Web & App mit KI.",
    },
    url: "https://replit.com/",
  ),
  AiTool(
    key: "Renderforest",
    category: "Website Maker AI Tools",
    shortDesc: {
      "en": "Create websites, videos & graphics with AI.",
      "hi": "AI से वेबसाइट, वीडियो व ग्राफिक्स बनाएं।",
      "mr": "AI वापरून वेबसाइट, व्हिडिओ व ग्राफिक्स तयार करा.",
      "es": "Haz webs, vídeos y gráficos con IA.",
      "de": "Websites, Videos & Grafiken mit KI erstellen.",
    },
    url: "https://renderforest.com/",
  ),
  AiTool(
    key: "JenniAI",
    category: "Writing AI Tools",
    shortDesc: {
      "en": "AI assistant for academic and creative writing.",
      "hi": "शैक्षिक और रचनात्मक लेखन के लिए AI सहायक।",
      "mr": "शैक्षणिक व सर्जनशील लेखनासाठी AI सहाय्यक.",
      "es": "Ayuda IA para escritura académica y creativa.",
      "de": "KI-Assistent für wissenschaftliches und kreatives Schreiben.",
    },
    url: "https://jenni.ai/",
  ),

// Graphic Design AI Tools
  AiTool(
    key: "Canva",
    category: "Graphic Design AI Tools",
    shortDesc: {
      "en": "All-in-one graphic design platform powered by AI.",
      "hi": "AI संचालित ऑल-इन-वन ग्राफिक डिजाइन मंच।",
      "mr": "AI-चालित ऑल-इन-वन ग्राफिक डिझाईन प्लेटफॉर्म.",
      "es": "Plataforma todo-en-uno de diseño gráfico con IA.",
      "de": "All-in-One Grafikplattform mit KI.",
    },
    url: "https://canva.com/",
  ),
  AiTool(
    key: "Khromo",
    category: "Graphic Design AI Tools",
    shortDesc: {
      "en": "Unique AI color palette and design generator.",
      "hi": "AI रंग पैलेट और डिज़ाइन जनरेटर।",
      "mr": "AI रंग-पैलेट व डिझाईन जनरेटर.",
      "es": "Generador IA de paletas de color y diseño.",
      "de": "KI-Farbpaletten- & Design-Generator.",
    },
    url: "https://www.khroma.co/.co/",
  ),
  AiTool(
    key: "Microdesigner",
    category: "Graphic Design AI Tools",
    shortDesc: {
      "en": "AI tool for quick graphics and illustrations.",
      "hi": "जल्दी ग्राफिक्स और चित्रण के लिए AI टूल।",
      "mr": "जलद ग्राफिक्स व चित्रासाठी AI साधन.",
      "es": "Herramienta IA para gráficos rápidos.",
      "de": "Schnelle Grafik- und Illustrations-KI.",
    },
    url: "https://microdesigner.io/",
  ),
  AiTool(
    key: "Nisme",
    category: "Graphic Design AI Tools",
    shortDesc: {
      "en": "AI-based personalized graphic suggestions.",
      "hi": "AI द्वारा वैयक्तिकृत ग्राफिक सुझाव।",
      "mr": "AI आधारित वैयक्तिकृत ग्राफिक सुचना.",
      "es": "Sugerencias gráficas personalizadas con IA.",
      "de": "Individuelle Grafikvorschläge per KI.",
    },
    url: "https://nisme.ai/",
  ),
  AiTool(
    key: "DesignAI",
    category: "Graphic Design AI Tools",
    shortDesc: {
      "en": "End-to-end design suite powered by AI.",
      "hi": "AI संचालित एंड-टू-एंड डिजाइन सूट।",
      "mr": "AI चालित एंड-टू-एंड डिझाईन सूट.",
      "es": "Suite de diseño integral con IA.",
      "de": "KI-gestützte Komplett-Designsuite.",
    },
    url: "https://designs.ai/",
  ),
  AiTool(
    key: "OpenArtAI",
    category: "Graphic Design AI Tools",
    shortDesc: {
      "en": "AI generator for creative art and illustrations.",
      "hi": "रचनात्मक कला और चित्रण के लिए AI जनरेटर।",
      "mr": "कला व चित्रणासाठी AI जनरेटर.",
      "es": "Generador IA de arte creativo e ilustraciones.",
      "de": "KI-Kunst- und Illustrationsgenerator.",
    },
    url: "https://openart.ai/",
  ),
  AiTool(
    key: "Perplexity",
    category: "Coding Assistants",
    shortDesc: {
      "en": "AI generator for creative art and illustrations.",
      "hi": "रचनात्मक कला और चित्रण के लिए AI जनरेटर।",
      "mr": "कला व चित्रणासाठी AI जनरेटर.",
      "es": "Generador IA de arte creativo e ilustraciones.",
      "de": "KI-Kunst- und Illustrationsgenerator.",
    },
    url: "https://www.perplexity.ai/",
  ),
  AiTool(
    key: "ChatGPT",
    category: "Coding Assistants",
    shortDesc: {
      "en": "AI generator for creative art and illustrations.",
      "hi": "रचनात्मक कला और चित्रण के लिए AI जनरेटर।",
      "mr": "कला व चित्रणासाठी AI जनरेटर.",
      "es": "Generador IA de arte creativo e ilustraciones.",
      "de": "KI-Kunst- und Illustrationsgenerator.",
    },
    url: "https://chatgpt.com/",
  ),
// Civil Sector AI Tools
  AiTool(
    key: "VirtalStaging",
    category: "Civil Sector AI Tools",
    shortDesc: {
      "en": "App for AI-powered virtual staging and real estate.",
      "hi": "AI संचालित वर्चुअल स्टेजिंग और रियल एस्टेट ऐप।",
      "mr": "AI आधारित व्हर्च्युअल स्टेजिंग व रिअल इस्टेट अ‍ॅप.",
      "es": "App IA para puesta en escena virtual inmobiliaria.",
      "de": "KI-App für virtuelle Immobilienstaging.",
    },
    url: "https://aihomedesign.com/virtual-stagingirtual-staging",
  ),
  AiTool(
    key: "CivilsAI",
    category: "Civil Sector AI Tools",
    shortDesc: {
      "en": "AI solutions for civil engineering and infrastructure.",
      "hi": "सिविल इंजीनियरिंग हेतु AI समाधान।",
      "mr": "सिव्हिल इंजिनिअरिंगसाठी AI सोल्यूशन्स.",
      "es": "Soluciones IA para ingeniería civil.",
      "de": "KI für Bauingenieurwesen und Infrastruktur.",
    },
    url: "https://civils.ai/",
  ),
  AiTool(
    key: "ChatAI",
    category: "Civil Sector AI Tools",
    shortDesc: {
      "en": "Conversational AI chat for public sector Q&A.",
      "hi": "सार्वजनिक प्रश्न-उत्तर हेतु संवादात्मक AI चैट।",
      "mr": "सार्वजनिक Q&A साठी संवादात्मक AI चॅट.",
      "es": "Chat conversacional IA para administración pública.",
      "de": "Konversationeller KI-Chat für öffentliche Beratung.",
    },
    url: "https://chat.ai/",
  ),
  AiTool(
    key: "AIRoomPlanner",
    category: "Interior Design AI",
    shortDesc: {
      "en": "AI-powered room layout & furnishing planner.",
      "hi": "एआई आधारित कक्ष डिजाइन व लेआउट प्लानर।",
      "mr": "एआय खोली रचना व सजावट नियोजक.",
      "es": "Planificador IA de distribución y diseño de interiores.",
      "de": "KI-Raumgestaltungs- & Einrichtungsplaner.",
    },
    url: "https://airoomplanner.com/",
  ),
  AiTool(
    key: "RoomGPT",
    category: "Interior Design AI",
    shortDesc: {
      "en": "Redesign rooms from photos using AI.",
      "hi": "फोटो से एआई-कक्ष रीडिजाइन टूल।",
      "mr": "फोटोवरून एआय खोली पुन्हा डिझाइन करा.",
      "es": "Reforma IA de habitaciones desde fotos.",
      "de": "KI-Umgestaltung von Zimmerfotos.",
    },
    url: "https://www.roomgpt.io/",
  ),
  AiTool(
    key: "Homestyler",
    category: "Interior Design AI",
    shortDesc: {
      "en": "3D floor planner & decor ideas with AI.",
      "hi": "एआई के साथ 3D फ़्लोर प्लान व डेकोर आइडियाज।",
      "mr": "एआय सह 3D फ्लोअर प्लॅन व डेकोरेशन कल्पना.",
      "es": "Planos 3D de interiores e ideas IA.",
      "de": "3D-Grundrisse & Dekoideen mit KI.",
    },
    url: "https://www.homestyler.com/",
  ),

  AiTool(
    key: "roamaround",
    category: "AI Trip",
    shortDesc: {
      "en": "Smart AI planner for optimizing trips and room layouts.",
      "hi": "ट्रिप एवं रूम लेआउट के लिए स्मार्ट एआई प्लानर।",
      "mr": "ट्रिप व रूम लेआउटसाठी स्मार्ट AI योजना.",
      "es": "Planificador inteligente de viajes y habitaciones con IA.",
      "de": "Intelligenter KI-Planer für Reisen und Raumlayouts.",
    },
    url: "https://layla.ai/roamaround", // Replace with actual URL if different
  ),
  AiTool(
    key: "VaeayChatbot",
    category: "AI Trip",
    shortDesc: {
      "en": "AI chatbot for conversational trip advice and local info.",
      "hi": "यात्रा सलाह हेतु एआई चैटबोट व लोकल जानकारी।",
      "mr": "प्रवासी सल्ल्यासाठी व स्थानिक माहितीसाठी AI चॅटबोट.",
      "es": "Chatbot IA para viajes y consejos locales.",
      "de": "KI-Chatbot für Reiseberatung und Ortsinfos.",
    },
    url:
        "https://www.usevacay.com/chatbot", // Replace with actual URL if different
  ),
  AiTool(
    key: "TripPlannerAI",
    category: "AI Trip",
    shortDesc: {
      "en": "End-to-end AI-powered trip itinerary generator.",
      "hi": "एआई आधारित यात्रा कार्यक्रम जेनरेटर।",
      "mr": "एआईवर आधारित संपूर्ण प्रवास नियोजक.",
      "es": "Generador IA de itinerarios completos de viaje.",
      "de": "KI-gesteuerter Reiseplan-Generator.",
    },
    url: "https://tripplanner.ai/", // Replace with actual URL if different
  ),
  AiTool(
    key: "TheNewBluilk",
    category: "Passionate AI",
    shortDesc: {
      "en": "Discover your passions and reflect with AI journaling.",
      "hi": "एआई जनरेटिव जर्नलिंग के साथ अपने जुनून को पहचानें।",
      "mr": "AI जर्नलिंगसह स्वतःची आवड शोधा आणि वैयक्तिक विचार मांडा.",
      "es": "Descubre tus pasiones con diarios de IA.",
      "de": "Finde deine Leidenschaften mit KI-gestütztem Journaling.",
    },
    url: "https://newbluefx.com/totalfx/", // Example URL
  ),
  AiTool(
    key: "AlbdO",
    category: "Passionate AI",
    shortDesc: {
      "en": "Creative inspiration and writing prompts powered by AI.",
      "hi": "एआई से प्रेरित रचनात्मक लेखन और विचार।",
      "mr": "AI प्रेरित सर्जनशील लेखन आणि कल्पना.",
      "es": "Inspiración creativa y sugerencias de escritura IA.",
      "de": "Kreative Inspiration und Schreibanregungen durch KI.",
    },
    url: "https://albedo.com/", // Example URL
  ),
  AiTool(
    key: "Visenze",
    category: "E-commerce AI",
    shortDesc: {
      "en": "Visual AI for product recognition and smart search.",
      "hi": "उत्पाद पहचान और स्मार्ट खोज के लिए विजुअल एआई।",
      "mr": "उत्पादन ओळख आणि स्मार्ट शोधासाठी व्हिज्युअल AI.",
      "es": "IA visual para reconocimiento y búsqueda de productos.",
      "de": "Visuelle KI für Produkterkennung und smarte Suche.",
    },
    url: "https://www.visenze.com/",
  ),
  AiTool(
    key: "BlueShift",
    category: "E-commerce AI",
    shortDesc: {
      "en": "AI-driven customer engagement and marketing automation.",
      "hi": "ग्राहक संलग्नता और विपणन ऑटोमेशन के लिए AI।",
      "mr": "ग्राहक संलग्नता आणि मार्केटींग ऑटोमेशनसाठी AI.",
      "es": "Automatización del marketing y engagement mediante IA.",
      "de": "KI-gestützte Kundenbindung und Marketingautomatisierung.",
    },
    url: "https://blueshift.com/",
  ),
  AiTool(
    key: "LivePerson",
    category: "E-commerce AI",
    shortDesc: {
      "en": "Conversational intelligence platform for customer support.",
      "hi": "ग्राहक सहायता हेतु संवादात्मक AI प्लेटफ़ॉर्म।",
      "mr": "ग्राहक सहाय्यसाठी संवादात्मक AI प्लॅटफॉर्म.",
      "es": "Plataforma conversacional IA para soporte al cliente.",
      "de": "Konversations-KI für Kundenservice und E-Commerce.",
    },
    url: "https://www.liveperson.com/",
  ),
  AiTool(
    key: "ClerkIO",
    category: "E-commerce AI",
    shortDesc: {
      "en": "Product recommendations and personalization engine.",
      "hi": "उत्पाद सिफारिश और व्यक्तिगत अनुभव के लिए AI।",
      "mr": "उत्पादन शिफारसी आणि वैयक्तिक अनुभवासाठी AI.",
      "es": "Motor de recomendaciones y personalización IA.",
      "de": "KI-Empfehlungs- und Personalisierungssystem.",
    },
    url: "https://www.clerk.io/",
  ),
  AiTool(
    key: "Style",
    category: "E-commerce AI",
    shortDesc: {
      "en": "AI-powered style suggestions and tailored shopping experience.",
      "hi": "एआई से स्टाइल सुझाव और कस्टमाइज़्ड शॉपिंग।",
      "mr": "AI-आधारित स्टाईल सूचना व वैयक्तिकृत शॉपिंग.",
      "es": "Sugerencias de estilo y experiencia personalizada IA.",
      "de": "KI-Stilempfehlungen und maßgeschneidertes Einkaufserlebnis.",
    },
    url: "https://style.ai/", // example url, replace with actual
  ),
  AiTool(
    key: "ComposerTrade",
    category: "Share Market",
    shortDesc: {
      "en": "AI-driven stock trading ideas platform.",
      "hi": "एआई संचालित स्टॉक ट्रेडिंग विचार मंच।",
      "mr": "AI-चालित शेअर ट्रेडिंग आयडिया प्लॅटफॉर्म.",
      "es": "Plataforma de ideas de trading bursátil con IA.",
      "de": "KI-gesteuerte Aktienhandelsideen-Plattform.",
    },
    url: "https://composer.trade/",
  ),
  AiTool(
    key: "TradeIdeas",
    category: "Share Market",
    shortDesc: {
      "en": "AI stock market analytics and trade suggestions.",
      "hi": "एआई स्टॉक मार्केट विश्लेषण और ट्रेड सुझाव।",
      "mr": "AI शेअर बाजार विश्लेषण व ट्रेड सूचना.",
      "es": "Análisis y sugerencias de trading bursátil IA.",
      "de": "KI-basierte Aktienmarktanalysen und Handelsempfehlungen.",
    },
    url: "https://trade-ideas.com/",
  ),
  AiTool(
    key: "Sigmoidal",
    category: "Share Market",
    shortDesc: {
      "en": "AI trading strategy and financial analysis tool.",
      "hi": "एआई ट्रेडिंग रणनीति और वित्तीय विश्लेषण उपकरण।",
      "mr": "AI ट्रेडिंग स्ट्रॅटेजी व आर्थिक विश्लेषण साधन.",
      "es": "Herramienta de estrategia y análisis financiero IA.",
      "de": "KI-basierte Handelsstrategie und Finanzanalyse-Tool.",
    },
    url: "https://sigmoidal.io/",
  ),
  AiTool(
    key: "Eginbot",
    category: "Share Market",
    shortDesc: {
      "en": "Intelligent stock market automation.",
      "hi": "बुद्धिमान स्टॉक मार्केट ऑटोमेशन।",
      "mr": "बुद्धिमान शेअर मार्केट ऑटोमेशन.",
      "es": "Automatización bursátil inteligente.",
      "de": "Intelligente Börsenautomation.",
    },
    url: "https://gainbot-ai.com/",
  ),
  AiTool(
    key: "LogoCopy",
    category: "Logo Creator",
    shortDesc: {
      "en": "Create stunning logos with AI assistance.",
      "hi": "एआई सहायता से शानदार लोगो बनाएं।",
      "mr": "AI सहाय्याने आकर्षक लोगो तयार करा.",
      "es": "Crea logos impresionantes con asistencia IA.",
      "de": "Erstellen Sie beeindruckende Logos mit KI-Unterstützung.",
    },
    url: "https://logocopy.com",
  ),
  AiTool(
    key: "DesignCom",
    category: "Logo Creator",
    shortDesc: {
      "en": "AI-driven logo and graphic design platform.",
      "hi": "एआई संचालित लोगो और ग्राफिक डिजाइन प्लेटफॉर्म।",
      "mr": "AI आधारित लोगो आणि ग्राफिक डिझाइन प्लॅटफॉर्म.",
      "es": "Plataforma de diseño gráfico y logo impulsada por IA.",
      "de": "KI-gestützte Logo- und Grafikdesign-Plattform.",
    },
    url: "https://design.com",
  ),
  AiTool(
    key: "LogoAI",
    category: "Logo Creator",
    shortDesc: {
      "en": "Generate high quality logos with AI.",
      "hi": "एआई से उच्च गुणवत्ता वाले लोगो बनाएं।",
      "mr": "एआय द्वारे उच्च दर्जाचे लोगो तयार करा.",
      "es": "Genera logos de alta calidad con IA.",
      "de": "Erstellen Sie hochwertige Logos mit KI.",
    },
    url: "https://logoai.com",
  ),
  AiTool(
    key: "LoGo",
    category: "Logo Creator",
    shortDesc: {
      "en": "AI-based advanced logo generator.",
      "hi": "एआई आधारित उन्नत लोगो जनरेटर।",
      "mr": "AI आधारित प्रगत लोगो जनरेटर.",
      "es": "Generador de logotipos avanzado con IA.",
      "de": "Fortschrittlicher KI-Logogenerator.",
    },
    url: "https://logo.com/logos/artificial-intelligence",
  ),
  AiTool(
    key: "LogoPony",
    category: "Logo Creator",
    shortDesc: {
      "en": "Instant professional logo designs with AI.",
      "hi": "एआई से त्वरित पेशेवर लोगो डिजाइन।",
      "mr": "AI द्वारे त्वरित व्यावसायिक लोगो डिझाइन.",
      "es": "Diseños de logotipo profesional con IA al instante.",
      "de": "Sofort professionelle Logos mit KI.",
    },
    url: "https://logopony.com",
  ),
  AiTool(
    key: "LogoMaker",
    category: "Logo Creator",
    shortDesc: {
      "en": "Easy logo design with smart suggestions.",
      "hi": "स्मार्ट सुझावों के साथ आसान लोगो डिज़ाइन।",
      "mr": "स्मार्ट सूचनांसह सहज लोगो डिझाइन.",
      "es": "Diseño de logotipos fácil con sugerencias inteligentes.",
      "de": "Einfache Logo-Designs mit intelligenten Vorschlägen.",
    },
    url: "https://logomaker.com",
  ),
  AiTool(
    key: "TurboLogo",
    category: "Logo Creator",
    shortDesc: {
      "en": "Fast, automated logo branding tool.",
      "hi": "तेज, स्वचालित लोगो ब्रांडिंग टूल।",
      "mr": "वेगवान, स्वयंचलित लोगो ब्रँडिंग साधन.",
      "es": "Herramienta de branding de logos rápida y automática.",
      "de": "Schnelles, automatisiertes Logo-Branding-Tool.",
    },
    url: "https://turbologo.com",
  ),
  AiTool(
    key: "TomeAI",
    category: "Presentation",
    shortDesc: {
      "en": "AI-powered storytelling and presentation builder.",
      "hi": "एआई संचालित कहानी कहने और प्रस्तुति निर्माता।",
      "mr": "AI-शक्तिशाली कथाकथन आणि प्रेझेंटेशन बिल्डर.",
      "es": "Constructor de presentaciones y narración IA.",
      "de": "KI-gestützter Erzähler und Präsentationsersteller.",
    },
    url: "https://tome.app",
  ),
  AiTool(
    key: "DecktopusAT",
    category: "Presentation",
    shortDesc: {
      "en": "Smart slide deck creator with AI.",
      "hi": "एआई के साथ स्मार्ट स्लाइड डेक निर्माता।",
      "mr": "AI-सहाय्यक स्मार्ट स्लाइड डेक निर्माता.",
      "es": "Creador inteligente de presentaciones con IA.",
      "de": "Intelligenter Folienersteller mit KI.",
    },
    url: "https://decktopus.com",
  ),
  AiTool(
    key: "Perplexity",
    category: "Presentation",
    shortDesc: {
      "en": "AI-powered research and Q&A assistant.",
      "hi": "एआई-संचालित अनुसंधान और क्यूए सहायक।",
      "mr": "AI-शक्तियुक्त संशोधन आणि Q&A सहाय्यक.",
      "es": "Asistente de investigación y Q&A impulsado por IA.",
      "de": "KI-gestützter Forschungs- und Q&A-Assistent.",
    },
    url: "https://www.perplexity.ai/",
  ),
  AiTool(
    key: "Gemini",
    category: "Presentation",
    shortDesc: {
      "en": "Google's AI helper for presentations and brainstorming.",
      "hi": "प्रस्तुति और ब्रेनस्टॉर्मिंग के लिए Google का AI सहायक।",
      "mr": "प्रेझेंटेशन आणि विचारमंथनासाठी Google चे AI सहाय्यक.",
      "es": "Asistente IA de Google para presentaciones y ideas.",
      "de": "Googles KI-Helfer für Präsentationen und Brainstorming.",
    },
    url: "https://gemini.google.com/",
  ),
  AiTool(
    key: "Gamma",
    category: "Presentation",
    shortDesc: {
      "en": "Creative content presentations with AI.",
      "hi": "एआई के साथ रचनात्मक प्रजेंटेशन।",
      "mr": "AI सह सर्जनशील प्रेझेंटेशन.",
      "es": "Presentaciones creativas con IA.",
      "de": "Kreative Inhalte und Präsentationen mit KI.",
    },
    url: "https://gamma.app/",
  ),
  AiTool(
    key: "Canva",
    category: "Presentation",
    shortDesc: {
      "en": "Design suite with AI-powered writing and layout tools.",
      "hi": "एआई लेखन और लेआउट टूल्स के साथ डिज़ाइन सूट।",
      "mr": "AI लेखन व लेआउट साधनांसह डिझाइन सूट.",
      "es": "Suite de diseño con IA para escribir y maquetar.",
      "de": "Design-Suite mit KI-Text- und Layout-Tools.",
    },
    url: "https://canva.com/",
  ),
  AiTool(
    key: "SuperAI",
    category: "Productivity",
    shortDesc: {
      "en": "Boosts your productivity with AI.",
      "hi": "एआई के साथ आपकी उत्पादकता बढ़ाता है।",
      "mr": "एआयसह तुमची उत्पादकता वाढवा.",
      "es": "Generador de arte basado en IA.",
      "de": "KI-basierter Kunstgenerator.",
    },
    url: "https://superai.com/",
  ),
  AiTool(
    key: "Midjourney",
    category: "Image Generation",
    shortDesc: {
      "en": "AI-based art generator.",
      "hi": "एआई आधारित कला जनरेटर।",
      "mr": "AI आधारित कला जनरेटर.",
      "es": "Generador de arte basado en IA.",
      "de": "KI-basierter Kunstgenerator.",
    },
    url: "https://www.midjourney.com/",
  ),
  AiTool(
    key: "Resume.io",
    category: "Career Tools",
    shortDesc: {
      "en": "Smart resume builder.",
      "hi": "स्मार्ट रिज़्यूमे बिल्डर।",
      "mr": "स्मार्ट रिझ्युमे बिल्डर.",
      "es": "Creador de currículum inteligente.",
      "de": "Intelligenter Lebenslauf-Ersteller.",
    },
    url: "https://resume.io/",
  ),
  AiTool(
    key: "GitHub Copilot",
    category: "Coding Assistants",
    shortDesc: {
      "en": "Your AI pair programmer.",
      "hi": "आपका एआई पेयर प्रोग्रामर।",
      "mr": "तुमचा AI जोडीदारी प्रोग्रामर.",
      "es": "Tu programador de IA colaborativo.",
      "de": "Ihr KI-Paarprogrammierer.",
    },
    url: "https://github.com/features/copilot",
  ),
  AiTool(
    key: "Canva Magic Write",
    category: "Writing",
    shortDesc: {
      "en": "AI writing assistant in Canva.",
      "hi": "कैनवा में एआई लेखन सहायक।",
      "mr": "कॅनव्हा मध्ये AI लेखन सहाय्यक.",
      "es": "Asistente de escritura IA en Canva.",
      "de": "KI-Schreibassistent in Canva.",
    },
    url: "https://www.canva.com/magic-write/",
  ),
  AiTool(
    key: "HealthifyMe",
    category: "Medical AI",
    shortDesc: {
      "en": "AI nutrition & fitness coaching.",
      "hi": "एआई पोषण और फिटनेस कोचिंग।",
      "mr": "एआय पोषण आणि फिटनेस कोचिंग.",
      "es": "Nutrición y coaching fitness IA.",
      "de": "KI-Ernährungs- & Fitness-Coach.",
    },
    url: "https://healthifyme.com/",
  ),
  AiTool(
    key: "PathAI",
    category: "Medical AI",
    shortDesc: {
      "en": "AI pathology diagnostics platform.",
      "hi": "एआई रोगविज्ञान डायग्नोस्टिक्स प्लेटफ़ॉर्म।",
      "mr": "एआय पॅथॉलॉजी निदान प्लॅटफॉर्म.",
      "es": "Plataforma IA para diagnóstico patológico.",
      "de": "KI-Plattform für Pathologie-Diagnostik.",
    },
    url: "https://pathai.com/",
  ),
  AiTool(
    key: "ETlitic",
    category: "Medical AI",
    shortDesc: {
      "en": "AI-powered medical imaging and analytics.",
      "hi": "एआई आधारित चिकित्सीय इमेजिंग और एनालिटिक्स।",
      "mr": "एआय वैद्यकीय इमेजिंग व विश्लेषण.",
      "es": "Imágenes médicas y análisis con IA.",
      "de": "KI für medizinische Bildgebung & Analytik.",
    },
    url: "https://www.atlantic.net/hipaa-compliant-hosting/medical-ai/",
  ),
  AiTool(
    key: "FitnessAI",
    category: "Fitness AI",
    shortDesc: {
      "en": "Personal AI-powered workout trainer.",
      "hi": "व्यक्तिगत एआई जिम ट्रेनर ऐप।",
      "mr": "व्यक्तिगत AI वर्कआउट मार्गदर्शक.",
      "es": "Entrenador personal de ejercicios con IA.",
      "de": "Persönlicher KI-Trainingscoach.",
    },
    url: "https://www.fitnessai.com/",
  ),
  AiTool(
    key: "CureFit",
    category: "Fitness AI",
    shortDesc: {
      "en": "AI-based workouts, health & nutrition app.",
      "hi": "एआई-आधारित फिटनेस, स्वास्थ्य और डाइट ऐप।",
      "mr": "AI-आधारित फिटनेस व हेल्थ ॲप.",
      "es": "App de fitness y salud con IA.",
      "de": "KI-Fitness-, Gesundheits- und Ernährungsapp.",
    },
    url: "https://www.cure.fit/",
  ),

  AiTool(
    key: "Grammarly",
    category: "Writing",
    shortDesc: {
      "en": "Grammar and style checker.",
      "hi": "व्याकरण और शैली चेकर।",
      "mr": "व्याकरण आणि शैली तपासक.",
      "es": "Corrector de gramática y estilo.",
      "de": "Grammatik- und Stilprüfer.",
    },
    url: "https://www.grammarly.com/",
  ),
];

class AiToolsHomePage extends StatelessWidget {
  final String lang;
  final void Function(String?) onLangChanged;
  const AiToolsHomePage(
      {required this.lang, required this.onLangChanged, super.key});

  @override
  Widget build(BuildContext context) {
    final pack = langPack[lang]!;
    final categories = toolsData.map((t) => t.category).toSet().toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(pack['title']!),
        backgroundColor: Colors.blue,
        actions: [
          DropdownButton<String>(
            value: lang,
            underline: const SizedBox(),
            icon: const Icon(Icons.language, color: Colors.red),
            dropdownColor: Colors.grey[800],
            items: [
              DropdownMenuItem(
                value: 'en',
                child: Text(pack['English']!,
                    style: const TextStyle(color: Colors.white)),
              ),
              DropdownMenuItem(
                value: 'hi',
                child: Text(pack['Hindi']!,
                    style: const TextStyle(color: Colors.white)),
              ),
              DropdownMenuItem(
                value: 'mr',
                child: Text(pack['Marathi']!,
                    style: const TextStyle(color: Colors.white)),
              ),
              DropdownMenuItem(
                value: 'es',
                child: Text(pack['Spanish']!,
                    style: const TextStyle(color: Colors.white)),
              ),
              DropdownMenuItem(
                value: 'de',
                child: Text(pack['German']!,
                    style: const TextStyle(color: Colors.white)),
              ),
            ],
            onChanged: onLangChanged,
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, catIdx) {
          final cat = categories[catIdx];
          final catTools = toolsData.where((t) => t.category == cat).toList();

          return ExpansionTile(
            title:
                Text(cat, style: const TextStyle(fontWeight: FontWeight.bold)),
            children: catTools.map((tool) {
              final translation = toolTranslations[tool.key]?[lang] ??
                  toolTranslations[tool.key]?['en'] ??
                  {};
              return ListTile(
                title: Text(translation['name'] ?? tool.key),
                subtitle: Text(tool.shortDesc[lang] ?? tool.shortDesc['en']!),
                trailing: const Icon(Icons.arrow_forward),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => AiToolDetailPage(tool: tool, lang: lang),
                  ));
                },
              );
            }).toList(),
          );
        },
      ),
    );
  }
}

class AiToolDetailPage extends StatelessWidget {
  final AiTool tool;
  final String lang;

  const AiToolDetailPage({required this.tool, required this.lang, super.key});

  @override
  Widget build(BuildContext context) {
    final pack = langPack[lang]!;
    final translation = toolTranslations[tool.key]?[lang] ??
        toolTranslations[tool.key]?['en'] ??
        {};
    final examples =
        toolExamples[tool.key]?[lang] ?? toolExamples[tool.key]?['en'] ?? [];

    return Scaffold(
      appBar: AppBar(title: Text(translation['name'] ?? tool.key)),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${pack['category']!}: ${tool.category}',
                style: const TextStyle(fontSize: 14, color: Colors.black)),
            const SizedBox(height: 10),
            Text(translation['name'] ?? tool.key,
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(translation['desc'] ?? ""),
            const SizedBox(height: 20),
            Text(pack['examplePrompts']!,
                style: const TextStyle(fontWeight: FontWeight.bold)),
            ...examples.map((p) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4.0),
                  child: Text('• $p'),
                )),
            const Spacer(),
            ElevatedButton.icon(
              icon: const Icon(Icons.open_in_new),
              label: Text(pack['openTool']!),
              onPressed: () async {
                final uri = Uri.parse(tool.url);

                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri);
                } else {
                  await launchUrl(uri);
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}

// Updated AiTool to handle translations
class AiTool {
  final String key; // unique key (original name in English)
  final String category;
  final Map<String, String> shortDesc; // shortDesc for each language
  final String url;

  AiTool({
    required this.key,
    required this.category,
    required this.shortDesc,
    required this.url,
  });
}
